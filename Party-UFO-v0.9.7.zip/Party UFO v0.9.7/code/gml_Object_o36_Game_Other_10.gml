if (substate == 0)
{
    if (prevState != STATE_CREDITS && !retryScenario)
    {
        scrBGM(bgm36P_stageSelect);
    }
    substate = 1;
    with (o36_Card)
    {
        instance_destroy();
    }
    divider = scr36_CreateCard(CHAR_DIVIDER);
    dividerBanned = scr36_CreateCard(CHAR_DIVIDER_BANNED);
    rolodexExit = scr36_CreateCard(CHAR_ROLODEX_EXIT);
    ds_list_clear(deck[0]);
    ds_list_clear(deck[1]);
    ds_list_clear(draw_pile);
    ds_list_clear(party);
    ds_list_clear(store);
    ds_list_clear(rolodex);
    ds_list_clear(draw_pile_fetch);
    ds_list_clear(booted);
    scr36_SetupScenarios();
    scr36_RandomScenario(scenario[5]);
    if (prevState != STATE_WIN && prevState != STATE_LOSE && prevState != STATE_CREDITS)
    {
        scenarioY = 0;
        scenarioX = 0;
        scenarioIndex = 0;
    }
    idleTimer = 0;
    if (retryScenario)
    {
        muteBGM();
        scrTransition(-1, 8, 0, -1000, false);
        retryScenario = false;
        scenarioIndex = 5;
        substate = 2;
    }
}
if (substate == 1)
{
    if (!scrInputAny())
    {
        idleTimer++;
    }
    else
    {
        idleTimer = 0;
    }
    if (idleTimer >= 800)
    {
        idleTimer = 0;
        scr36_ChangeState(STATE_CREDITS);
        exit;
    }
    if (pressUp)
    {
        scenarioY--;
    }
    if (pressDown)
    {
        scenarioY++;
    }
    if (scenarioY < 0)
    {
        scenarioY = 3;
    }
    if (scenarioY > 3)
    {
        scenarioY = 0;
    }
    if (pressLeft)
    {
        scenarioX--;
    }
    if (pressRight)
    {
        scenarioX++;
    }
    if (scenarioX < 0)
    {
        scenarioX = 1;
    }
    if (scenarioX > 1)
    {
        scenarioX = 0;
    }
    if (scenarioY < 3)
    {
        scenarioIndex = (scenarioX * 3) + scenarioY;
    }
    else
    {
        scenarioIndex = 6;
    }
    if (scenarioIndex <= 5 && (pressDown || pressUp || pressLeft || pressRight))
    {
        scrSfx(soundNaviC, 10);
        stateTimer = 0;
    }
    else if (scenarioIndex == 6 && (pressDown || pressUp))
    {
        scrSfx(soundNaviC, 10);
        stateTimer = 0;
    }
    if (scenarioIndex == 5)
    {
        if (fire1pressed || pressDown || pressUp || pressLeft || pressRight)
        {
            scr36_RandomScenario(scenario[5]);
        }
        if (fire1pressed && numPlayers == 2)
        {
            scrSfx(soundRandom, 11);
        }
    }
    if (scenarioIndex > 5 && fire2pressed)
    {
        echoSwap = !echoSwap;
        scrSfx(soundMagicSwap, 50);
    }
    else if (scenarioIndex <= 5 && fire2pressed)
    {
        muteBGM();
        scrSfx(soundStageSelect, 50);
        substate = 2;
    }
}
if (substate == 2)
{
    scr36_SetupGame(scenarioIndex);
    scr36_ChangeState(STATE_START_PARTY);
}
