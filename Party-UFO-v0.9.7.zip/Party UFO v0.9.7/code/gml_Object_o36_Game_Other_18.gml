if (substate == 0)
{
    scrBGM(bgm36P_win);
    substate = 1;
}
if (substate == 1)
{
    stateTimer++;
    if (stateTimer == 15 && wonGame[cp])
    {
        partyFullTimer = 1;
    }
    if (stateTimer == 15)
    {
        tiePossible = false;
        if (numPlayers == 1)
        {
            if (scenarioIndex != 5)
            {
                if (time[cp] > scenarioWins[scenarioIndex])
                {
                    scenarioWins[scenarioIndex] = time[cp];
                }
            }
            else
            {
                scenarioWins[5] = abs(scenarioWins[5]);
                scenarioWins[5]++;
                if (scenarioWins[5] > longestStreak)
                {
                    longestStreak = scenarioWins[5];
                }
            }
            var scenariosBeat = 0;
            for (var i = 0; i < 5; i++)
            {
                if (scenarioWins[i] > 0)
                {
                    scenariosBeat++;
                }
            }
            if (scenariosBeat >= 5)
            {
                scrWin(global.GOLD_WIN);
            }
            if (longestStreak >= CHERRY_GOAL)
            {
                scrWin(global.CHERRY_WIN);
            }
            if (scenariosBeat >= GARDEN_GOAL)
            {
                scrWin(global.GARDEN_WIN);
            }
            for (var i = 0; i < ds_list_size(deck[cp]); i++)
            {
                var currCard = ds_list_find_value(deck[cp], i);
                if (verify(currCard))
                {
                    charsWon[currCard.type] = true;
                }
            }
            scrSaveGame(0);
            messageColor = global.palette[2];
            if (scenarioWins[5] == CHERRY_GOAL)
            {
                scr36_MessageSet(scrString("beat_scenario_cherry"));
            }
            else
            {
                scr36_MessageSet(scrString("beat_scenario"));
            }
        }
        else if (numPlayers == 2)
        {
            if (cp == 0)
            {
                var numDeckStars2P = 0;
                for (var i = 0; i < ds_list_size(deck[1]); i++)
                {
                    var currCard = ds_list_find_value(deck[1], i);
                    numDeckStars2P += currCard.prestige;
                }
                if (numDeckStars2P >= PRESTIGE_GOAL)
                {
                    tiePossible = true;
                }
            }
            if (wonGame[0] && !wonGame[1] && tiePossible == false)
            {
                messageColor = global.palette[2];
                if (cp == 0)
                {
                    scr36_MessageSet(scrString("p1_won_1"));
                }
                else if (cp == 1)
                {
                    scr36_MessageSet(scrString("p1_won_2"));
                }
                scenarioWinsP1[scenarioIndex]++;
                scenarioWinsP2[scenarioIndex] = 0;
                scrSaveGame(0);
            }
            else if (wonGame[0] && !wonGame[1] && tiePossible == true)
            {
                messageColor = global.palette[2];
                scr36_MessageSet(scrString("p1_won_3"));
            }
            else if (wonGame[1] && !wonGame[0])
            {
                messageColor = global.palette[2];
                scr36_MessageSet(scrString("p2_won_1"));
                scenarioWinsP1[scenarioIndex] = 0;
                scenarioWinsP2[scenarioIndex]++;
                scrSaveGame(0);
            }
            else if (wonGame[0] && wonGame[1])
            {
                messageColor = global.palette[2];
                scr36_MessageSet(scrString("p2_won_2"));
            }
        }
    }
    if (stateTimer >= 50)
    {
        if (fire2pressed)
        {
            substate = 3;
            stateTimer = 0;
            with (oFxDummy)
            {
                instance_destroy();
            }
            partyFullTimer = 0;
            if (!tiePossible)
            {
                scrTransition(-1, 30, 0, -20, false);
            }
            var scenariosBeat = 0;
            for (var i = 0; i < 5; i++)
            {
                if (scenarioWins[i] > 0)
                {
                    scenariosBeat++;
                }
            }
            partyFullTimer = 0;
            if (numPlayers == 2 && tiePossible)
            {
                muteBGM();
                gotoState = STATE_START_PARTY;
            }
            else
            {
                cp = 0;
                muteBGM();
                if (global.cheatID <= 0)
                {
                    gotoState = STATE_SCENARIO_SELECT;
                }
                else if (global.cheatID == 1)
                {
                    gotoState = STATE_SEED_SELECTION;
                }
                else if (global.cheatID == 2)
                {
                    gotoState = STATE_MAKE_SHOP;
                }
            }
        }
    }
}
if (substate == 3)
{
    if (scrTransitionDone())
    {
        scr36_ChangeState(gotoState);
        exit;
    }
}
