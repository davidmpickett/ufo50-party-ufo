function scr36_RefreshCharActions(arg0)
{
    var size, ds;
    if (arg0 == 0)
    {
        ds = deck[cp];
        size = ds_list_size(deck[cp]);
    }
    else
    {
        ds = party;
        size = ds_list_size(party);
    }
    for (var i = 0; i < size; i++)
    {
        var currCard = ds_list_find_value(ds, i);
        currCard.bounce = currCard.bouncemax;
        currCard.peek = currCard.peekmax;
        currCard.phone = currCard.phonemax;
        currCard.reshuffle = currCard.reshufflemax;
        currCard.photo = currCard.photomax;
        currCard.matchmaker = currCard.matchmakermax;
        currCard.upgrade = currCard.upgrademax;
        currCard.magicSwap = currCard.magicSwapmax;
        currCard.greet = currCard.greetmax;
        currCard.introvert = currCard.introvertmax;
        currCard.banish = currCard.banishmax;
        currCard.bless = currCard.blessmax;
        currCard.copyfrog = currCard.copyfrogmax;
        currCard.tinyActions = 0;
        currCard.tinyChoice = 0;
        currCard.tinyIndex = 0;
        currCard.tinyList = 0;
        if (arg0 == 0)
        {
            currCard.flopped = false;
            if (currCard.reshuffle)
            {
                currCard.image_index = 0;
            }
            if (currCard.flipped)
            {
                currCard.flipped = false;
                currCard.popularity = currCard.currPop;
                currCard.money = currCard.currMon;
            }
            if (currCard.popularity > 9)
            {
                currCard.popularity = 9;
            }
            if (currCard.money > 9)
            {
                currCard.money = 9;
            }
            if (currCard.type == CHAR_WRESTLER)
            {
                currCard.sprite_index = s36_Wrestler;
                currCard.name = "JACK & BOX";
                currCard.photox = 0;
                currCard.photoy = 6;
            }
            if (currCard.type == CHAR_SECURITY)
            {
                currCard.sprite_index = s36_Security;
                currCard.name = "LANCER";
            }
            if (currCard.type == CHAR_SECURITY_R)
            {
                currCard.sprite_index = s36_Security_R;
                currCard.name = "LANCER";
            }
            if (currCard.type == CHAR_HOST)
            {
                currCard.popularity = 0;
                currCard.money = 0;
                currCard.bounce = 0;
                currCard.bouncemax = 0;
                currCard.bring = 0;
                currCard.troublemaker = 0;
                currCard.peacekeeper = 0;
                currCard.peek = 0;
                currCard.peekmax = 0;
                currCard.dancer = 0;
                currCard.full = 0;
                currCard.phone = 0;
                currCard.phonemax = 0;
                currCard.reshuffle = 0;
                currCard.reshufflemax = 0;
                currCard.photo = 0;
                currCard.photomax = 0;
                currCard.matchmaker = 0;
                currCard.matchmakermax = 0;
                currCard.schoolpride = 0;
                currCard.oldfriend = 0;
                currCard.introvert = 0;
                currCard.introvertmax = 0;
                currCard.werewolf = 0;
                currCard.bless = 0;
                currCard.blessmax = 0;
                currCard.upgrade = 0;
                currCard.upgrademax = 0;
                currCard.troublePopBonus = 0;
                currCard.troubleMoneyBonus = 0;
                currCard.entranceBonus = 0;
                currCard.magicSwap = 0;
                currCard.magicSwapmax = 0;
                currCard.greet = 0;
                currCard.greetmax = 0;
                currCard.banish = 0;
                currCard.banishmax = 0;
                currCard.phoneLow = 0;
                currCard.flipped = 0;
                currCard.tiny = 0;
                currCard.tinySprite1 = 0;
                currCard.tinySprite2 = 0;
                currCard.tinyFlipped1 = 0;
                currCard.tinyFlipped2 = 0;
                currCard.tinyFlopped1 = 0;
                currCard.tinyFlopped2 = 0;
                currCard.tinyPhoto1 = 0;
                currCard.tinyPhoto2 = 0;
                currCard.tinypcolor1 = 0;
                currCard.tinypcolor2 = 0;
                currCard.polaroid = 0;
                currCard.pcolor = 0;
                currCard.arrow = 0;
                currCard.stone = 0;
                currCard.bomb = 0;
                currCard.sprite_index = s36_Host;
            }
        }
    }
}
