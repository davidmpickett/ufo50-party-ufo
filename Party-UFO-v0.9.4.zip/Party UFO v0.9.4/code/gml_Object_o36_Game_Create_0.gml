scrRandomize(57);
scrInputClear();
STATE_SCENARIO_SELECT = 1;
STATE_START_PARTY = 2;
STATE_PARTY = 3;
STATE_STORE = 4;
STATE_LOSE = 5;
STATE_WIN = 6;
STATE_BUSTED = 7;
STATE_SCORE = 8;
STATE_ROLODEX = 9;
STATE_FETCH = 10;
STATE_CREDITS = 11;
STATE_SEED_SELECTION = 12;
STATE_MAKE_SHOP = 13;
STATE_PLAYER_COUNT_SELECTION = 14;
PHASE_PARTY = 1;
PHASE_SHOP = 2;
PHASE_BUSTED = 3;
PHASE_SCORING = 4;
INFO_Y = 136;
MESSAGE_Y = 192;
LINE_SPACE = 8;
NUM_DAYS = 25;
POP_MAX = 80;
POP_2P_BONUS = 0;
MONEY_MAX = 40;
MONEY_2P_BONUS = 0;
START_CAPACITY = 5;
DEBT_PENALTY = 7;
TROUBLE_THRESHOLD = 3;
if (global.numPlayers == 1)
{
    PRESTIGE_GOAL = 4;
}
else
{
    PRESTIGE_GOAL = 3;
}
STORE_SUPPLY_1P = 4;
STORE_SUPPLY_2P = 6;
if (global.numPlayers == 1)
{
    STORE_SUPPLY = STORE_SUPPLY_1P;
}
if (global.numPlayers == 2)
{
    STORE_SUPPLY = STORE_SUPPLY_2P;
}
PROBATION_TIME = 1;
ROLODEX_PAGE_MAX = 36;
CAPACITY_MAX = 34;
MAX_EXPAND_COST = 12;
PRICE_DROP_DAY_2P = 10;
PRICE_DROP_AMOUNT_2P = 2;
PRICE_DROP_ON_2P = false;
PRICE_DROP_DAY_1P = 4;
PRICE_DROP_AMOUNT_1P = 0.1;
PRICE_DROP_ON_1P = true;
CHAR_DIVIDER = 0;
CHAR_DIVIDER_BANNED = 0.1;
CHAR_ROLODEX_EXIT = 0.2;
CHAR_EXPAND = 0.5;
CHAR_COOL_BUDDY_M = 1;
CHAR_COOL_BUDDY_M_2 = 2;
CHAR_COOL_BUDDY_F = 3;
CHAR_COOL_BUDDY_F_2 = 4;
CHAR_RICH_FRIEND_M = 5;
CHAR_RICH_FRIEND_F = 6;
CHAR_WILD_FRIEND_M = 7;
CHAR_WILD_FRIEND_F = 8;
CHAR_WILD_FRIEND_M_2 = 9;
CHAR_WILD_FRIEND_F_2 = 10;
CHAR_START = 11;
CHAR_DANCER = 11;
CHAR_HIPPY = 12;
CHAR_CUTE_DOG = 13;
CHAR_SECURITY = 14;
CHAR_WRESTLER = 15;
CHAR_DOG = 16;
CHAR_SPY = 17;
CHAR_DRIVER = 18;
CHAR_PRIVATE_I = 19;
CHAR_GRILLMASTER = 20;
CHAR_ATHLETE = 21;
CHAR_MR_POPULAR = 22;
CHAR_CELEBRITY = 23;
CHAR_COMEDIAN = 24;
CHAR_PHOTOGRAPHER = 25;
CHAR_CATERER = 26;
CHAR_TICKET_TAKER = 27;
CHAR_AUCTIONEER = 28;
CHAR_MONKEY = 29;
CHAR_ROCK_STAR = 30;
CHAR_GANGSTER = 31;
CHAR_GAMBLER = 32;
CHAR_WEREWOLF = 33;
CHAR_MASCOT = 34;
CHAR_INTROVERT = 35;
CHAR_COUNSELOR = 36;
CHAR_STYLIST = 37;
CHAR_BARTENDER = 38;
CHAR_WRITER = 39;
CHAR_CLIMBER = 40;
CHAR_CUPID = 41;
CHAR_MAGICIAN = 42;
CHAR_HOST = 43;
CHAR_CHEERLEADER = 44;
CHAR_END = 44;
CHAR_PRESTIGE_START = 50;
CHAR_ALIEN = 50;
CHAR_DINOSAUR = 51;
CHAR_LEPRECHAUN = 52;
CHAR_GENIE = 53;
CHAR_MERMAID = 54;
CHAR_DRAGON = 55;
CHAR_GHOST = 56;
CHAR_UNICORN = 57;
CHAR_SUPERHERO = 58;
CHAR_PRESTIGE_END = 58;
NUM_CHARACTERS = (CHAR_PRESTIGE_END - CHAR_PRESTIGE_START) + 1 + (CHAR_END - CHAR_START) + 1 + 3;
CHAR_THE_HOST = 59;
CHAR_DOG_W = 61;
CHAR_MAGICIAN_V = 62;
CHAR_DRIVER_P = 63;
CHAR_PRIVATE_I_P = 64;
CHAR_RITUALIST_A = 94;
CHAR_RITUALIST_B = 95;
CHAR_RITUALIST_S = 96;
CHAR_LIL_GUESTS = 97;
CHAR_PHOTO = 98;
CHAR_BOUNCE_TOP = 99;
CHERRY_GOAL = 5;
GARDEN_GOAL = 1;
scrLoadGame();
if (scenarioWins[5] < 0)
{
    scenarioWins[5] = 0;
}
var saveStatus = false;
scrOpenCurrFile();
saveStatus = scrReadSaveStatus();
scrCloseCurrFile();
if (!saveStatus)
{
    scrResetSpeedRun();
}
numPlayers = global.numPlayers;
cp = 0;
state = STATE_SCENARIO_SELECT;
prevState = state;
futureState = state;
stateTimer = 0;
substate = 0;
phase = PHASE_PARTY;
selectorX = 1;
selectorY = 0;
selOn = true;
selIndex = 1;
selCard = -4;
newCard = -4;
nextCard = -4;
nextNextCard = -4;
actionCard = -4;
flicker8 = false;
generalTimer = 0;
partyFullTimer = 0;
tSelector = 0;
tNewCard = 0;
tFetchNavi = 0;
messageColor = 16777215;
scr36_MessageSet("");
messageLines = 2;
for (var p = 0; p < 2; p++)
{
    deck[p] = ds_list_create();
}
draw_pile = ds_list_create();
party = ds_list_create();
store = ds_list_create();
rolodex = ds_list_create();
draw_pile_fetch = ds_list_create();
draw_pile_fetch_sort = ds_list_create();
booted = ds_list_create();
for (var i = 0; i < 6; i++)
{
    scenario[i] = ds_list_create();
}
cutChar = -4;
cutCharType = 0;
capacity[0] = START_CAPACITY;
capacity[1] = START_CAPACITY;
randSeed = 0;
currPrestige = 0;
depth = 10;
retryScenario = false;
soundStageSelect = sfx_select09;
soundNaviA = sfx_navi09;
soundNaviB = sfx_navi10;
soundNaviC = sfx_navi01;
soundNaviD = sfx_navi07;
soundNaviE = sfx_navi04;
soundSelectSpecial = sfx_switch02;
soundOpenFetch = sfx_jump06b;
soundNope = sfx_nope02;
soundCancel = sfx_deselect02;
soundDoorOpen = sfx_switch03;
soundBootOut = sfx_laser01;
soundPeek = sfx_special00;
soundBring = sfx_deposit00;
soundGoOutside = sfx_charge01;
soundPopular = sfx_collect01;
soundPhoto = sfx_camera00;
soundRefresh = sfx_boost01c;
soundPacify = sfx_special09;
soundMagicSwap = sfx_magic04;
soundMatchA = sfx_switch01;
soundMatchB = sfx_bounce01;
soundText = sfx_comm01;
soundWarning = sfx_warn04;
soundTransitionA = sfx_charge03;
soundTransitionB = sfx_transition01;
soundPopAdd = sfx_boost01a;
soundPopSub = sfx_decrease00;
soundMoneyAdd = sfx_coin01;
soundMoneySub = sfx_reverse00;
soundBonus = sfx_special08;
soundPurchase = sfx_select03;
soundExpand = sfx_upgrade01;
soundRandom = sfx_random00;
soundWerewolf = sfx_magic02;
soundWarnStreak[0] = sfx_select12a;
soundWarnStreak[1] = sfx_select12b;
soundWarnStreak[2] = sfx_select12c;
soundWarnStreak[3] = sfx_select12d;
soundWarnStreak[4] = sfx_select12e;
bgmParty[0] = bgm36_gameplayA;
bgmParty[1] = bgm36_gameplayB;
bgmParty[2] = bgm36_gameplayC;
bgmParty[3] = bgm36_gameplayD;
bgmTrig = false;
doorSoundBuffered = false;
doorSoundNegate = false;
scr36_AttractMode();
if (global.cheatID == 1)
{
    state = STATE_PLAYER_COUNT_SELECTION;
    futureState = state;
    prevState = state;
}
else if (global.cheatID == 2)
{
    state = STATE_PLAYER_COUNT_SELECTION;
    futureState = state;
    prevState = state;
}
debug = false;
