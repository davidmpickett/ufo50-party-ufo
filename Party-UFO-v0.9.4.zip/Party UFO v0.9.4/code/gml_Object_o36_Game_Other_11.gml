if (substate == 0)
{
    scrTransition(-1, 30, 0, -10, false);
    substate++;
}
if (substate == 1)
{
    if (scrTransitionDone())
    {
        scrSfx(soundText, 15);
        scr36_MessageSet("");
        if (numPlayers == 2 && time[0] != NUM_DAYS)
        {
            cp = !cp;
        }
        if (PRICE_DROP_ON_2P && numPlayers == 2 && time[cp] <= PRICE_DROP_DAY_2P && cp == 0)
        {
            for (i = 0; i < ds_list_size(store); i++)
            {
                var _thisChar = ds_list_find_value(store, i);
                if (verify(_thisChar) && _thisChar.prestige > 0)
                {
                    _thisChar.cost = max(12, _thisChar.cost - PRICE_DROP_AMOUNT_2P);
                }
            }
        }
        if (PRICE_DROP_ON_1P && numPlayers == 1 && time[cp] <= PRICE_DROP_DAY_1P)
        {
            for (i = 0; i < ds_list_size(store); i++)
            {
                var _thisChar = ds_list_find_value(store, i);
                if (_thisChar.type != CHAR_EXPAND)
                {
                    _thisChar.cost = max(2, round(_thisChar.cost - (_thisChar.cost * PRICE_DROP_AMOUNT_1P)));
                }
            }
        }
        messageColor = 16777215;
        if (numPlayers == 2)
        {
            if (time[cp] == NUM_DAYS)
            {
                var str = scrStringExt("get_started_2", cp + 1, 0, 0);
                str = string_copy(str, 1, 35);
                scr36_MessageSet(str);
            }
            else
            {
                var str = scrStringExt("another_party_2", cp + 1, 0, 0);
                str = string_copy(str, 1, 35);
                scr36_MessageSet(str);
            }
        }
        else if (time[cp] == NUM_DAYS)
        {
            scr36_MessageSet(scrString("get_started_1"));
        }
        else
        {
            scr36_MessageSet(scrString("another_party_1"));
        }
        scr36_RefreshCharActions(0);
        totalTrouble = 0;
        troubleWarnStreak = 0;
        selCard = -4;
        newCard = -4;
        actionCard = -4;
        nextCard = -4;
        nextNextCard = -4;
        greeting = false;
        currPrestige = 0;
        ds_list_clear(party);
        ds_list_clear(booted);
        ds_list_clear(draw_pile);
        scrShuffle(deck[cp]);
        ds_list_copy(draw_pile, deck[cp]);
        var i = ds_list_size(draw_pile) - 1;
        while (i >= 0)
        {
            if (ds_list_find_value(draw_pile, i).probation)
            {
                ds_list_find_value(draw_pile, i).probation--;
                if (ds_list_find_value(draw_pile, i).probation == 0)
                {
                    ds_list_find_value(draw_pile, i).wasOnProbation = true;
                }
                ds_list_add(booted, ds_list_find_value(draw_pile, i));
                ds_list_delete(draw_pile, i);
            }
            i--;
        }
        if (numPlayers == 1 && scenarioIndex == 5)
        {
            scenarioWins[5] = -abs(scenarioWins[5]);
            scrSaveGame(0);
        }
        phase = PHASE_PARTY;
        scr36_ChangeState(STATE_PARTY);
    }
}
