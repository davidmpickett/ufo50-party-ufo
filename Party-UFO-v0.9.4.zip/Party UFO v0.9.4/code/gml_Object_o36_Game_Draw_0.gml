var fire2width = scrGetInputIconWidth(cp, global.INP_FIRE2);
var fire1width = scrGetInputIconWidth(cp, global.INP_FIRE1);
if (state == STATE_SCENARIO_SELECT)
{
    draw_clear(0);
    draw_sprite(s36_ScenarioSelect, 0, 0, 0);
    draw_sprite(s36_ScenarioSelect, 1, 16 + (176 * scenarioX), 80 + (40 * scenarioY));
    for (var i = 0; i < 6; i++)
    {
        var xShift, yShift;
        if (i >= 3)
        {
            xShift = 176;
            yShift = 120;
        }
        else
        {
            xShift = 0;
            yShift = 0;
        }
        if (i != 5)
        {
            scrSetFont(global.fontTall);
            draw_set_color(16777215);
            draw_text(28 + xShift, (88 + (i * 40)) - yShift, string(i + 1));
            draw_text(56 + xShift, (88 + (i * 40)) - yShift, string(scenarioName[i]));
        }
        else
        {
            scrSetFont(global.fontTall);
            draw_set_color(16777215);
            draw_text(28 + xShift, (88 + (i * 40)) - yShift, "R");
            scrStringDrawExt(56 + xShift, (88 + (i * 40)) - yShift, "random_scenario", 0, 16, 0);
        }
        var bgColor;
        if (scenarioIndex == i)
        {
            draw_set_color(16777215);
            bgColor = global.palette[28];
        }
        else
        {
            draw_set_color(global.palette[28]);
            bgColor = global.palette[24];
        }
        if (numPlayers == 1)
        {
            if (i == 5)
            {
                scr36_DrawTextBG(56 + xShift, (104 + (i * 40)) - yShift, scrStringVal("curr_streak", scenarioWins[5]), bgColor, false);
            }
            else if (scenarioWins[i])
            {
                if (scenarioWins[i] > 9)
                {
                    scr36_DrawTextBG(56 + xShift, (104 + (i * 40)) - yShift, scrStringVal("won_days_1", scenarioWins[i]), bgColor, false);
                }
                else if (scenarioWins[i] > 1)
                {
                    scr36_DrawTextBG(56 + xShift, (104 + (i * 40)) - yShift, scrStringVal("won_days_2", scenarioWins[i]), bgColor, false);
                }
                else
                {
                    scr36_DrawTextBG(56 + xShift, (104 + (i * 40)) - yShift, scrStringVal("won_days_3", scenarioWins[i]), bgColor, false);
                }
            }
            else
            {
                scr36_DrawTextBG(56 + xShift, (104 + (i * 40)) - yShift, scrString("unbeaten"), bgColor, false);
            }
        }
        else
        {
            var metaStr;
            if (scenarioWinsP1[i] == 0 && scenarioWinsP2[i] == 0)
            {
                metaStr = scrStringExt("unplayed", 0, 16, 0);
            }
            else if (scenarioWinsP1[i] == 1)
            {
                metaStr = scrStringExt("p1_won_last_game", 0, 16, 0);
            }
            else if (scenarioWinsP1[i] > 1)
            {
                metaStr = scrStringExt("p1_won_last_x", scenarioWinsP1[i], 16, 0);
            }
            else if (scenarioWinsP2[i] == 1)
            {
                metaStr = scrStringExt("p2_won_last_game", 0, 16, 0);
            }
            else if (scenarioWinsP2[i] > 1)
            {
                metaStr = scrStringExt("p2_won_last_x", scenarioWinsP2[i], 16, 0);
            }
            scr36_DrawTextBG(56 + xShift, (104 + (i * 40)) - yShift, metaStr, bgColor, false);
        }
    }
    if (numPlayers == 1 && scenarioIndex == 5 && longestStreak > 0)
    {
        draw_set_color(16777215);
        scrSetFont(global.fontDefault);
        draw_text(232, 56, scrStringVal("best_streak", longestStreak));
    }
    for (var i = 0; i < ds_list_size(scenario[scenarioIndex]); i++)
    {
        var c = ds_list_find_value(scenario[scenarioIndex], i);
        if (numPlayers == 2 || scenarioIndex != 5)
        {
            draw_sprite(c.sprite_index, c.image_index, 32 + (24 * i), 24);
        }
        else
        {
            draw_sprite(s36_MysteryCharacter, 0, 32 + (24 * i), 24);
            scrSetFont(global.fontDefault);
            draw_set_color(16777215);
            draw_text(32 + (24 * i) + 12, 36, "?");
        }
    }
}
if (state != STATE_SCENARIO_SELECT && state != STATE_CREDITS && state != STATE_SEED_SELECTION && state != STATE_MAKE_SHOP && state != STATE_PLAYER_COUNT_SELECTION)
{
    scrSetFont(global.fontTall);
    draw_set_color(global.palette[3]);
    if (popularity[cp] < 10)
    {
        draw_text(336, 16, string(popularity[cp]));
    }
    else
    {
        draw_text(328, 16, string(popularity[cp]));
    }
    draw_set_color(global.palette[16]);
    draw_text(348, 16, "/");
    draw_text(360, 16, string(POP_MAX));
    draw_set_color(global.palette[11]);
    if (money[cp] < 0)
    {
        draw_set_color(global.palette[15]);
    }
    if (abs(money[cp]) < 10 && money[cp] >= 0)
    {
        draw_text(336, 48, string(money[cp]));
    }
    else if (money[cp] > -10)
    {
        draw_text(328, 48, string(money[cp]));
    }
    else if (money[cp] <= -10)
    {
        draw_text(320, 48, string(money[cp]));
    }
    draw_set_color(global.palette[16]);
    draw_text(348, 48, "/");
    draw_text(360, 48, string(MONEY_MAX));
    if (numPlayers == 1)
    {
        scrSetFont(global.fontTall);
        draw_set_color(global.palette[4]);
        draw_text(344, 80, string(time[cp]));
    }
    if (numPlayers == 2)
    {
        scrSetFont(global.fontTall);
        draw_set_color(global.palette[4]);
        draw_text(344, 80, "P" + string(cp + 1));
    }
    draw_sprite(s36_InfoBox, 0, 292, INFO_Y);
    for (var i = 0; i < PRESTIGE_GOAL; i++)
    {
        draw_sprite(s36_Icons, 32, 320 + (8 * i), 104);
    }
    for (var i = 0; i < min(PRESTIGE_GOAL, currPrestige); i++)
    {
        draw_sprite(s36_Icons, 22, 320 + (8 * i), 104);
    }
    if (verify(selCard))
    {
        draw_set_color(16777215);
        scrSetFont(global.fontTall);
        draw_text(295, INFO_Y - 16, string(selCard.name));
        scrSetFont(global.fontDefault);
        var lineY = INFO_Y + 8;
        if (selCard.troublemaker > 0)
        {
            draw_set_color(global.palette[15]);
            scrStringDraw(304, lineY, "troublemaker");
            lineY += LINE_SPACE;
        }
        if (selCard.peacekeeper > 0 && !selCard.werewolf)
        {
            draw_set_color(global.palette[0]);
            var str;
            str[0] = "CANCEL *";
            str[1] = "TROUBLE";
            for (var i = 0; i < min(4, array_length(str)); i++)
            {
                str[i] = string_replace_all(str[i], "*", string(selCard.peacekeeper));
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.bring == 1)
        {
            draw_set_color(global.palette[5]);
            var str;
            str[0] = "BRINGS *";
            str[1] = "GUEST";
            for (var i = 0; i < min(4, array_length(str)); i++)
            {
                str[i] = string_replace_all(str[i], "*", string(selCard.bring));
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
        else if (selCard.bring >= 2)
        {
            draw_set_color(global.palette[5]);
            var str;
            str[0] = "BRINGS *";
            str[1] = "GUESTS";
            for (var i = 0; i < min(4, array_length(str)); i++)
            {
                str[i] = string_replace_all(str[i], "*", string(selCard.bring));
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.bounce > 0)
        {
            draw_sprite_ext(sVirtualInputs, 7, 304, lineY, 1, 1, 0, global.palette[10], 1);
            draw_set_color(global.palette[10]);
            var str;
            str[0] = "*: PUSH";
            str[1] = "OUT 1";
            str[2] = "GUEST";
            for (var i = 0; i < min(5, array_length(str)); i++)
            {
                str[i] = string_replace_all(str[i], "*", " ");
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.stone > 0)
        {
            draw_sprite_ext(sVirtualInputs, 7, 304, lineY, 1, 1, 0, global.palette[16], 1);
            draw_set_color(global.palette[16]);
            var str;
            str[0] = "*: PUSH";
            str[1] = "OUT ALL";
            str[2] = "GUESTS";
            str[3] = "BELOW";
            for (var i = 0; i < min(5, array_length(str)); i++)
            {
                str[i] = string_replace_all(str[i], "*", " ");
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.arrow > 0)
        {
            draw_sprite_ext(sVirtualInputs, 7, 304, lineY, 1, 1, 0, global.palette[10], 1);
            draw_set_color(global.palette[10]);
            var str;
            str[0] = "*: PUSH";
            str[1] = "OUT ALL";
            str[2] = "GUESTS";
            str[3] = "TO RIGHT";
            for (var i = 0; i < min(5, array_length(str)); i++)
            {
                str[i] = string_replace_all(str[i], "*", " ");
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.bomb > 0)
        {
            draw_sprite_ext(sVirtualInputs, 7, 304, lineY, 1, 1, 0, global.palette[10], 1);
            draw_set_color(global.palette[10]);
            var str;
            str[0] = "*: PUSH";
            str[1] = "OUT ONE";
            str[2] = "GUEST";
            str[3] = "EACH WAY";
            for (var i = 0; i < min(5, array_length(str)); i++)
            {
                str[i] = string_replace_all(str[i], "*", " ");
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.full > 0)
        {
            draw_set_color(global.palette[3]);
            var str;
            str[0] = "+* POP";
            str[1] = "FOR EACH";
            str[2] = "1 POP";
            str[3] = "GUEST";
            for (var i = 0; i < min(5, array_length(str)); i++)
            {
                str[i] = string_replace_all(str[i], "*", string(selCard.full));
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.dancer > 0)
        {
            draw_sprite(s36_Icons, 14, 328, lineY);
            draw_set_color(global.palette[0]);
            draw_text(336, lineY, ": ");
            draw_set_color(global.palette[15]);
            draw_text(336, lineY, " -1");
            lineY += LINE_SPACE;
            draw_sprite(s36_Icons, 14, 320, lineY);
            draw_sprite(s36_Icons, 14, 328, lineY);
            draw_set_color(global.palette[0]);
            draw_text(336, lineY, ": ");
            draw_set_color(global.palette[11]);
            draw_text(336, lineY, " +4");
            lineY += LINE_SPACE;
            draw_sprite(s36_Icons, 14, 312, lineY);
            draw_sprite(s36_Icons, 14, 320, lineY);
            draw_sprite(s36_Icons, 14, 328, lineY);
            draw_set_color(global.palette[0]);
            draw_text(336, lineY, ": ");
            draw_set_color(global.palette[15]);
            draw_text(336, lineY, " -9");
            lineY += LINE_SPACE;
            draw_sprite(s36_Icons, 14, 304, lineY);
            draw_sprite(s36_Icons, 14, 312, lineY);
            draw_sprite(s36_Icons, 14, 320, lineY);
            draw_sprite(s36_Icons, 14, 328, lineY);
            draw_set_color(global.palette[0]);
            draw_text(336, lineY, ": ");
            draw_set_color(global.palette[11]);
            draw_text(336, lineY, " +16");
            lineY += LINE_SPACE;
        }
        if (selCard.peek > 0)
        {
            draw_sprite_ext(sVirtualInputs, 7, 304, lineY, 1, 1, 0, global.palette[13], 1);
            draw_set_color(global.palette[13]);
            var str;
            str[0] = "*: PEEK";
            str[1] = "AT NEXT ";
            str[2] = "2 GUESTS";
            for (var i = 0; i < min(5, array_length(str)); i++)
            {
                str[i] = string_replace_all(str[i], "*", " ");
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.copyfrog > 0)
        {
            draw_sprite_ext(sVirtualInputs, 7, 304, lineY, 1, 1, 0, global.palette[4], 1);
            draw_set_color(global.palette[4]);
            var str;
            str[0] = "*: COPY";
            str[1] = "STATS OF";
            str[2] = "NON-STAR";
            str[3] = "GUEST";
            for (var i = 0; i < min(5, array_length(str)); i++)
            {
                str[i] = string_replace_all(str[i], "*", " ");
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.werewolf > 0)
        {
            if (selCard.troublemaker)
            {
                draw_set_color(global.palette[15]);
            }
            else
            {
                draw_set_color(16777215);
            }
            var str;
            str[0] = "CANCEL 1";
            str[1] = "TROUBLE";
            str[2] = "EVERY";
            str[3] = "OTHER";
            str[4] = "ENTRANCE";
            for (var i = 0; i < min(5, array_length(str)); i++)
            {
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.banish > 0)
        {
            draw_sprite_ext(sVirtualInputs, 7, 304, lineY, 1, 1, 0, global.palette[9], 1);
            draw_set_color(global.palette[9]);
            var str;
            str[0] = "*: BOOT";
            str[1] = "1 GUEST";
            str[2] = "AND BAN";
            str[3] = "THEM FOR";
            str[4] = "1 PARTY";
            for (var i = 0; i < min(5, array_length(str)); i++)
            {
                str[i] = string_replace_all(str[i], "*", " ");
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.phone > 0)
        {
            draw_sprite_ext(sVirtualInputs, 7, 304, lineY, 1, 1, 0, global.palette[7], 1);
            draw_set_color(global.palette[7]);
            var str = scrStringSplit("fetch_action", 8, 0);
            for (var i = 0; i < min(4, array_length(str)); i++)
            {
                str[i] = string_replace_all(str[i], "*", " ");
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.reshuffle > 0)
        {
            draw_sprite_ext(sVirtualInputs, 7, 304, lineY, 1, 1, 0, global.palette[19], 1);
            draw_set_color(global.palette[19]);
            var str;
            str[0] = "*: MOVE";
            str[1] = "GUESTS";
            str[2] = "ON LEFT";
            str[3] = "OR RIGHT";
            str[4] = "OUTSIDE";
            for (var i = 0; i < min(5, array_length(str)); i++)
            {
                str[i] = string_replace_all(str[i], "*", " ");
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.photo > 0)
        {
            draw_sprite_ext(sVirtualInputs, 7, 304, lineY, 1, 1, 0, global.palette[4], 1);
            draw_set_color(global.palette[4]);
            var str;
            str[0] = "*: ADD";
            str[1] = "A STATIC";
            str[2] = "COPY OF";
            str[3] = "1 GUEST";
            str[4] = "& ";
            for (var i = 0; i < min(5, array_length(str)); i++)
            {
                str[i] = string_replace_all(str[i], "*", " ");
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
            draw_sprite(s36_Icons, 41, 316, lineY - 8);
        }
        if (selCard.matchmaker > 0)
        {
            draw_sprite_ext(sVirtualInputs, 7, 304, lineY, 1, 1, 0, global.palette[7], 1);
            draw_set_color(global.palette[7]);
            var str;
            str[0] = "*: MAKE";
            str[1] = "ADJACENT";
            str[2] = "GUESTS";
            str[3] = "SHRINK";
            for (var i = 0; i < min(6, array_length(str)); i++)
            {
                str[i] = string_replace_all(str[i], "*", " ");
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.upgrade > 0)
        {
            draw_sprite_ext(sVirtualInputs, 7, 304, lineY, 1, 1, 0, global.palette[9], 1);
            draw_set_color(global.palette[9]);
            var str;
            str[0] = "*: DRAIN";
            str[1] = "1 GUEST";
            str[2] = "OF 1 POP";
            for (var i = 0; i < min(5, array_length(str)); i++)
            {
                str[i] = string_replace_all(str[i], "*", " ");
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.bless > 0)
        {
            draw_sprite_ext(sVirtualInputs, 7, 304, lineY, 1, 1, 0, global.palette[14], 1);
            draw_set_color(global.palette[14]);
            var str;
            str[0] = "*: BLESS";
            str[1] = "A GUEST";
            str[2] = "FOR MORE";
            str[3] = "ACTIONS";
            for (var i = 0; i < min(5, array_length(str)); i++)
            {
                str[i] = string_replace_all(str[i], "*", " ");
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.magicSwap > 0)
        {
            draw_sprite_ext(sVirtualInputs, 7, 304, lineY, 1, 1, 0, global.palette[6], 1);
            draw_set_color(global.palette[6]);
            var str;
            str[0] = "*: FLIP";
            str[1] = "POP AND ";
            str[2] = "CASH OF ";
            str[3] = "1 GUEST ";
            for (var i = 0; i < min(5, array_length(str)); i++)
            {
                draw_text_with_sprites(304, lineY, str[i], -1, -1, s36_Icons, 22);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.schoolpride > 0)
        {
            draw_set_color(global.palette[21]);
            var str;
            str[0] = "FOR EACH";
            str[1] = "OPPIE +*";
            str[2] = "POP";
            for (var i = 0; i < min(5, array_length(str)); i++)
            {
                str[i] = string_replace_all(str[i], "*", string(selCard.schoolpride));
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.introvert > 0)
        {
            draw_sprite_ext(sVirtualInputs, 7, 304, lineY, 1, 1, 0, global.palette[10], 1);
            draw_set_color(global.palette[10]);
            var str;
            str[0] = "*: ADD";
            str[1] = "A GUEST";
            str[2] = "W/ 1 POP";
            str[3] = "& RANDOM";
            str[4] = "ABILITY";
            for (var i = 0; i < min(5, array_length(str)); i++)
            {
                draw_text_with_sprites(304, lineY, str[i], -1, -1, s36_Icons, 22);
                lineY += LINE_SPACE;
            }
            for (var i = 0; i < selCard.introvert; i++)
            {
                draw_sprite(s36_Icons, 37, 304 + (i * 8), lineY);
            }
            lineY += LINE_SPACE;
        }
        if (selCard.entranceBonus > 0)
        {
            draw_set_color(global.palette[11]);
            var str;
            str[0] = "EVERY ";
            str[1] = "ENTRANCE";
            str[2] = "ADDS 1 ";
            str[3] = "CASH. ";
            str[4] = "(MAX: 9)";
            for (var i = 0; i < min(6, array_length(str)); i++)
            {
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.troublePopBonus > 0)
        {
            draw_set_color(global.palette[3]);
            var str = scrStringSplit("trouble_pop", 8, 0);
            for (var i = 0; i < min(5, array_length(str)); i++)
            {
                str[i] = string_replace_all(str[i], "*", string(selCard.troublePopBonus));
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.troubleMoneyBonus > 0)
        {
            draw_set_color(global.palette[11]);
            var str = scrStringSplit("trouble_money", 8, 0);
            for (var i = 0; i < min(5, array_length(str)); i++)
            {
                str[i] = string_replace_all(str[i], "*", string(selCard.troubleMoneyBonus));
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.prestige > 0)
        {
            draw_set_color(global.palette[2]);
            var str;
            if (PRESTIGE_GOAL == 4)
            {
                str = scrStringSplit("prestige_2", 8, 0);
            }
            else
            {
                str = scrStringSplit("prestige_3", 8, 0);
            }
            for (var i = 0; i < min(3, array_length(str)); i++)
            {
                draw_text_with_sprites(304, lineY, str[i], s36_Icons, 22, -1, -1);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.popularity > 0)
        {
            draw_set_color(global.palette[3]);
            draw_text(304, lineY, scrStringExt("popularity", selCard.popularity, 8, 0));
            lineY += LINE_SPACE;
        }
        if (selCard.popularity < 0)
        {
            draw_set_color(global.palette[3]);
            draw_text(304, lineY, scrStringExt("popularity_negative", abs(selCard.popularity), 8, 0));
            lineY += LINE_SPACE;
        }
        if (selCard.money > 0)
        {
            draw_set_color(global.palette[11]);
            draw_text(304, lineY, scrStringExt("money_maker", selCard.money, 8, 0));
            lineY += LINE_SPACE;
        }
        if (selCard.money < 0)
        {
            draw_set_color(global.palette[11]);
            draw_text(304, lineY, scrStringExt("money_loser", abs(selCard.money), 8, 0));
            lineY += LINE_SPACE;
        }
        if (selCard.type == CHAR_DIVIDER)
        {
            draw_set_color(16777215);
            var str = scrStringSplit("divider_text_1", 8, 0);
            for (var i = 0; i < min(7, array_length(str)); i++)
            {
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.type == CHAR_DIVIDER_BANNED)
        {
            draw_set_color(16777215);
            var str = scrStringSplit("divider_text_2", 8, 0);
            for (var i = 0; i < min(7, array_length(str)); i++)
            {
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.type == CHAR_EXPAND)
        {
            draw_set_color(16777215);
            var str = scrStringSplit("expand_text", 8, 0);
            str[0] = "SPEND *";
            str[1] = "MONEY TO";
            str[2] = "EXPAND ";
            str[3] = "UFO.";
            for (var i = 0; i < min(7, array_length(str)); i++)
            {
                str[i] = string_replace_all(str[i], "*", string(selCard.moneyCost));
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
        if (selCard.type == CHAR_ROLODEX_EXIT)
        {
            draw_set_color(16777215);
            draw_sprite(s36_ButtonIcon, 1, 304, lineY);
            scrDrawTextInput(304, lineY, "[2]:", cp, 0, false);
            if (global.language != global.LANG_ENGLISH)
            {
                lineY += LINE_SPACE;
            }
            var str;
            str[0] = "CLOSE ";
            str[1] = "HOLODEX";
            for (var i = 0; i < min(5, array_length(str)); i++)
            {
                if (global.language != global.LANG_ENGLISH || i != 0)
                {
                    draw_text(304, lineY, str[i]);
                }
                else
                {
                    draw_text(312 + fire2width, lineY, str[i]);
                }
                lineY += LINE_SPACE;
            }
        }
        if (lineY == 135)
        {
            draw_set_color(16777215);
            var str = scrStringSplit("default_power", 8, 0);
            for (var i = 0; i < min(5, array_length(str)); i++)
            {
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
    }
    draw_set_color(0);
    draw_rectangle(292, 208, 379, 215, false);
    draw_set_color(messageColor);
    scrSetFont(global.fontDefault);
    var msg = scrMessageWrite(2);
    if (messageLines == 1)
    {
        msg = string_replace(msg, "*", "{0}");
        scrDrawTextInput(8, MESSAGE_Y, msg, cp, 0, 0);
    }
    else
    {
        draw_text_ext(8, MESSAGE_Y, msg, 8, 280);
    }
    if (state == STATE_LOSE && substate == 4)
    {
        scrStringDraw(16, MESSAGE_Y + 8, "retry_no");
        scrStringDraw(152, MESSAGE_Y + 8, "retry_yes");
        if (flicker8)
        {
            draw_sprite(s36_Icons, 33, 8 + (136 * answerX), MESSAGE_Y + 8);
        }
    }
}
if (state == STATE_START_PARTY || state == STATE_PARTY || (state == STATE_STORE && stateTimer <= 36) || state == STATE_LOSE || state == STATE_WIN || state == STATE_SCORE || state == STATE_BUSTED || (phase == PHASE_PARTY && state == STATE_ROLODEX && stateTimer <= 36) || state == STATE_FETCH)
{
    draw_sprite(s36_Headers, 2 + cp, 0, 0);
    draw_sprite_part(s36_House, 0, 0, 0, 288, 144, 0, 32);
    global.solutionState = false;
    if ((state == STATE_PARTY || state == STATE_FETCH) && prevState != STATE_BUSTED && substate != 5 && substate != 0)
    {
        if (totalTrouble == (TROUBLE_THRESHOLD - 1) && ds_list_size(party) <= capacity[cp])
        {
            if (cp == 0)
            {
                draw_sprite(s36_HeaderMeter1, floor(generalTimer / 16) % 4, 240, 0);
                global.solutionState = true;
            }
            else
            {
                draw_sprite(s36_HeaderMeter2, floor(generalTimer / 16) % 4, 240, 0);
                global.solutionState = false;
            }
        }
    }
    if (partyFullTimer)
    {
        partyFullTimer++;
        if ((partyFullTimer % 2) == 0)
        {
            var randX = scrQuantize(scrIRandomRange(0, 288), 8);
            var randY = scrQuantize(scrIRandomRange(32, 176), 8);
            scrFX(sFX_StarRotate, 0.2, randX, randY);
        }
    }
    if (instance_exists(o36_Door))
    {
        draw_sprite(s36_Door, o36_Door.image_index, 32, 32);
    }
    draw_sprite(s36_Rolodex, 0, 0, 32);
    for (var i = 0; i < 9; i++)
    {
        for (var j = 0; j < 5; j++)
        {
            if ((i + (9 * j)) > (capacity[cp] + 1))
            {
                draw_sprite_part(s36_House, 1, 32 * i, 32 * j, 32, 32, 32 * i, (32 * j) + 32);
            }
        }
    }
    if (state != STATE_START_PARTY)
    {
        if (state == STATE_PARTY && (substate == 4 || substate == 6 || (substate == 7 || substate == 8) || substate == 10 || substate == 11))
        {
            draw_set_alpha(0.5);
            draw_set_color(0);
            draw_rectangle(0, 0, 288, 176, false);
            draw_set_color(16777215);
            draw_set_alpha(1);
        }
        if (state == STATE_FETCH)
        {
            draw_set_alpha(0.5);
            draw_set_color(0);
            draw_rectangle(0, 0, 288, 176, false);
            draw_set_color(16777215);
            draw_set_alpha(1);
        }
        if (nextCard != -4)
        {
            if ((round(generalTimer / 16) % 2) == 0)
            {
                scr36_DrawCard(nextCard, 32, 32, 0, 1);
            }
        }
        if (nextNextCard != -4)
        {
            if ((round(generalTimer / 16) % 2) == 0)
            {
                scr36_DrawCard(nextNextCard, 0, 32, 0, 1);
            }
        }
        var xPos = 2;
        var yPos = 1;
        for (var i = 0; i < ds_list_size(party); i++)
        {
            var currCard = ds_list_find_value(party, i);
            var yOffset = 0;
            if (i == 0 && tNewCard > 0)
            {
                yOffset = -1;
            }
            scr36_DrawCard(currCard, 32 * xPos, 32 * yPos, yOffset, 0);
            xPos++;
            if (xPos > 8)
            {
                xPos = 0;
                yPos++;
            }
        }
    }
    if (selOn)
    {
        if (state == STATE_FETCH)
        {
            scr36_DrawSelector(7, ds_list_find_value(party, selIndex), 32 * selectorX, (32 * selectorY) + 32);
        }
        else if (substate == 4)
        {
            scr36_DrawSelector(1, selCard, 32 * selectorX, (32 * selectorY) + 32);
        }
        else if (substate == 6 || substate == 15)
        {
            scr36_DrawSelector(2, selCard, 32 * selectorX, (32 * selectorY) + 32);
        }
        else if (substate == 7)
        {
            scr36_DrawSelector(3, selCard, 32 * selectorX, (32 * selectorY) + 32);
        }
        else if (substate == 8)
        {
            scr36_DrawSelector(3, matchCard, 32 * matchX, (32 * matchY) + 32);
            scr36_DrawSelector(4, selCard, 32 * selectorX, (32 * selectorY) + 32);
        }
        else if (substate == 9)
        {
            scr36_DrawSelector(5, selCard, 32 * selectorX, (32 * selectorY) + 32);
        }
        else if (substate == 10 || substate == 13)
        {
            scr36_DrawSelector(4, selCard, 32 * selectorX, (32 * selectorY) + 32);
        }
        else if (substate == 11)
        {
            scr36_DrawSelector(5, selCard, 32 * selectorX, (32 * selectorY) + 32);
        }
        else if (substate == 12)
        {
            scr36_DrawSelector(8, selCard, 32 * selectorX, (32 * selectorY) + 32);
        }
        else if (substate == 14)
        {
            scr36_DrawSelector(9, selCard, 32 * selectorX, (32 * selectorY) + 32);
        }
        else
        {
            scr36_DrawSelector(0, selCard, 32 * selectorX, (32 * selectorY) + 32);
        }
    }
    if (selCard == -4 && state != STATE_ROLODEX && selOn)
    {
        if (selIndex == -1)
        {
            if (nextCard == -4)
            {
                draw_set_color(16777215);
                scrSetFont(global.fontTall);
                draw_text(295, INFO_Y - 16, "AIRLOCK");
                scrSetFont(global.fontDefault);
                draw_set_color(16777215);
                var lineY = INFO_Y + 8;
                scrDrawTextInput(304, lineY, "[2]:", cp, 0, false);
                if (global.language != global.LANG_ENGLISH)
                {
                    lineY += LINE_SPACE;
                }
                var str = scrStringSplit("door_text_2", 8, 0);
                for (var i = 0; i < min(2, array_length(str)); i++)
                {
                    if (global.language != global.LANG_ENGLISH || i != 0)
                    {
                        draw_text(304, lineY, str[i]);
                    }
                    else
                    {
                        draw_text(312 + fire2width, lineY, str[i]);
                    }
                    lineY += LINE_SPACE;
                }
                lineY += LINE_SPACE;
                scrDrawTextInput(304, lineY, "[1]:", cp, 0, false);
                if (global.language != global.LANG_ENGLISH)
                {
                    lineY += LINE_SPACE;
                }
                str = scrStringSplit("door_text_3", 8, 0);
                for (var i = 0; i < min(3, array_length(str)); i++)
                {
                    if (global.language != global.LANG_ENGLISH || i != 0)
                    {
                        draw_text(304, lineY, str[i]);
                    }
                    else
                    {
                        draw_text(312 + fire1width, lineY, str[i]);
                    }
                    lineY += LINE_SPACE;
                }
            }
            else if (nextNextCard == -4)
            {
                draw_set_color(16777215);
                scrSetFont(global.fontTall);
                draw_text(295, INFO_Y - 16, "AIRLOCK");
                scrSetFont(global.fontDefault);
                draw_set_color(16777215);
                var lineY = INFO_Y + 8;
                scrDrawTextInput(304, lineY, "[2]:", cp, 0, false);
                if (global.language != global.LANG_ENGLISH)
                {
                    lineY += LINE_SPACE;
                }
                var str = scrStringSplit("door_text_5", 8, 0);
                for (var i = 0; i < min(2, array_length(str)); i++)
                {
                    if (global.language != global.LANG_ENGLISH || i != 0)
                    {
                        draw_text(304, lineY, str[i]);
                    }
                    else
                    {
                        draw_text(312 + fire2width, lineY, str[i]);
                    }
                    lineY += LINE_SPACE;
                }
                lineY += LINE_SPACE;
                scrDrawTextInput(304, lineY, "[1]:", cp, 0, false);
                if (global.language != global.LANG_ENGLISH)
                {
                    lineY += LINE_SPACE;
                }
                str = scrStringSplit("door_text_4", 8, 0);
                for (var i = 0; i < min(3, array_length(str)); i++)
                {
                    if (global.language != global.LANG_ENGLISH || i != 0)
                    {
                        draw_text(304, lineY, str[i]);
                    }
                    else
                    {
                        draw_text(312 + fire1width, lineY, str[i]);
                    }
                    lineY += LINE_SPACE;
                }
            }
            else
            {
                draw_set_color(16777215);
                scrSetFont(global.fontTall);
                draw_text(295, INFO_Y - 16, "AIRLOCK");
                scrSetFont(global.fontDefault);
                draw_set_color(16777215);
                var lineY = INFO_Y + 8;
                scrDrawTextInput(304, lineY, "[2]:", cp, 0, false);
                if (global.language != global.LANG_ENGLISH)
                {
                    lineY += LINE_SPACE;
                }
                var str = scrStringSplit("door_text_5", 8, 0);
                for (var i = 0; i < min(2, array_length(str)); i++)
                {
                    if (global.language != global.LANG_ENGLISH || i != 0)
                    {
                        draw_text(304, lineY, str[i]);
                    }
                    else
                    {
                        draw_text(312 + fire2width, lineY, str[i]);
                    }
                    lineY += LINE_SPACE;
                }
                lineY += LINE_SPACE;
                scrDrawTextInput(304, lineY, "[1]:", cp, 0, false);
                if (global.language != global.LANG_ENGLISH)
                {
                    lineY += LINE_SPACE;
                }
                str[0] = "BOOT 2";
                for (var i = 0; i < min(3, array_length(str)); i++)
                {
                    if (global.language != global.LANG_ENGLISH || i != 0)
                    {
                        draw_text(304, lineY, str[i]);
                    }
                    else
                    {
                        draw_text(312 + fire1width, lineY, str[i]);
                    }
                    lineY += LINE_SPACE;
                }
            }
        }
        else if (selIndex == -2)
        {
            draw_set_color(16777215);
            scrSetFont(global.fontTall);
            draw_text(295, INFO_Y - 16, "HOLODEX");
            scrSetFont(global.fontDefault);
            draw_set_color(16777215);
            var lineY = INFO_Y + 8;
            scrDrawTextInput(304, lineY, "[2]:", cp, 0, false);
            if (global.language != global.LANG_ENGLISH)
            {
                lineY += LINE_SPACE;
            }
            var str = scrStringSplit("rolodex_text_2", 8, 0);
            for (var i = 0; i < min(5, array_length(str)); i++)
            {
                if (global.language != global.LANG_ENGLISH || i != 0)
                {
                    draw_text(304, lineY, str[i]);
                }
                else
                {
                    draw_text(312 + fire2width, lineY, str[i]);
                }
                lineY += LINE_SPACE;
            }
        }
        else
        {
            draw_set_color(16777215);
            scrSetFont(global.fontTall);
            scrStringDraw(295, INFO_Y - 16, "empty_text_1");
            scrSetFont(global.fontDefault);
            draw_set_color(16777215);
            var lineY = INFO_Y + 8;
            var str = scrStringSplit("empty_text_2", 8, 0);
            for (var i = 0; i < min(5, array_length(str)); i++)
            {
                draw_text(304, lineY, str[i]);
                lineY += LINE_SPACE;
            }
        }
    }
}
if (state == STATE_FETCH)
{
    if (tFetchNavi < 0)
    {
        draw_sprite(s36_Fetch, 1, 96, 48);
    }
    else if (tFetchNavi > 0)
    {
        draw_sprite(s36_Fetch, 2, 96, 48);
    }
    else
    {
        draw_sprite(s36_Fetch, 0, 96, 48);
    }
    scr36_DrawCard(selCard, 128, 80, 0, 0);
    draw_sprite(s36_Icons, 15, 90, 66);
}
if (state == STATE_BUSTED)
{
    if (ds_list_size(party) <= capacity[cp])
    {
        draw_sprite(s36_CopsShowUp, 0, 144, 108);
    }
    else
    {
        draw_sprite(s36_Overflowed, 0, 144, 108);
    }
}
if (state == STATE_STORE || (phase == PHASE_SHOP && state == STATE_ROLODEX && stateTimer <= 36))
{
    if (stateTimer <= 36 && (prevState == STATE_SCORE || prevState == STATE_PARTY))
    {
        for (var i = 1; i < 10; i++)
        {
            for (var j = 0; j < 6; j++)
            {
                if (j == 0)
                {
                    draw_set_color(global.palette[24]);
                }
                else
                {
                    draw_set_color(global.palette[28]);
                }
                if (j < 5)
                {
                    draw_rectangle((32 * i) - stateTimer - 1, (32 * j) - 1, (32 * i) - 1, (32 * (j + 1)) - 1, false);
                }
                else
                {
                    draw_rectangle((32 * i) - stateTimer - 1, (32 * j) - 1, (32 * i) - 1, (32 * (j + 0.5)) - 1, false);
                }
            }
        }
    }
    else
    {
        draw_set_color(global.palette[28]);
        draw_rectangle(0, 0, 287, 175, false);
        draw_sprite(s36_Headers, 1, 0, 0);
        scrSetFont(global.fontTall);
        draw_set_color(16777215);
        if (scenarioIndex != 5 || global.cheatID == 2)
        {
            scrStringDraw(56, 8, "store_header");
        }
        else
        {
            var seedString;
            if (randSeed < 10)
            {
                seedString = "00000" + string(randSeed);
            }
            else if (randSeed < 100)
            {
                seedString = "0000" + string(randSeed);
            }
            else if (randSeed < 1000)
            {
                seedString = "000" + string(randSeed);
            }
            else if (randSeed < 10000)
            {
                seedString = "00" + string(randSeed);
            }
            else if (randSeed < 100000)
            {
                seedString = "0" + string(randSeed);
            }
            else
            {
                seedString = string(randSeed);
            }
            scrStringDrawVal(56, 8, "scenario_x", seedString);
        }
        if (PRICE_DROP_ON_1P && numPlayers == 1 && time[cp] == (PRICE_DROP_DAY_1P - 1) && stateTimer > 36 && stateTimer <= 276)
        {
            draw_sprite(s36_SaleAlert, 0, 144, 108);
        }
        else
        {
            scrSetFont(global.fontDefault);
            var xPos = 0;
            var yPos = 1;
            for (var i = 0; i < ds_list_size(store); i++)
            {
                var currCard = ds_list_find_value(store, i);
                scr36_DrawCard(currCard, 32 * xPos, 32 * yPos, 0, 0);
                if (currCard.type == CHAR_EXPAND && capacity[cp] == CAPACITY_MAX)
                {
                    draw_sprite(s36_StoreBox, 0, 32 * xPos, (32 * yPos) + 32);
                }
                else if (currCard.supply <= STORE_SUPPLY)
                {
                    draw_sprite(s36_StoreBox, currCard.supply, 32 * xPos, (32 * yPos) + 32);
                }
                else
                {
                    draw_sprite(s36_StoreBox, 7, 32 * xPos, (32 * yPos) + 32);
                }
                if (currCard.supply > 0)
                {
                    if (currCard.cost > 0)
                    {
                        if (popularity[cp] >= currCard.cost)
                        {
                            draw_set_color(global.palette[3]);
                        }
                        else
                        {
                            draw_set_color(global.palette[16]);
                        }
                        scrSetFont(global.fontTall);
                        if (currCard.cost < 10)
                        {
                            draw_text((32 * xPos) + 12, (32 * yPos) + 36, string(currCard.cost));
                        }
                        else
                        {
                            draw_text((32 * xPos) + 8, (32 * yPos) + 36, string(currCard.cost));
                        }
                        if (currCard.cost < currCard.maxcost)
                        {
                            draw_sprite(s36_Icons, 35, 32 * xPos, (32 * yPos) + 32);
                        }
                    }
                    else if (currCard.moneyCost > 0)
                    {
                        if (money[cp] >= currCard.moneyCost)
                        {
                            draw_set_color(global.palette[14]);
                            currCard.image_speed = 0.05;
                        }
                        else
                        {
                            draw_set_color(global.palette[16]);
                            currCard.image_speed = 0;
                            currCard.image_index = 0;
                        }
                        scrSetFont(global.fontTall);
                        if (currCard.moneyCost < 10)
                        {
                            draw_text((32 * xPos) + 8, (32 * yPos) + 36, "$" + string(currCard.moneyCost));
                        }
                        else
                        {
                            draw_text((32 * xPos) + 4, (32 * yPos) + 36, "$" + string(currCard.moneyCost));
                        }
                    }
                }
                xPos++;
                if (xPos > 8)
                {
                    xPos = 0;
                    yPos += 2;
                }
            }
            draw_sprite(s36_Icons, 4, 32 * xPos, 32 * yPos);
            if (PRICE_DROP_ON_1P && numPlayers == 1 && time[cp] <= (PRICE_DROP_DAY_1P - 1))
            {
                draw_sprite(s36_SaleIcon, 0, 234, 132);
                draw_sprite(s36_Icons, 35, 32 * xPos, (32 * yPos) + 32);
            }
            draw_set_color(16777215);
            scrSetFont(global.fontDefault);
            if (ds_list_size(deck[cp]) < 10)
            {
                scr36_DrawTextBG((32 * xPos) + 16, (32 * yPos) + 24, string(ds_list_size(deck[cp])), 0, true);
            }
            else
            {
                scr36_DrawTextBG((32 * xPos) + 8, (32 * yPos) + 24, string(ds_list_size(deck[cp])), 0, true);
            }
            xPos++;
            if (xPos > 8)
            {
                xPos = 0;
                yPos += 2;
            }
            draw_sprite(s36_Icons, 5, 32 * xPos, 32 * yPos);
            if (selOn)
            {
                scr36_DrawSelector(0, selCard, 32 * selectorX, (64 * selectorY) + 32);
            }
            if (!selCard)
            {
                if (selIndex == ds_list_size(store))
                {
                    draw_set_color(16777215);
                    scrSetFont(global.fontTall);
                    draw_text(295, INFO_Y - 16, "HOLODEX");
                    scrSetFont(global.fontDefault);
                    draw_set_color(16777215);
                    var lineY = INFO_Y + 8;
                    scrDrawTextInput(304, lineY, "[2]:", cp, 0, false);
                    if (global.language != global.LANG_ENGLISH)
                    {
                        lineY += LINE_SPACE;
                    }
                    var str = scrStringSplit("rolodex_text_2", 8, 0);
                    for (var i = 0; i < min(5, array_length(str)); i++)
                    {
                        if (global.language != global.LANG_ENGLISH || i != 0)
                        {
                            draw_text(304, lineY, str[i]);
                        }
                        else
                        {
                            draw_text(312 + fire2width, lineY, str[i]);
                        }
                        lineY += LINE_SPACE;
                    }
                }
                else if (selIndex == (ds_list_size(store) + 1))
                {
                    draw_set_color(16777215);
                    scrSetFont(global.fontTall);
                    scrStringDraw(295, INFO_Y - 16, "done_text_1");
                    scrSetFont(global.fontDefault);
                    draw_set_color(16777215);
                    var lineY = INFO_Y + 8;
                    scrDrawTextInput(304, lineY, "[2]:", cp, 0, false);
                    if (global.language != global.LANG_ENGLISH)
                    {
                        lineY += LINE_SPACE;
                    }
                    var str = scrStringSplit("done_text_2", 8, 0);
                    for (var i = 0; i < min(5, array_length(str)); i++)
                    {
                        if (global.language != global.LANG_ENGLISH || i != 0)
                        {
                            draw_text(304, lineY, str[i]);
                        }
                        else
                        {
                            draw_text(312 + fire2width, lineY, str[i]);
                        }
                        lineY += LINE_SPACE;
                    }
                }
            }
        }
    }
}
if (state == STATE_ROLODEX)
{
    if (substate == 1 && stateTimer <= 32)
    {
        for (var i = 0; i < 9; i++)
        {
            for (var j = 1; j < 7; j++)
            {
                draw_set_color(0);
                draw_rectangle((32 * i) - 1, (32 * j) - stateTimer - 1, (32 * (i + 1)) - 1, (32 * j) - 1, false);
            }
        }
    }
    else
    {
        draw_set_color(global.palette[28]);
        draw_rectangle(0, 0, 287, 175, false);
        draw_sprite(s36_Headers, 0, 0, 0);
        scrSetFont(global.fontTall);
        draw_set_color(16777215);
        scrStringDrawExt(56, 8, "rolodex_header", 0, 12, 0);
        scrSetFont(global.fontDefault);
        draw_set_color(16777215);
        scrSetFont(global.fontDefault);
        draw_text(168, 16, string(ds_list_size(deck[cp])));
        var xPos = 0;
        var yPos = 1;
        var startPos = pageY * 9;
        var endPos = (pageY * 9) + ROLODEX_PAGE_MAX;
        if (endPos > ds_list_size(rolodex))
        {
            endPos = ds_list_size(rolodex);
        }
        for (var i = startPos; i < endPos; i++)
        {
            var currCard = ds_list_find_value(rolodex, i);
            scr36_DrawCard(currCard, 32 * xPos, 32 * yPos, 0, 0);
            xPos++;
            if (xPos > 8)
            {
                xPos = 0;
                yPos++;
            }
        }
        if (selOn)
        {
            scr36_DrawSelector(0, selCard, 32 * selectorX, ((32 * selectorY) + 32) - (pageY * 32));
        }
        if (flicker8 && ds_list_size(rolodex) >= ROLODEX_PAGE_MAX && ((pageY * 9) + ROLODEX_PAGE_MAX) < ds_list_size(rolodex))
        {
            draw_sprite(s36_Icons, 0, 128, 160);
        }
        if (substate == 3 || futureState == STATE_PARTY || futureState == STATE_STORE)
        {
            draw_rectangle_color(0, 0, 288, 176, 0, 0, 0, 0, 0);
        }
    }
}
if (state == STATE_CREDITS)
{
    scrFillScreen(0);
    draw_set_color(global.palette[28]);
    draw_rectangle(0, 0, global.SCREEN_WIDTH / 2, global.SCREEN_HEIGHT, false);
    if (verify(cutChar))
    {
        draw_sprite(cutChar.sprite_index, cutChar.image_index, 80, 72);
        scrSetFont(global.fontTall);
        draw_set_color(global.palette[14]);
        scrDrawTextCenteredPoint(string(cutChar.name), 96, 120, 8);
    }
}
if (state == STATE_SEED_SELECTION)
{
    scrFillScreen(0);
    scrFontDefault();
    draw_text_ce(192, 80, scrString("scenario_code"), 4);
    scrSetFont(global.fontTall);
    for (var i = 0; i < 6; i++)
    {
        if (digitSel == i)
        {
            if ((floor(stateTimer / 12) % 2) == 0)
            {
                draw_text(168 + (8 * i), 96, string(digit[i]));
            }
        }
        else
        {
            draw_text(168 + (8 * i), 96, string(digit[i]));
        }
    }
}
if (state == STATE_MAKE_SHOP && substate == 2)
{
    scrFillScreen(global.palette[28]);
    scrFontDefault();
    for (var i = 0; i < 14; i++)
    {
        if (i == 13)
        {
            if (customSel == i)
            {
                draw_sprite(s36_Icons, 5, 80 + (32 * (i % 7)), (64 + (48 * (i >= 7))) - 8);
            }
            else
            {
                draw_sprite(s36_Icons, 5, 80 + (32 * (i % 7)), 64 + (48 * (i >= 7)));
            }
        }
        else
        {
            var currCard = customCard[i];
            if (customSel == i)
            {
                scr36_DrawCard(currCard, 80 + (32 * (i % 7)), (64 + (48 * (i >= 7))) - 8, 0, 0);
            }
            else
            {
                scr36_DrawCard(currCard, 80 + (32 * (i % 7)), 64 + (48 * (i >= 7)), 0, 0);
            }
        }
    }
    draw_set_color(16777215);
    scrDrawTextInput(192, 192, scrStringVal("hold_to_randomize", "[1"), 0, 0, 1);
}
if (state == STATE_PLAYER_COUNT_SELECTION)
{
    scrFillScreen(0);
    scrSetFont(global.fontTall);
    draw_text_ce(192, 88, "< " + scrString("player_count_" + string(numPlayers)) + " >", 4);
}
