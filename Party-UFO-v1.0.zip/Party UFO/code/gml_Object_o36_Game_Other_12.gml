if (substate == 0)
{
    substate = 1;
    if (prevState == STATE_ROLODEX)
    {
        selectorX = 0;
        selectorY = 0;
    }
    else if (prevState == STATE_START_PARTY)
    {
        selectorX = 1;
        selectorY = 0;
    }
    else if (prevState == STATE_BUSTED)
    {
        selectorX = 2;
        selectorY = 0;
        substate = 4;
    }
    bringCounter = 0;
    currPrestige = scr36_GetPrestige();
}
if (substate == 1 || substate == 4 || substate == 6 || substate == 7 || substate == 8 || substate == 10 || substate == 11 || substate == 12 || substate == 13 || substate == 14 || substate == 15)
{
    selOn = true;
    var moved;
    if (substate == 1)
    {
        moved = scr36_HandleMovement(0, capacity[cp] + 2);
    }
    else
    {
        moved = scr36_HandleMovement(2, ds_list_size(party) + 2);
    }
    if (moved)
    {
        if (substate == 1)
        {
            scrSfx(soundNaviA, 10);
        }
        else
        {
            scrSfx(soundNaviD, 10);
        }
    }
    selIndex = scr36_GetIndex(selectorX, selectorY, 2);
    if (selIndex >= 0 && selIndex < ds_list_size(party))
    {
        selCard = ds_list_find_value(party, selIndex);
    }
    else
    {
        selCard = -4;
    }
    if (moved && nextCard != -4)
    {
        if (selIndex == -1)
        {
            messageColor = 16777215;
            scr36_MessageSet(scrStringVal("let_in", string(nextCard.name)));
        }
        else
        {
            scr36_MessageSet("");
        }
    }
}
if (doorSoundBuffered)
{
    scrSfx(soundDoorOpen, 40);
    doorSoundBuffered = false;
}
if (substate == 1)
{
    if (debug)
    {
        debug = false;
        selIndex = -1;
        scr36_LuckPushingAI();
    }
    if (selIndex >= 0 && selCard != -4)
    {
        if (selCard.tiny)
        {
            selCard.tinyActions = 0;
            selCard.tinyList = 0;
            if (selCard.bounce)
            {
                selCard.tinyList[selCard.tinyActions] = "bounce";
                selCard.tinyActions++;
            }
            if (selCard.photo)
            {
                selCard.tinyList[selCard.tinyActions] = "photo";
                selCard.tinyActions++;
            }
            if (selCard.upgrade)
            {
                selCard.tinyList[selCard.tinyActions] = "upgrade";
                selCard.tinyActions++;
            }
            if (selCard.magicSwap)
            {
                selCard.tinyList[selCard.tinyActions] = "magicSwap";
                selCard.tinyActions++;
            }
            if (selCard.reshuffle)
            {
                selCard.tinyList[selCard.tinyActions] = "reshuffle";
                selCard.tinyActions++;
            }
            if (selCard.bless)
            {
                selCard.tinyList[selCard.tinyActions] = "bless";
                selCard.tinyActions++;
            }
            if (selCard.introvert)
            {
                selCard.tinyList[selCard.tinyActions] = "introvert";
                selCard.tinyActions++;
            }
            if (selCard.phone)
            {
                selCard.tinyList[selCard.tinyActions] = "phone";
                selCard.tinyActions++;
            }
            if (selCard.peek)
            {
                selCard.tinyList[selCard.tinyActions] = "peek";
                selCard.tinyActions++;
            }
            if (selCard.banish)
            {
                selCard.tinyList[selCard.tinyActions] = "banish";
                selCard.tinyActions++;
            }
            if (selCard.matchmaker)
            {
                selCard.tinyList[selCard.tinyActions] = "matchmaker";
                selCard.tinyActions++;
            }
            if (selCard.copyfrog)
            {
                selCard.tinyList[selCard.tinyActions] = "copyfrog";
                selCard.tinyActions++;
            }
            if (selCard.stone)
            {
                selCard.tinyList[selCard.tinyActions] = "stone";
                selCard.tinyActions++;
            }
            if (selCard.arrow)
            {
                selCard.tinyList[selCard.tinyActions] = "arrow";
                selCard.tinyActions++;
            }
            if (selCard.bomb)
            {
                selCard.tinyList[selCard.tinyActions] = "bomb";
                selCard.tinyActions++;
            }
        }
        else if (selCard.stone)
        {
            if ((ds_list_size(party) - 1) >= (selIndex + 9))
            {
                ds_list_find_value(party, selIndex + 9).flickerTimer = 10;
                if ((ds_list_size(party) - 1) >= (selIndex + 18))
                {
                    ds_list_find_value(party, selIndex + 18).flickerTimer = 10;
                    if ((ds_list_size(party) - 1) >= (selIndex + 27))
                    {
                        ds_list_find_value(party, selIndex + 27).flickerTimer = 10;
                    }
                }
            }
        }
        else if (selCard.arrow)
        {
            arrowRow = 0;
            if (selIndex < 6)
            {
                arrowRow = 1;
                for (var i = 1; i <= (6 - selIndex); i++)
                {
                    if ((selIndex + i) < ds_list_size(party))
                    {
                        ds_list_find_value(party, selIndex + i).flickerTimer = 10;
                    }
                }
            }
            else if (selIndex < 15 && selIndex > 6)
            {
                arrowRow = 2;
                for (var i = 1; i <= (15 - selIndex); i++)
                {
                    if ((selIndex + i) < ds_list_size(party))
                    {
                        ds_list_find_value(party, selIndex + i).flickerTimer = 10;
                    }
                }
            }
            else if (selIndex < 24 && selIndex > 15)
            {
                arrowRow = 3;
                for (var i = 1; i <= (24 - selIndex); i++)
                {
                    if ((selIndex + i) < ds_list_size(party))
                    {
                        ds_list_find_value(party, selIndex + i).flickerTimer = 10;
                    }
                }
            }
            else if (selIndex < 33 && selIndex > 24)
            {
                arrowRow = 4;
                for (var i = 1; i <= (33 - selIndex); i++)
                {
                    if ((selIndex + i) < ds_list_size(party))
                    {
                        ds_list_find_value(party, selIndex + i).flickerTimer = 10;
                    }
                }
            }
            else if (selIndex == 6)
            {
                arrowRow = 1;
            }
            else if (selIndex == 15)
            {
                arrowRow = 2;
            }
            else if (selIndex == 24)
            {
                arrowRow = 3;
            }
            else if (selIndex == 33)
            {
                arrowRow = 4;
            }
        }
        else if (selCard.bomb)
        {
            bombTotal = 0;
            if ((selIndex - 9) >= 0)
            {
                bombUp = ds_list_find_value(party, selIndex - 9);
                bombUp.flickerTimer = 10;
                bombTotal++;
            }
            else
            {
                bombUp = false;
            }
            if ((selIndex + 9) <= (ds_list_size(party) - 1))
            {
                bombDown = ds_list_find_value(party, selIndex + 9);
                bombDown.flickerTimer = 10;
                bombTotal++;
            }
            else
            {
                bombDown = false;
            }
            if ((selIndex + 1) <= (ds_list_size(party) - 1) && selIndex != 6 && selIndex != 15 && selIndex != 24)
            {
                bombRight = ds_list_find_value(party, selIndex + 1);
                bombRight.flickerTimer = 10;
                bombTotal++;
            }
            else
            {
                bombRight = false;
            }
            if ((selIndex - 1) >= 0 && selIndex != 7 && selIndex != 16 && selIndex != 25)
            {
                bombLeft = ds_list_find_value(party, selIndex - 1);
                bombLeft.flickerTimer = 10;
                bombTotal++;
            }
            else
            {
                bombLeft = false;
            }
        }
    }
    if (fire2pressed && selIndex == -1)
    {
        if (!bgmTrig)
        {
            if (capacity[cp] < 8)
            {
                scrBGM(bgmParty[0]);
            }
            else if (capacity[cp] < 17)
            {
                scrBGM(bgmParty[1]);
            }
            else if (capacity[cp] < 26)
            {
                scrBGM(bgmParty[2]);
            }
            else
            {
                scrBGM(bgmParty[3]);
            }
            bgmTrig = true;
        }
        if (ds_list_size(party) < capacity[cp])
        {
            if (nextNextCard != -4)
            {
                nextCard = nextNextCard;
                nextNextCard = -4;
            }
            else
            {
                nextCard = -4;
            }
            with (o36_Door)
            {
                image_speed = 0.2;
            }
            substate = 2;
            with (o36_Card)
            {
                flickerActionTimer = 0;
            }
        }
        else
        {
            scrSfx(soundText, 15);
            messageColor = 16777215;
            scr36_MessageSet(scrString("no_room"));
        }
    }
    else if (fire1pressed && selIndex == -1)
    {
        if (nextCard != -4 && nextNextCard != -4)
        {
            scrSfx(soundBootOut, 50);
            messageColor = global.palette[13];
            scr36_MessageSet(nextCard.name + " & " + nextNextCard.name + " WERE SENT AWAY.");
            ds_list_delete(draw_pile, 1);
            ds_list_delete(draw_pile, 0);
            ds_list_add(booted, nextCard);
            ds_list_add(booted, nextNextCard);
            nextCard = -4;
            nextNextCard = -4;
        }
        else if (nextCard != -4)
        {
            scrSfx(soundBootOut, 50);
            messageColor = global.palette[13];
            scr36_MessageSet(nextCard.name + " WAS SENT AWAY.");
            ds_list_delete(draw_pile, 0);
            ds_list_add(booted, nextCard);
            nextCard = -4;
        }
        else if (ds_list_size(party) < 1 && ds_list_size(draw_pile) > 0)
        {
            scrSfx(soundText, 15);
            messageColor = global.palette[0];
            scr36_MessageSet(scrString("dont_end"));
        }
        else
        {
            scrBGM(bgm36P_stingPartyEndA, false);
            bgmTrig = false;
            with (o36_Card)
            {
                flickerActionTimer = 0;
            }
            nextCard = -4;
            nextNextCard = -4;
            messageColor = global.palette[0];
            scr36_MessageSet(scrString("ended_party"));
            scr36_ChangeState(STATE_SCORE);
            phase = PHASE_SCORING;
            exit;
        }
    }
    else if (fire2pressed && selIndex == -2)
    {
        scrSfx(soundTransitionA, 60);
        selOn = false;
        messageColor = global.palette[0];
        scr36_MessageSet("OPENING HOLODEX...");
        scr36_ChangeState(STATE_ROLODEX);
        exit;
    }
    else if (fire2pressed && selCard != -4 && selCard.tinyActions > 1)
    {
        mute(soundCancel);
        scrSfx(soundSelectSpecial, 20);
        with (o36_Card)
        {
            flickerActionTimer = 0;
        }
        messageColor = global.palette[0];
        scr36_MessageSet("CHOOSE AN ABILITY");
        actionCard = selCard;
        tinyIndex = 0;
        substate = 21;
    }
    else if (fire2pressed && selCard != -4 && selCard.tinyActions <= 1)
    {
        if (selCard.bounce)
        {
            mute(soundCancel);
            scrSfx(soundSelectSpecial, 20);
            tSelector = 3;
            actionIndex = selIndex;
            with (o36_Card)
            {
                flickerActionTimer = 0;
            }
            messageColor = global.palette[10];
            scr36_MessageSet("WHO DO YOU WANT TO PUSH OUT?");
            substate = 4;
            actionCard = selCard;
        }
        else if (selCard.photo)
        {
            if (ds_list_size(party) < capacity[cp])
            {
                mute(soundCancel);
                scrSfx(soundSelectSpecial, 20);
                with (o36_Card)
                {
                    flickerActionTimer = 0;
                }
                messageColor = global.palette[4];
                scr36_MessageSet(scrString("photograph"));
                substate = 6;
                actionCard = selCard;
            }
            else
            {
                messageColor = global.palette[4];
                scr36_MessageSet("NOT ENOUGH ROOM FOR A PHOTOSHOOT.");
            }
        }
        else if (selCard.matchmaker)
        {
            mute(soundCancel);
            scrSfx(soundSelectSpecial, 20);
            with (o36_Card)
            {
                flickerActionTimer = 0;
            }
            messageColor = global.palette[7];
            scr36_MessageSet("WHO WILL SHRINK TOGETHER?");
            substate = 7;
            actionCard = selCard;
        }
        else if (selCard.upgrade)
        {
            if (selCard.popularity < 9)
            {
                mute(soundCancel);
                scrSfx(soundSelectSpecial, 20);
                with (o36_Card)
                {
                    flickerActionTimer = 0;
                }
                messageColor = global.palette[9];
                scr36_MessageSet("WHO LOOKS TASTY?");
                substate = 10;
                actionCard = selCard;
            }
            else if (selCard.popularity >= 9)
            {
                scrSfx(soundText, 15);
                messageColor = global.palette[0];
                scr36_MessageSet(selCard.name + " HAS DRANK THEIR FILL OF POP");
            }
        }
        else if (selCard.magicSwap)
        {
            mute(soundCancel);
            scrSfx(soundSelectSpecial, 20);
            with (o36_Card)
            {
                flickerActionTimer = 0;
            }
            messageColor = global.palette[7];
            scr36_MessageSet("WHO WILL BE FLIPPED?");
            substate = 11;
            actionCard = selCard;
        }
        else if (selCard.reshuffle)
        {
            mute(soundCancel);
            scrSfx(soundSelectSpecial, 20);
            with (o36_Card)
            {
                flickerActionTimer = 0;
            }
            messageColor = global.palette[19];
            scr36_MessageSet("WHICH SIDE OF THE PARTY WILL GO OUTSIDE?");
            substate = 12;
            actionIndex = selIndex;
            actionCard = selCard;
        }
        else if (selCard.bless)
        {
            var actionsToBless = false;
            for (var i = 0; i < ds_list_size(party); i++)
            {
                if ((ds_list_find_value(party, i).bouncemax > 0 && ds_list_find_value(party, i).bounce < 4) || (ds_list_find_value(party, i).peekmax > 0 && ds_list_find_value(party, i).peek < 4) || (ds_list_find_value(party, i).phonemax > 0 && ds_list_find_value(party, i).phone < 4) || (ds_list_find_value(party, i).reshufflemax > 0 && ds_list_find_value(party, i).reshuffle < 4) || (ds_list_find_value(party, i).photomax > 0 && ds_list_find_value(party, i).photo < 4) || (ds_list_find_value(party, i).matchmakermax > 0 && ds_list_find_value(party, i).matchmaker < 4) || (ds_list_find_value(party, i).introvertmax > 0 && ds_list_find_value(party, i).introvert < 7) || (ds_list_find_value(party, i).upgrademax > 0 && ds_list_find_value(party, i).upgrade < 4) || (ds_list_find_value(party, i).magicSwapmax > 0 && ds_list_find_value(party, i).magicSwap < 4) || (ds_list_find_value(party, i).greetmax > 0 && ds_list_find_value(party, i).greet < 4) || (ds_list_find_value(party, i).banishmax > 0 && ds_list_find_value(party, i).banish < 4) || (ds_list_find_value(party, i).blessmax > 0 && ds_list_find_value(party, i).bless < 4))
                {
                    ds_list_find_value(party, i).flickerTimer = 128;
                    actionsToBless = true;
                }
            }
            if (actionsToBless)
            {
                mute(soundCancel);
                scrSfx(soundSelectSpecial, 20);
                messageColor = global.palette[14];
                scr36_MessageSet("WHICH SOUL SHALL YOU BLESS WITH BRONTOR'S GRACE?");
                substate = 14;
                actionCard = selCard;
            }
            else
            {
                scrSfx(soundText, 15);
                messageColor = global.palette[0];
                scr36_MessageSet("NO ACTIONS TO BLESS");
            }
        }
        else if (selCard.copyfrog)
        {
            mute(soundCancel);
            scrSfx(soundSelectSpecial, 20);
            messageColor = global.palette[2];
            scr36_MessageSet("WHICH GUEST WILL YOU COPY?");
            substate = 15;
            actionCard = selCard;
        }
        else if (selCard.introvert)
        {
            if (ds_list_size(party) < capacity[cp])
            {
                scrSfx(soundDoorOpen, 40);
                with (o36_Card)
                {
                    flickerActionTimer = 0;
                }
                selCard.introvert--;
                newType = scrChoose(CHAR_RITUALIST_A, CHAR_RITUALIST_S, CHAR_RITUALIST_B);
                nonCard = scr36_CreateCard(newType);
                ds_list_insert(party, selIndex + 1, nonCard);
                newCard = nonCard;
                substate = 9;
            }
            else if (ds_list_size(party) >= capacity[cp])
            {
                scrSfx(soundText, 15);
                messageColor = 16777215;
                scr36_MessageSet(scrString("no_room"));
            }
        }
        else if (selCard.phone)
        {
            if (ds_list_size(party) < capacity[cp] && !ds_list_empty(draw_pile))
            {
                mute(soundCancel);
                scrSfx(soundOpenFetch, 20);
                messageColor = global.palette[7];
                scr36_MessageSet(scrString("fetch_anyone"));
                scr36_ChangeState(STATE_FETCH);
                actionCard = selCard;
                exit;
            }
            else
            {
                scrSfx(soundText, 15);
                messageColor = 16777215;
                if (ds_list_size(party) >= capacity[cp])
                {
                    scr36_MessageSet(scrString("no_room"));
                }
                else
                {
                    scr36_MessageSet("NO ONE LEFT IN HOLODEX!");
                }
            }
        }
        else if (selCard.peek)
        {
            if (nextCard != -4)
            {
                scrSfx(soundText, 15);
                messageColor = global.palette[0];
                scr36_MessageSet("YOU ALREADY KNOW WHO'S AT THE AIRLOCK!");
            }
            else if (ds_list_empty(draw_pile))
            {
                scrSfx(soundText, 15);
                messageColor = global.palette[0];
                scr36_MessageSet("NO ONE LEFT IN HOLODEX!");
            }
            else if (ds_list_size(draw_pile) >= 2)
            {
                scrSfx(soundPeek, 50);
                selCard.peek--;
                nextCard = ds_list_find_value(draw_pile, 0);
                nextNextCard = ds_list_find_value(draw_pile, 1);
                messageColor = global.palette[13];
                scr36_MessageSet(nextCard.name + " & " + nextNextCard.name + " ARE HERE");
                actionCard = selCard;
            }
            else
            {
                scrSfx(soundPeek, 50);
                selCard.peek--;
                nextCard = ds_list_find_value(draw_pile, 0);
                messageColor = global.palette[13];
                scr36_MessageSet(nextCard.name + "IS AT THE AIRLOCK.");
                actionCard = selCard;
            }
        }
        else if (selCard.banish)
        {
            mute(soundCancel);
            scrSfx(soundSelectSpecial, 20);
            tSelector = 3;
            with (o36_Card)
            {
                flickerActionTimer = 0;
            }
            messageColor = global.palette[9];
            scr36_MessageSet("WHO WILL YOU BANISH TO THE NIGHT MANOR?");
            substate = 13;
            actionCard = selCard;
        }
        else if (selCard.stone)
        {
            if ((ds_list_size(party) - 1) >= (selIndex + 9))
            {
                mute(soundCancel);
                scrSfx(soundStone, 50);
                selCard.stone--;
                nonCard = scr36_CreateCard(CHAR_BOUNCE_TOP);
                nonCard.name = "STONE";
                if (selCard.type == CHAR_HOST)
                {
                    nonCard.sprite_index = s36_FrogStone;
                }
                else
                {
                    nonCard.sprite_index = s36_Stone;
                }
                ds_list_add(booted, ds_list_find_value(party, selIndex + 9));
                ds_list_delete(party, selIndex + 9);
                ds_list_insert(party, selIndex + 9, nonCard);
                selCard.visible = false;
                stateTimer = 0;
                previous = 9;
                substate = 16;
            }
            else
            {
                scrSfx(soundText, 15);
                messageColor = global.palette[0];
                scr36_MessageSet("NOONE TO CRUSH.");
            }
        }
        else if (selCard.arrow)
        {
            arrowMax = (arrowRow * 9) - 3;
            if (selIndex < arrowMax && selIndex < (ds_list_size(party) - 1))
            {
                mute(soundCancel);
                scrSfx(soundArrow, 50);
                selCard.arrow--;
                substate = 19;
            }
            else
            {
                scrSfx(soundText, 15);
                messageColor = global.palette[0];
                scr36_MessageSet("NOONE TO SHOOT.");
            }
        }
        else if (selCard.bomb)
        {
            if (!bombRight && !bombLeft && !bombDown && !bombUp)
            {
                scrSfx(soundText, 15);
                messageColor = global.palette[0];
                scr36_MessageSet("NOONE TO BOMB.");
            }
            else
            {
                mute(soundCancel);
                scrSfx(soundBomb, 50);
                selCard.bomb--;
                if (bombDown)
                {
                    ds_list_add(booted, bombDown);
                    ds_list_delete(party, selIndex + 9);
                }
                if (bombRight)
                {
                    ds_list_add(booted, bombRight);
                    ds_list_delete(party, selIndex + 1);
                }
                nonCard = scr36_CreateCard(CHAR_BOUNCE_TOP);
                nonCard.name = "BLAST";
                if (selCard.type == CHAR_HOST)
                {
                    nonCard.sprite_index = s36_FrogBlast;
                }
                else
                {
                    nonCard.sprite_index = s36_Blast;
                }
                ds_list_add(booted, selCard);
                ds_list_delete(party, selIndex);
                ds_list_insert(party, selIndex, nonCard);
                if (bombLeft)
                {
                    ds_list_add(booted, bombLeft);
                    ds_list_delete(party, selIndex - 1);
                }
                if (bombUp)
                {
                    ds_list_add(booted, bombUp);
                    ds_list_delete(party, selIndex - 9);
                }
                messageColor = global.palette[0];
                str = "* GUESTS WERE PUSHED OUT OF THE PARTY.";
                str = string_replace_all(str, "*", string(bombTotal));
                scr36_MessageSet(str);
                substate = 20;
            }
        }
        else
        {
            scrSfx(soundText, 15);
            messageColor = global.palette[0];
            scr36_MessageSet(scrString("this_person_no_action"), true);
        }
    }
    else if (fire2pressed)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        if (selectorX == 6 && selectorY == 2)
        {
            scr36_MessageSet("EGGPLANT IS A GREAT PODCAST.");
        }
        else
        {
            scr36_MessageSet(scrString("nothing_here"));
        }
    }
    else if (fire1pressed)
    {
        scrSfx(soundNaviA, 10);
        selectorX = 1;
        selectorY = 0;
        selIndex = scr36_GetIndex(selectorX, selectorY, 2);
    }
}
else if (substate == 4)
{
    if (phase == PHASE_BUSTED && (stateTimer++ < 60 || textMessagePos < textMessageLength))
    {
        selOn = false;
        nextCard = -4;
        nextNextCard = -4;
        exit;
    }
    selOn = true;
    if (fire1pressed && phase != PHASE_BUSTED)
    {
        mute(soundSelectSpecial);
        scrSfx(soundCancel, 5);
        scr36_MessageSet("");
        substate = 1;
    }
    else if (fire2pressed && selCard != -4)
    {
        if (phase == PHASE_PARTY)
        {
            if (selCard != actionCard)
            {
                scrSfx(soundBootOut, 50);
                bounceTop = scr36_CreateCard(CHAR_BOUNCE_TOP);
                if (actionIndex > selIndex)
                {
                    ds_list_insert(party, actionIndex, bounceTop);
                    ds_list_delete(party, selIndex);
                    actionCard.flopped = false;
                    actionCard.tinyFlopped1 = false;
                    actionCard.tinyFlopped2 = false;
                    bounceTop.flopped = false;
                }
                else if (actionIndex < selIndex)
                {
                    ds_list_delete(party, selIndex);
                    ds_list_insert(party, actionIndex + 1, bounceTop);
                    actionCard.flopped = true;
                    actionCard.tinyFlopped1 = true;
                    actionCard.tinyFlopped2 = true;
                    bounceTop.flopped = true;
                }
                if (actionCard.type == CHAR_WRESTLER)
                {
                    actionCard.sprite_index = s36_ClownBottom;
                    actionCard.photoy = 7;
                    actionCard.photox = 13;
                    actionCard.name = "BOX";
                }
                else if (actionCard.type == CHAR_SECURITY)
                {
                    actionCard.sprite_index = s36_SpearBottom;
                    actionCard.name = "-ER";
                    bounceTop.name = "LANCE-";
                    bounceTop.sprite_index = s36_SpearTop;
                    bounceTop.photox = 14;
                    bounceTop.photoy = 13;
                }
                else if (actionCard.type == CHAR_SECURITY_R)
                {
                    actionCard.sprite_index = s36_SpearBottom_R;
                    actionCard.name = "-ER";
                    bounceTop.name = "LANCE-";
                    bounceTop.sprite_index = s36_SpearTop_R;
                    bounceTop.photox = 13;
                }
                else if (actionCard.type == CHAR_GHOST)
                {
                    bounceTop.name = "DRONE";
                    bounceTop.sprite_index = s36_Drone;
                    bounceTop.photox = 6;
                    bounceTop.photoy = 9;
                }
                else if (actionCard.type == CHAR_GHOST_W)
                {
                    bounceTop.name = "DRONE";
                    bounceTop.sprite_index = s36_Drone_W;
                    bounceTop.photox = 2;
                    bounceTop.photoy = 7;
                }
                else if (actionCard.type == CHAR_HOST)
                {
                    bounceTop.name = "SPARE FROG";
                    bounceTop.sprite_index = s36_CopyCopy;
                    bounceTop.photox = 5;
                    bounceTop.photoy = 7;
                }
                else if (actionCard.type == CHAR_LIL_GUESTS)
                {
                    bounceTop.name = "LIL PUSH";
                    bounceTop.sprite_index = s36_LilPush;
                    bounceTop.photox = 14;
                    bounceTop.photoy = 14;
                }
                actionCard.bounce--;
                ds_list_add(booted, selCard);
                messageColor = global.palette[10];
                scr36_MessageSet(selCard.name + " WAS PUSHED OUT OF THE PARTY.");
                totalTrouble = scr36_GetTrouble();
                currPrestige = scr36_GetPrestige();
                if (totalTrouble >= TROUBLE_THRESHOLD)
                {
                    mute(global.SFX);
                    scrBGM(bgm36P_stingPartyEndB, false);
                    bgmTrig = false;
                    messageColor = global.palette[9];
                    scr36_MessageSet("OH NO! YOU CRASHED YOUR SHIP!");
                    scr36_ChangeState(STATE_BUSTED);
                    exit;
                }
                substate = 1;
            }
            else
            {
                scrSfx(soundText, 15);
                messageColor = global.palette[0];
                scr36_MessageSet(actionCard.name + " CAN'T PUSH THEMSELVES OUT.");
            }
        }
        else if (phase == PHASE_BUSTED)
        {
            if (selCard.type != CHAR_BOUNCE_TOP && selCard.type != CHAR_PHOTO && selCard.type != CHAR_RITUALIST_A && selCard.type != CHAR_RITUALIST_B && selCard.type != CHAR_RITUALIST_S && selCard.type != CHAR_LIL_GUESTS)
            {
                scrSfx(soundBootOut, 50);
                ds_list_delete(party, selIndex);
                totalTrouble = scr36_GetTrouble();
                currPrestige = scr36_GetPrestige();
                selCard.probation = PROBATION_TIME;
                messageColor = global.palette[0];
                scr36_MessageSet(scrStringVal("banned", selCard.name, PROBATION_TIME));
                substate = 5;
                stateTimer = 0;
            }
            else
            {
                scrSfx(soundText, 15);
                totalTrouble = scr36_GetTrouble();
                currPrestige = scr36_GetPrestige();
                messageColor = global.palette[0];
                scr36_MessageSet("YOU BLAMED " + selCard.name + " BUT THEY RESISTED THE BAN.");
                substate = 5;
                stateTimer = 0;
            }
        }
    }
    else if (fire2pressed && selCard == -4)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("nobody_here"));
    }
    else if (phase != PHASE_BUSTED)
    {
        if (actionIndex > selIndex)
        {
            actionCard.flopped = false;
            actionCard.tinyFlopped1 = false;
            actionCard.tinyFlopped2 = false;
        }
        else if (actionIndex < selIndex)
        {
            actionCard.flopped = true;
            actionCard.tinyFlopped1 = true;
            actionCard.tinyFlopped2 = true;
        }
    }
}
else if (substate == 7)
{
    if (fire1pressed)
    {
        mute(soundSelectSpecial);
        scrSfx(soundCancel, 5);
        scr36_MessageSet("");
        substate = 1;
    }
    else if (fire2pressed && selCard != -4 && !selCard.tiny)
    {
        mute(soundCancel);
        scrSfx(soundMatchA, 20);
        draw_set_color(global.palette[7]);
        scr36_MessageSet("WHO WILL SHRINK WITH THEM?");
        matchCard = selCard;
        matchIndex = selIndex;
        matchX = selectorX;
        matchY = selectorY;
        substate = 8;
    }
    else if (fire2pressed && selCard == -4)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("nobody_here"));
    }
    else if (fire2pressed && selCard.tiny)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet("THEY ARE ALREADY TINY.");
    }
}
else if (substate == 8)
{
    if (fire1pressed)
    {
        mute(soundMatchA);
        scrSfx(soundCancel, 5);
        scr36_MessageSet("");
        substate = 1;
    }
    else if (fire2pressed && selCard != -4 && abs(selIndex - matchIndex) == 1 && !selCard.tiny)
    {
        scrSfx(soundMatchB, 51);
        ds_list_delete(party, max(selIndex, matchIndex));
        ds_list_delete(party, min(selIndex, matchIndex));
        actionCard.matchmaker--;
        newCard = scr36_CreateCard(CHAR_LIL_GUESTS);
        newCard.money = selCard.money + matchCard.money;
        newCard.popularity = selCard.popularity + matchCard.popularity;
        newCard.prestige = selCard.prestige + matchCard.prestige;
        newCard.reshuffle = selCard.reshuffle + matchCard.reshuffle;
        newCard.reshufflemax = selCard.reshufflemax + matchCard.reshufflemax;
        if (newCard.reshufflemax)
        {
            if (selCard.reshufflemax)
            {
                newCard.sprite_index = selCard.sprite_index;
                newCard.image_index = selCard.image_index;
            }
            else
            {
                newCard.sprite_index = matchCard.sprite_index;
                newCard.image_index = matchCard.image_index;
            }
            newCard.image_speed = 0;
        }
        else if (sprite_get_number(selCard.sprite_index) > sprite_get_number(matchCard.sprite_index))
        {
            newCard.sprite_index = selCard.sprite_index;
        }
        else
        {
            newCard.sprite_index = matchCard.sprite_index;
        }
        if (matchIndex > selIndex)
        {
            newCard.tinySprite1 = selCard.sprite_index;
            newCard.tinySprite2 = matchCard.sprite_index;
            newCard.tinyFlipped1 = selCard.flipped;
            newCard.tinyFlipped2 = matchCard.flipped;
            newCard.tinyFlopped1 = selCard.flopped;
            newCard.tinyFlopped2 = matchCard.flopped;
            newCard.tinyPhoto1 = selCard.polaroid;
            newCard.tinyPhoto2 = matchCard.polaroid;
            newCard.tinypcolor1 = selCard.pcolor;
            newCard.tinypcolor2 = matchCard.pcolor;
        }
        else
        {
            newCard.tinySprite1 = matchCard.sprite_index;
            newCard.tinySprite2 = selCard.sprite_index;
            newCard.tinyFlipped1 = matchCard.flipped;
            newCard.tinyFlipped2 = selCard.flipped;
            newCard.tinyFlopped1 = matchCard.flopped;
            newCard.tinyFlopped2 = selCard.flopped;
            newCard.tinyPhoto1 = matchCard.polaroid;
            newCard.tinyPhoto2 = selCard.polaroid;
            newCard.tinypcolor1 = matchCard.pcolor;
            newCard.tinypcolor2 = selCard.pcolor;
        }
        if ((newCard.tinyPhoto1 + newCard.tinyPhoto2) > 0)
        {
            newCard.image_speed = 0;
        }
        newCard.troublemaker = selCard.troublemaker + matchCard.troublemaker;
        newCard.peacekeeper = selCard.peacekeeper + matchCard.peacekeeper;
        newCard.oldfriend = selCard.oldfriend + matchCard.oldfriend;
        newCard.bring = selCard.bring + matchCard.bring;
        newCard.full = selCard.full + matchCard.full;
        newCard.schoolpride = selCard.schoolpride + matchCard.schoolpride;
        newCard.dancer = selCard.dancer + matchCard.dancer;
        newCard.troublePopBonus = selCard.troublePopBonus + matchCard.troublePopBonus;
        newCard.troubleMoneyBonus = selCard.troubleMoneyBonus + matchCard.troubleMoneyBonus;
        newCard.bounce = selCard.bounce + matchCard.bounce;
        newCard.bouncemax = selCard.bouncemax + matchCard.bouncemax;
        newCard.stone = selCard.stone + matchCard.stone;
        newCard.arrow = selCard.arrow + matchCard.arrow;
        newCard.bomb = selCard.bomb + matchCard.bomb;
        newCard.peek = selCard.peek + matchCard.peek;
        newCard.peekmax = selCard.peekmax + matchCard.peekmax;
        newCard.banish = selCard.banish + matchCard.banish;
        newCard.banishmax = selCard.banishmax + matchCard.banishmax;
        newCard.phone = selCard.phone + matchCard.phone;
        newCard.phonemax = selCard.phonemax + matchCard.phonemax;
        newCard.photo = selCard.photo + matchCard.photo;
        newCard.photomax = selCard.photomax + matchCard.photomax;
        newCard.upgrade = selCard.upgrade + matchCard.upgrade;
        newCard.upgrademax = selCard.upgrademax + matchCard.upgrademax;
        newCard.bless = selCard.bless + matchCard.bless;
        newCard.blessmax = selCard.blessmax + matchCard.blessmax;
        if (newCard.blessmax > 1)
        {
            newCard.blessmax = 1;
        }
        newCard.magicSwap = selCard.magicSwap + matchCard.magicSwap;
        newCard.magicSwapmax = selCard.magicSwapmax + matchCard.magicSwapmax;
        newCard.introvert = selCard.introvert + matchCard.introvert;
        newCard.introvertmax = selCard.introvertmax + matchCard.introvertmax;
        newCard.matchmaker = selCard.matchmaker + matchCard.matchmaker;
        newCard.matchmakermax = selCard.matchmakermax + matchCard.matchmakermax;
        newCard.copyfrog = selCard.copyfrog + matchCard.copyfrog;
        newCard.entranceBonus = selCard.entranceBonus + matchCard.entranceBonus;
        newCard.werewolf = selCard.werewolf + matchCard.werewolf;
        newCard.tiny = 1;
        ds_list_insert(party, min(selIndex, matchIndex), newCard);
        ds_list_add(booted, selCard);
        ds_list_add(booted, matchCard);
        messageColor = global.palette[7];
        scr36_MessageSet(matchCard.name + " & " + selCard.name + " ARE REALLY SMALL NOW.");
        substate = 1;
    }
    else if (fire2pressed && selCard == -4)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("nobody_here"));
    }
    else if (fire2pressed && abs(matchIndex - selIndex) > 1)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("must_be_adjacent"));
    }
    else if (fire2pressed && selCard == matchCard)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("same_person_warning"));
    }
    else if (fire2pressed && selCard.tiny)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet("THEY ARE ALREADY TINY.");
    }
}
else if (substate == 6)
{
    if (fire1pressed)
    {
        mute(soundSelectSpecial);
        scrSfx(soundCancel, 5);
        scr36_MessageSet("");
        substate = 1;
    }
    else if (fire2pressed && selCard != -4)
    {
        scrSfx(soundPhoto, 50);
        selCard.flickerTimer = 32;
        actionCard.photo--;
        newCard = scr36_CreateCard(CHAR_PHOTO);
        newCard.money = selCard.money;
        newCard.popularity = selCard.popularity;
        newCard.tiny = selCard.tiny;
        newCard.tinySprite1 = selCard.tinySprite1;
        newCard.tinySprite2 = selCard.tinySprite2;
        newCard.tinyFlipped1 = selCard.tinyFlipped1;
        newCard.tinyFlipped2 = selCard.tinyFlipped2;
        newCard.tinyFlopped1 = selCard.tinyFlopped1;
        newCard.tinyFlopped2 = selCard.tinyFlopped2;
        newCard.tinyPhoto1 = selCard.tinyPhoto1;
        newCard.tinyPhoto2 = selCard.tinyPhoto2;
        newCard.tinypcolor1 = selCard.tinypcolor1;
        newCard.tinypcolor2 = selCard.tinypcolor2;
        newCard.sprite_index = selCard.sprite_index;
        newCard.troublemaker = selCard.troublemaker;
        newCard.peacekeeper = selCard.peacekeeper;
        newCard.flipped = selCard.flipped;
        newCard.flopped = selCard.flopped;
        newCard.image_index = selCard.image_index;
        newCard.image_speed = 0;
        newCard.polaroid = 1;
        newCard.photox = selCard.photox;
        newCard.photoy = selCard.photoy;
        newCard.pcolor = scrChoose(4, 6, 10, 12, 13, 15);
        newCard.pscalex = scrChoose(1.1, 1.2, 1.3, 1.4, 1.5);
        newCard.pscaley = scrChoose(1.1, 1.2, 1.3, 1.4, 1.5);
        ds_list_insert(party, 0, newCard);
        substate = 9;
        exit;
    }
    else if (fire2pressed && selCard == -4)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("nobody_here"));
    }
}
else if (substate == 10)
{
    if (fire1pressed)
    {
        mute(soundSelectSpecial);
        scrSfx(soundCancel, 5);
        scr36_MessageSet("");
        substate = 1;
    }
    else if (fire2pressed && selCard != -4 && selCard != actionCard && selCard.popularity > -9)
    {
        scrSfx(soundPopular, 50);
        messageColor = global.palette[9];
        scr36_MessageSet(actionCard.name + " DRAINED 1 POP FROM " + selCard.name);
        actionCard.upgrade--;
        selCard.flickerTimer = 32;
        if (selCard.flipped)
        {
            selCard.currMon--;
        }
        selCard.popularity--;
        actionCard.popularity++;
        if (actionCard.flipped)
        {
            actionCard.currMon++;
        }
        substate = 1;
        exit;
    }
    else if (fire2pressed && selCard == actionCard)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(actionCard.name + " CAN'T DRAIN THEMSELVES.");
    }
    else if (fire2pressed && selCard == -4)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("nobody_here"));
    }
    else if (fire2pressed && selCard.popularity == -9)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(selCard.name + " HAS NO MORE POP TO DRAIN.");
    }
}
else if (substate == 11)
{
    if (fire1pressed)
    {
        mute(soundSelectSpecial);
        scrSfx(soundCancel, 5);
        scr36_MessageSet("");
        substate = 1;
    }
    else if (fire2pressed && selCard != -4)
    {
        selCard.currPop = selCard.popularity;
        selCard.currMon = selCard.money;
        scrSfx(soundMagicSwap, 50);
        messageColor = global.palette[7];
        scr36_MessageSet(selCard.name + " WAS FLIPPED");
        selCard.popularity = selCard.currMon;
        selCard.money = selCard.currPop;
        if (selCard.flipped == 0)
        {
            selCard.flipped = 1;
        }
        else
        {
            selCard.flipped = 0;
        }
        if (selCard.tinyFlipped1 == 0)
        {
            selCard.tinyFlipped1 = 1;
        }
        else
        {
            selCard.tinyFlipped1 = 0;
        }
        if (selCard.tinyFlipped2 == 0)
        {
            selCard.tinyFlipped2 = 1;
        }
        else
        {
            selCard.tinyFlipped2 = 0;
        }
        actionCard.magicSwap--;
        substate = 1;
    }
    else if (fire2pressed && selCard == -4)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("nobody_here"));
    }
}
else if (substate == 12)
{
    if (fire1pressed)
    {
        mute(soundSelectSpecial);
        scrSfx(soundCancel, 5);
        scr36_MessageSet("");
        actionCard.image_index = 0;
        substate = 1;
    }
    else if (fire2pressed && selIndex < actionIndex)
    {
        scrSfx(soundGoOutside, 50);
        with (o36_Card)
        {
            flickerActionTimer = 0;
        }
        actionCard.reshuffle--;
        actionCard.image_index = 2;
        actionCard.flopped = false;
        actionCard.tinyFlopped1 = false;
        actionCard.tinyFlopped2 = false;
        for (i = 0; i < actionIndex; i++)
        {
            ds_list_add(draw_pile, ds_list_find_value(party, i));
        }
        var i = actionIndex - 1;
        while (i >= 0)
        {
            ds_list_delete(party, i);
            i--;
        }
        scrShuffle(draw_pile);
        nextCard = -4;
        nextNextCard = -4;
        messageColor = global.palette[19];
        scr36_MessageSet("EVERYONE TO THE LEFT WENT OUTSIDE");
        totalTrouble = scr36_GetTrouble();
        currPrestige = scr36_GetPrestige();
        if (totalTrouble >= TROUBLE_THRESHOLD)
        {
            mute(global.SFX);
            scrBGM(bgm36P_stingPartyEndB, false);
            bgmTrig = false;
            messageColor = global.palette[9];
            scr36_MessageSet("OH NO! YOU CRASHED YOUR SHIP!");
            scr36_ChangeState(STATE_BUSTED);
            exit;
        }
        substate = 1;
    }
    else if (fire2pressed && selIndex > actionIndex)
    {
        scrSfx(soundGoOutside, 50);
        with (o36_Card)
        {
            flickerActionTimer = 0;
        }
        actionCard.reshuffle--;
        actionCard.image_index = 2;
        actionCard.flopped = true;
        actionCard.tinyFlopped1 = true;
        actionCard.tinyFlopped2 = true;
        var i = actionIndex + 1;
        while (i < ds_list_size(party))
        {
            ds_list_add(draw_pile, ds_list_find_value(party, i));
            i++;
        }
        i = ds_list_size(party);
        while (i > actionIndex)
        {
            ds_list_delete(party, i);
            i--;
        }
        scrShuffle(draw_pile);
        nextCard = -4;
        nextNextCard = -4;
        messageColor = global.palette[19];
        scr36_MessageSet("EVERYONE TO THE RIGHT WENT OUTSIDE");
        totalTrouble = scr36_GetTrouble();
        currPrestige = scr36_GetPrestige();
        if (totalTrouble >= TROUBLE_THRESHOLD)
        {
            mute(global.SFX);
            scrBGM(bgm36P_stingPartyEndB, false);
            bgmTrig = false;
            messageColor = global.palette[9];
            scr36_MessageSet("OH NO! YOU CRASHED YOUR SHIP!");
            scr36_ChangeState(STATE_BUSTED);
            exit;
        }
        substate = 1;
    }
    else if (fire2pressed && selIndex == actionIndex)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet("CHOOSE A SIDE");
        actionCard.image_index = 1;
    }
    else if (actionIndex > selIndex)
    {
        actionCard.image_index = 1;
        actionCard.flopped = false;
        actionCard.tinyFlopped1 = false;
        actionCard.tinyFlopped2 = false;
        for (var i = 0; i < actionIndex; i++)
        {
            ds_list_find_value(party, i).flickerTimer = 10;
        }
    }
    else if (actionIndex < selIndex)
    {
        actionCard.image_index = 1;
        actionCard.flopped = true;
        actionCard.tinyFlopped1 = true;
        actionCard.tinyFlopped2 = true;
        var i = actionIndex + 1;
        while (i < ds_list_size(party))
        {
            ds_list_find_value(party, i).flickerTimer = 10;
            i++;
        }
    }
    else if (selIndex == actionIndex)
    {
        actionCard.image_index = 0;
    }
}
else if (substate == 13)
{
    if (fire1pressed)
    {
        mute(soundSelectSpecial);
        scrSfx(soundCancel, 5);
        scr36_MessageSet("");
        substate = 1;
    }
    else if (fire2pressed && selCard != -4 && selCard.type != CHAR_LIL_GUESTS && selCard.type != CHAR_BOUNCE_TOP && selCard.type != CHAR_PHOTO && selCard.type != CHAR_RITUALIST_A && selCard.type != CHAR_RITUALIST_B && selCard.type != CHAR_RITUALIST_S)
    {
        scrSfx(soundBanish, 50);
        actionCard.banish--;
        selCard.probation = 1;
        ds_list_add(booted, selCard);
        ds_list_delete(party, selIndex);
        messageColor = global.palette[0];
        scr36_MessageSet(selCard.name + " WAS BANNED FOR 1 PARTY.");
        totalTrouble = scr36_GetTrouble();
        currPrestige = scr36_GetPrestige();
        if (totalTrouble >= TROUBLE_THRESHOLD)
        {
            mute(global.SFX);
            scrBGM(bgm36P_stingPartyEndB, false);
            bgmTrig = false;
            messageColor = global.palette[9];
            scr36_MessageSet("OH NO! YOU CRASHED YOUR SHIP!");
            scr36_ChangeState(STATE_BUSTED);
            exit;
        }
        substate = 1;
    }
    else if (fire2pressed && selCard == -4)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("nobody_here"));
    }
    else if (fire2pressed && (selCard.type == CHAR_LIL_GUESTS || selCard.type == CHAR_BOUNCE_TOP || selCard.type == CHAR_PHOTO || selCard.type == CHAR_RITUALIST_A || selCard.type == CHAR_RITUALIST_B || selCard.type == CHAR_RITUALIST_S))
    {
        scrSfx(soundText, 15);
        actionCard.banish--;
        ds_list_add(booted, selCard);
        ds_list_delete(party, selIndex);
        messageColor = global.palette[0];
        scr36_MessageSet("YOU BOOTED " + selCard.name + " BUT THEY RESISTED THE BAN.");
        totalTrouble = scr36_GetTrouble();
        currPrestige = scr36_GetPrestige();
        if (totalTrouble >= TROUBLE_THRESHOLD)
        {
            mute(global.SFX);
            scrBGM(bgm36P_stingPartyEndB, false);
            bgmTrig = false;
            messageColor = global.palette[9];
            scr36_MessageSet("OH NO! YOU CRASHED YOUR SHIP!");
            scr36_ChangeState(STATE_BUSTED);
            exit;
        }
        substate = 1;
    }
}
else if (substate == 14)
{
    if (fire1pressed)
    {
        mute(soundSelectSpecial);
        scrSfx(soundCancel, 5);
        scr36_MessageSet("");
        substate = 1;
    }
    else if (fire2pressed && selCard != -4 && selCard != actionCard)
    {
        if (selCard.bounce == 4 || selCard.peek == 4 || selCard.phone == 4 || selCard.reshuffle == 4 || selCard.photo == 4 || selCard.matchmaker == 4 || selCard.introvert >= 7 || selCard.upgrade == 4 || selCard.magicSwap == 4 || selCard.greet == 4 || selCard.banish == 4 || selCard.bless == 4)
        {
            scrSfx(soundText, 15);
            messageColor = global.palette[0];
            scr36_MessageSet(selCard.name + " IS FULLY BLESSED");
        }
        else if (selCard.arrow || selCard.bomb || selCard.stone)
        {
            scrSfx(soundText, 15);
            messageColor = global.palette[0];
            scr36_MessageSet("THAT RITUAL... CUTS TO THE ROOT. NOT EVEN BRONTOR CAN REGROW IT.");
        }
        else
        {
            blessed = false;
            if (selCard.bouncemax > 0 && selCard.bounce < 4)
            {
                selCard.bounce += selCard.bouncemax;
                blessed = true;
            }
            if (selCard.peekmax > 0 && selCard.peek < 4)
            {
                selCard.peek += selCard.peekmax;
                blessed = true;
            }
            if (selCard.phonemax > 0 && selCard.phone < 4)
            {
                selCard.phone += selCard.phonemax;
                blessed = true;
            }
            if (selCard.reshufflemax > 0 && selCard.reshuffle < 4)
            {
                selCard.reshuffle += selCard.reshufflemax;
                blessed = true;
            }
            if (selCard.photomax > 0 && selCard.photo < 4)
            {
                selCard.photo += selCard.photomax;
                blessed = true;
            }
            if (selCard.matchmakermax > 0 && selCard.matchmaker < 4)
            {
                selCard.matchmaker += selCard.matchmakermax;
                blessed = true;
            }
            if (selCard.introvertmax > 0 && selCard.introvert < 7)
            {
                selCard.introvert += 3;
                blessed = true;
            }
            if (selCard.upgrademax > 0 && selCard.upgrade < 4)
            {
                selCard.upgrade += selCard.upgrademax;
                blessed = true;
            }
            if (selCard.magicSwapmax > 0 && selCard.magicSwap < 4)
            {
                selCard.magicSwap += selCard.magicSwapmax;
                blessed = true;
            }
            if (selCard.greetmax > 0 && selCard.greet < 4)
            {
                selCard.greet += selCard.greetmax;
                blessed = true;
            }
            if (selCard.blessmax > 0 && selCard.bless < 4)
            {
                selCard.bless += selCard.blessmax;
                blessed = true;
            }
            if (selCard.banishmax > 0 && selCard.banish < 4)
            {
                selCard.banish += selCard.banishmax;
                blessed = true;
            }
            if (blessed == true)
            {
                actionCard.bless--;
                scrSfx(soundRefresh, 50);
                messageColor = global.palette[14];
                scr36_MessageSet(selCard.name + " WAS BLESSED");
                substate = 1;
            }
        }
        if (!selCard.bouncemax && !selCard.peekmax && !selCard.phonemax && !selCard.reshufflemax && !selCard.photomax && !selCard.matchmakermax && !selCard.introvertmax && !selCard.upgrademax && !selCard.magicSwapmax && !selCard.greetmax && !selCard.banishmax && !selCard.blessmax)
        {
            scrSfx(soundText, 15);
            messageColor = global.palette[0];
            scr36_MessageSet(selCard.name + " HAS NO ACTIONS TO BLESS");
        }
    }
    else if (fire2pressed && selCard == actionCard)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(actionCard.name + " TRIED VERY HARD, BUT THEY COULDN'T BLESS THEMSELF.");
    }
    else if (fire2pressed && selCard == -4)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("nobody_here"));
    }
}
else if (substate == 15)
{
    if (fire1pressed)
    {
        mute(soundSelectSpecial);
        scrSfx(soundCancel, 5);
        scr36_MessageSet("");
        substate = 1;
    }
    else if (fire2pressed && selCard != -4 && selCard != actionCard)
    {
        actionCard.popularity = selCard.popularity;
        actionCard.money = selCard.money;
        actionCard.bounce = selCard.bounce;
        actionCard.bouncemax = selCard.bouncemax;
        actionCard.bring = selCard.bring;
        actionCard.troublemaker = selCard.troublemaker;
        actionCard.peacekeeper = selCard.peacekeeper;
        actionCard.peek = selCard.peek;
        actionCard.peekmax = selCard.peekmax;
        actionCard.dancer = selCard.dancer;
        actionCard.full = selCard.full;
        actionCard.phone = selCard.phone;
        actionCard.phonemax = selCard.phonemax;
        actionCard.reshuffle = selCard.reshuffle;
        actionCard.reshufflemax = selCard.reshufflemax;
        actionCard.photo = selCard.photo;
        actionCard.photomax = selCard.photomax;
        actionCard.matchmaker = selCard.matchmaker;
        actionCard.matchmakermax = selCard.matchmakermax;
        actionCard.schoolpride = selCard.schoolpride;
        actionCard.oldfriend = selCard.oldfriend;
        actionCard.introvert = selCard.introvert;
        actionCard.introvertmax = selCard.introvertmax;
        actionCard.werewolf = selCard.werewolf;
        actionCard.bless = selCard.bless;
        actionCard.blessmax = selCard.blessmax;
        actionCard.upgrade = selCard.upgrade;
        actionCard.upgrademax = selCard.upgrademax;
        actionCard.troublePopBonus = selCard.troublePopBonus;
        actionCard.troubleMoneyBonus = selCard.troubleMoneyBonus;
        actionCard.entranceBonus = selCard.entranceBonus;
        actionCard.magicSwap = selCard.magicSwap;
        actionCard.magicSwapmax = selCard.magicSwapmax;
        actionCard.greet = selCard.greet;
        actionCard.greetmax = selCard.greetmax;
        actionCard.banish = selCard.banish;
        actionCard.banishmax = selCard.banishmax;
        actionCard.phoneLow = selCard.phoneLow;
        actionCard.flipped = selCard.flipped;
        actionCard.tiny = selCard.tiny;
        actionCard.sprite_index = s36_Host;
        actionCard.tinySprite1 = actionCard.sprite_index;
        actionCard.tinySprite2 = actionCard.sprite_index;
        actionCard.tinyFlipped1 = selCard.tinyFlipped1;
        actionCard.tinyFlipped2 = selCard.tinyFlipped2;
        actionCard.tinyFlopped1 = selCard.tinyFlopped1;
        actionCard.tinyFlopped2 = selCard.tinyFlopped2;
        actionCard.tinyPhoto1 = selCard.tinyPhoto1;
        actionCard.tinyPhoto2 = selCard.tinyPhoto2;
        actionCard.tinypcolor1 = selCard.tinypcolor1;
        actionCard.tinypcolor2 = selCard.tinypcolor2;
        actionCard.polaroid = selCard.polaroid;
        if (actionCard.polaroid)
        {
            actionCard.image_speed = 0;
        }
        actionCard.pcolor = selCard.pcolor;
        actionCard.arrow = selCard.arrow;
        actionCard.bomb = selCard.bomb;
        actionCard.stone = selCard.stone;
        actionCard.copyfrog += selCard.copyfrog;
        actionCard.copyfrog--;
        scrSfx(soundPacify, 50);
        messageColor = global.palette[4];
        scr36_MessageSet(actionCard.name + " MIMICKED " + selCard.name);
        substate = 20;
    }
    else if (fire2pressed && selCard == -4)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("nobody_here"));
    }
    else if (fire2pressed && selCard == actionCard)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(actionCard.name + " TRIED VERY HARD, BUT THEY COULDN'T MIMIC THEMSELF.");
    }
}
else if (substate == 16)
{
    selOn = false;
    wait = true;
    if (wait)
    {
        stateTimer++;
        if (stateTimer > 15)
        {
            wait = false;
        }
    }
    if (!wait)
    {
        if (previous == 9)
        {
            substate = 17;
        }
        else if (previous == 18)
        {
            substate = 18;
        }
        else if (previous == 27)
        {
            ds_list_add(booted, ds_list_find_value(party, selIndex + 18));
            ds_list_delete(party, selIndex + 18);
            stateTimer = 0;
            previous = 2718;
            substate = 16;
        }
        else if (previous == 2718)
        {
            ds_list_add(booted, ds_list_find_value(party, selIndex + 9));
            ds_list_delete(party, selIndex + 9);
            stateTimer = 0;
            previous = 279;
            messageColor = global.palette[0];
            str = "3 GUESTS WERE PUSHED OUT OF THE PARTY.";
            scr36_MessageSet(str);
            substate = 16;
        }
        else if (previous == 279 || previous == 189)
        {
            ds_list_add(booted, ds_list_find_value(party, selIndex));
            ds_list_delete(party, selIndex);
            substate = 20;
        }
    }
}
else if (substate == 17)
{
    if ((ds_list_size(party) - 1) >= (selIndex + 18))
    {
        nonCard = scr36_CreateCard(CHAR_BOUNCE_TOP);
        nonCard.name = "STONE";
        if (selCard.type == CHAR_HOST)
        {
            nonCard.sprite_index = s36_FrogStone;
        }
        else
        {
            nonCard.sprite_index = s36_Stone;
        }
        ds_list_add(booted, ds_list_find_value(party, selIndex + 18));
        ds_list_delete(party, selIndex + 18);
        ds_list_insert(party, selIndex + 18, nonCard);
        ds_list_find_value(party, selIndex + 9).visible = false;
        stateTimer = 0;
        previous = 18;
        substate = 16;
    }
    else
    {
        ds_list_add(booted, ds_list_find_value(party, selIndex));
        ds_list_delete(party, selIndex);
        messageColor = global.palette[0];
        str = "1 GUEST WAS PUSHED OUT OF THE PARTY.";
        scr36_MessageSet(str);
        substate = 20;
    }
}
else if (substate == 18)
{
    if ((ds_list_size(party) - 1) >= (selIndex + 27))
    {
        nonCard = scr36_CreateCard(CHAR_BOUNCE_TOP);
        nonCard.name = "STONE";
        if (selCard.type == CHAR_HOST)
        {
            nonCard.sprite_index = s36_FrogStone;
        }
        else
        {
            nonCard.sprite_index = s36_Stone;
        }
        ds_list_add(booted, ds_list_find_value(party, selIndex + 27));
        ds_list_delete(party, selIndex + 27);
        ds_list_insert(party, selIndex + 27, nonCard);
        ds_list_find_value(party, selIndex + 18).visible = false;
        stateTimer = 0;
        previous = 27;
        substate = 16;
    }
    else
    {
        ds_list_add(booted, ds_list_find_value(party, selIndex + 9));
        ds_list_delete(party, selIndex + 9);
        stateTimer = 0;
        previous = 189;
        messageColor = global.palette[0];
        str = "2 GUESTS WERE PUSHED OUT OF THE PARTY.";
        scr36_MessageSet(str);
        substate = 16;
    }
}
else if (substate == 19)
{
    targets = ds_list_create();
    for (var i = 0; i <= (arrowMax - selIndex); i++)
    {
        if ((selIndex + i) < ds_list_size(party))
        {
            ds_list_add(targets, selIndex + i);
        }
    }
    for (var i = 0; i < (ds_list_size(targets) - 1); i++)
    {
        ds_list_find_value(party, ds_list_find_value(targets, i)).visible = false;
    }
    nonCard = scr36_CreateCard(CHAR_BOUNCE_TOP);
    nonCard.name = "ARROW";
    nonCard.photox = 14;
    nonCard.photoy = 7;
    if (selCard.type == CHAR_HOST)
    {
        nonCard.sprite_index = s36_FrogArrow;
        nonCard.photox = 12;
        nonCard.photoy = 8;
    }
    else
    {
        nonCard.sprite_index = s36_Arrow;
    }
    finalIndex = ds_list_find_value(targets, ds_list_size(targets) - 1);
    finalTarget = ds_list_find_value(party, finalIndex);
    ds_list_add(booted, finalTarget);
    ds_list_delete(party, finalIndex);
    ds_list_insert(party, finalIndex, nonCard);
    for (var i = 1; i < ds_list_size(targets); i++)
    {
        target = ds_list_find_value(party, finalIndex - i);
        ds_list_add(booted, target);
        ds_list_delete(party, finalIndex - i);
    }
    messageColor = global.palette[0];
    str = "* GUESTS WERE PUSHED OUT OF THE PARTY.";
    str = string_replace_all(str, "*", string(ds_list_size(targets) - 1));
    scr36_MessageSet(str);
    ds_list_destroy(targets);
    substate = 20;
}
else if (substate == 20)
{
    substate = 1;
    var oldTotalTrouble = totalTrouble;
    totalTrouble = scr36_GetTrouble();
    currPrestige = scr36_GetPrestige();
    if (totalTrouble >= TROUBLE_THRESHOLD)
    {
        mute(global.SFX);
        scrBGM(bgm36P_stingPartyEndB, false);
        bgmTrig = false;
        messageColor = global.palette[9];
        scr36_MessageSet("OH NO! YOU CRASHED YOUR SHIP!");
        scr36_ChangeState(STATE_BUSTED);
        exit;
    }
    else if (totalTrouble == (TROUBLE_THRESHOLD - 1) && totalTrouble != oldTotalTrouble)
    {
        scrSfx(soundWarning, 55);
        messageColor = global.palette[9];
        scr36_MessageSet(scrString("warning"));
    }
    else if (oldTotalTrouble == (TROUBLE_THRESHOLD - 1) && totalTrouble == (TROUBLE_THRESHOLD - 2))
    {
        scrSfx(soundText, 40);
        troubleWarnStreak = 0;
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("chilled_out"));
    }
    else if (totalTrouble == (TROUBLE_THRESHOLD - 1) && totalTrouble == oldTotalTrouble)
    {
        if (troubleWarnStreak < 4)
        {
            scrSfx(soundWarnStreak[troubleWarnStreak], 40);
        }
        else
        {
            scrSfx(soundWarnStreak[4], 40);
        }
        troubleWarnStreak++;
    }
}
else if (substate == 21)
{
    if (pressLeft)
    {
        tinyIndex--;
        scrSfx(soundNaviA, 10);
    }
    if (pressRight)
    {
        tinyIndex++;
        scrSfx(soundNaviA, 10);
    }
    if (tinyIndex >= actionCard.tinyActions)
    {
        tinyIndex = 0;
    }
    if (tinyIndex < 0)
    {
        tinyIndex = actionCard.tinyActions - 1;
    }
    tinySelect = string(actionCard.tinyList[tinyIndex]);
    if (tinySelect == "stone")
    {
        if ((ds_list_size(party) - 1) >= (selIndex + 9))
        {
            ds_list_find_value(party, selIndex + 9).flickerTimer = 10;
            if ((ds_list_size(party) - 1) >= (selIndex + 18))
            {
                ds_list_find_value(party, selIndex + 18).flickerTimer = 10;
                if ((ds_list_size(party) - 1) >= (selIndex + 27))
                {
                    ds_list_find_value(party, selIndex + 27).flickerTimer = 10;
                }
            }
        }
    }
    else if (tinySelect == "arrow")
    {
        arrowRow = 0;
        if (selIndex < 6)
        {
            arrowRow = 1;
            for (var i = 1; i <= (6 - selIndex); i++)
            {
                if ((selIndex + i) < ds_list_size(party))
                {
                    ds_list_find_value(party, selIndex + i).flickerTimer = 10;
                }
            }
        }
        else if (selIndex < 15 && selIndex > 6)
        {
            arrowRow = 2;
            for (var i = 1; i <= (15 - selIndex); i++)
            {
                if ((selIndex + i) < ds_list_size(party))
                {
                    ds_list_find_value(party, selIndex + i).flickerTimer = 10;
                }
            }
        }
        else if (selIndex < 24 && selIndex > 15)
        {
            arrowRow = 3;
            for (var i = 1; i <= (24 - selIndex); i++)
            {
                if ((selIndex + i) < ds_list_size(party))
                {
                    ds_list_find_value(party, selIndex + i).flickerTimer = 10;
                }
            }
        }
        else if (selIndex < 33 && selIndex > 24)
        {
            arrowRow = 4;
            for (var i = 1; i <= (33 - selIndex); i++)
            {
                if ((selIndex + i) < ds_list_size(party))
                {
                    ds_list_find_value(party, selIndex + i).flickerTimer = 10;
                }
            }
        }
        else if (selIndex == 6)
        {
            arrowRow = 1;
        }
        else if (selIndex == 15)
        {
            arrowRow = 2;
        }
        else if (selIndex == 24)
        {
            arrowRow = 3;
        }
        else if (selIndex == 33)
        {
            arrowRow = 4;
        }
    }
    else if (tinySelect == "bomb")
    {
        bombTotal = 0;
        if ((selIndex - 9) >= 0)
        {
            bombUp = ds_list_find_value(party, selIndex - 9);
            bombUp.flickerTimer = 10;
            bombTotal++;
        }
        else
        {
            bombUp = false;
        }
        if ((selIndex + 9) <= (ds_list_size(party) - 1))
        {
            bombDown = ds_list_find_value(party, selIndex + 9);
            bombDown.flickerTimer = 10;
            bombTotal++;
        }
        else
        {
            bombDown = false;
        }
        if ((selIndex + 1) <= (ds_list_size(party) - 1) && selIndex != 6 && selIndex != 15 && selIndex != 24)
        {
            bombRight = ds_list_find_value(party, selIndex + 1);
            bombRight.flickerTimer = 10;
            bombTotal++;
        }
        else
        {
            bombRight = false;
        }
        if ((selIndex - 1) >= 0 && selIndex != 7 && selIndex != 16 && selIndex != 25)
        {
            bombLeft = ds_list_find_value(party, selIndex - 1);
            bombLeft.flickerTimer = 10;
            bombTotal++;
        }
        else
        {
            bombLeft = false;
        }
    }
    if (fire1pressed)
    {
        mute(soundSelectSpecial);
        scrSfx(soundCancel, 5);
        scr36_MessageSet("");
        substate = 1;
    }
    else if (fire2pressed)
    {
        tinyChoice = string(actionCard.tinyList[tinyIndex]);
        if (tinyChoice == "bounce")
        {
            mute(soundCancel);
            scrSfx(soundSelectSpecial, 20);
            tSelector = 3;
            actionIndex = selIndex;
            with (o36_Card)
            {
                flickerActionTimer = 0;
            }
            messageColor = global.palette[10];
            scr36_MessageSet("WHO DO YOU WANT TO PUSH OUT?");
            substate = 4;
            actionCard = selCard;
        }
        else if (tinyChoice == "photo")
        {
            if (ds_list_size(party) < capacity[cp])
            {
                mute(soundCancel);
                scrSfx(soundSelectSpecial, 20);
                with (o36_Card)
                {
                    flickerActionTimer = 0;
                }
                messageColor = global.palette[4];
                scr36_MessageSet(scrString("photograph"));
                substate = 6;
                actionCard = selCard;
            }
            else
            {
                messageColor = global.palette[4];
                scr36_MessageSet("NOT ENOUGH ROOM FOR A PHOTOSHOOT.");
            }
        }
        else if (tinyChoice == "upgrade")
        {
            if (selCard.popularity < 9)
            {
                mute(soundCancel);
                scrSfx(soundSelectSpecial, 20);
                with (o36_Card)
                {
                    flickerActionTimer = 0;
                }
                messageColor = global.palette[9];
                scr36_MessageSet("WHO LOOKS TASTY?");
                substate = 10;
                actionCard = selCard;
            }
            else if (selCard.popularity >= 9)
            {
                scrSfx(soundText, 15);
                messageColor = global.palette[0];
                scr36_MessageSet(selCard.name + " HAS DRANK THEIR FILL OF POP");
            }
        }
        else if (tinyChoice == "magicSwap")
        {
            mute(soundCancel);
            scrSfx(soundSelectSpecial, 20);
            with (o36_Card)
            {
                flickerActionTimer = 0;
            }
            messageColor = global.palette[7];
            scr36_MessageSet("WHO WILL BE FLIPPED?");
            substate = 11;
            actionCard = selCard;
        }
        else if (tinyChoice == "reshuffle")
        {
            mute(soundCancel);
            scrSfx(soundSelectSpecial, 20);
            with (o36_Card)
            {
                flickerActionTimer = 0;
            }
            messageColor = global.palette[19];
            scr36_MessageSet("WHICH SIDE OF THE PARTY WILL GO OUTSIDE?");
            substate = 12;
            actionIndex = selIndex;
            actionCard = selCard;
        }
        else if (tinyChoice == "bless")
        {
            var actionsToBless = false;
            for (var i = 0; i < ds_list_size(party); i++)
            {
                if ((ds_list_find_value(party, i).bouncemax > 0 && ds_list_find_value(party, i).bounce < 4) || (ds_list_find_value(party, i).peekmax > 0 && ds_list_find_value(party, i).peek < 4) || (ds_list_find_value(party, i).phonemax > 0 && ds_list_find_value(party, i).phone < 4) || (ds_list_find_value(party, i).reshufflemax > 0 && ds_list_find_value(party, i).reshuffle < 4) || (ds_list_find_value(party, i).photomax > 0 && ds_list_find_value(party, i).photo < 4) || (ds_list_find_value(party, i).matchmakermax > 0 && ds_list_find_value(party, i).matchmaker < 4) || (ds_list_find_value(party, i).introvertmax > 0 && ds_list_find_value(party, i).introvert < 7) ||  (ds_list_find_value(party, i).upgrademax > 0 && ds_list_find_value(party, i).upgrade < 4) || (ds_list_find_value(party, i).magicSwapmax > 0 && ds_list_find_value(party, i).magicSwap < 4) || (ds_list_find_value(party, i).greetmax > 0 && ds_list_find_value(party, i).greet < 4) || (ds_list_find_value(party, i).banishmax > 0 && ds_list_find_value(party, i).banish < 4) || (ds_list_find_value(party, i).blessmax > 0 && ds_list_find_value(party, i).bless < 4))
                {
                    ds_list_find_value(party, i).flickerTimer = 128;
                    actionsToBless = true;
                }
            }
            if (actionsToBless)
            {
                mute(soundCancel);
                scrSfx(soundSelectSpecial, 20);
                messageColor = global.palette[14];
                scr36_MessageSet("WHICH SOUL SHALL YOU BLESS WITH BRONTOR'S GRACE?");
                substate = 14;
                actionCard = selCard;
            }
            else
            {
                scrSfx(soundText, 15);
                messageColor = global.palette[0];
                scr36_MessageSet("NO ACTIONS TO BLESS");
            }
        }
        else if (tinyChoice == "introvert")
        {
            if (ds_list_size(party) < capacity[cp])
            {
                scrSfx(soundDoorOpen, 40);
                with (o36_Card)
                {
                    flickerActionTimer = 0;
                }
                selCard.introvert--;
                newType = scrChoose(CHAR_RITUALIST_A, CHAR_RITUALIST_S, CHAR_RITUALIST_B);
                nonCard = scr36_CreateCard(newType);
                ds_list_insert(party, selIndex + 1, nonCard);
                newCard = nonCard;
                substate = 9;
            }
            else if (ds_list_size(party) >= capacity[cp])
            {
                scrSfx(soundText, 15);
                messageColor = 16777215;
                scr36_MessageSet(scrString("no_room"));
            }
        }
        else if (tinyChoice == "phone")
        {
            if (ds_list_size(party) < capacity[cp] && !ds_list_empty(draw_pile))
            {
                mute(soundCancel);
                scrSfx(soundOpenFetch, 20);
                messageColor = global.palette[7];
                scr36_MessageSet(scrString("fetch_anyone"));
                scr36_ChangeState(STATE_FETCH);
                actionCard = selCard;
                exit;
            }
            else
            {
                scrSfx(soundText, 15);
                messageColor = 16777215;
                if (ds_list_size(party) >= capacity[cp])
                {
                    scr36_MessageSet(scrString("no_room"));
                }
                else
                {
                    scr36_MessageSet("NO ONE LEFT IN HOLODEX!");
                }
            }
        }
        else if (tinyChoice == "peek")
        {
            if (nextCard != -4)
            {
                scrSfx(soundText, 15);
                messageColor = global.palette[0];
                scr36_MessageSet("YOU ALREADY KNOW WHO'S AT THE AIRLOCK!");
            }
            else if (ds_list_empty(draw_pile))
            {
                scrSfx(soundText, 15);
                messageColor = global.palette[0];
                scr36_MessageSet("NO ONE LEFT IN HOLODEX!");
            }
            else if (ds_list_size(draw_pile) >= 2)
            {
                scrSfx(soundPeek, 50);
                selCard.peek--;
                nextCard = ds_list_find_value(draw_pile, 0);
                nextNextCard = ds_list_find_value(draw_pile, 1);
                messageColor = global.palette[13];
                scr36_MessageSet(nextCard.name + " & " + nextNextCard.name + " ARE HERE");
                actionCard = selCard;
                substate = 1;
            }
            else
            {
                scrSfx(soundPeek, 50);
                selCard.peek--;
                nextCard = ds_list_find_value(draw_pile, 0);
                messageColor = global.palette[13];
                scr36_MessageSet(nextCard.name + "IS AT THE AIRLOCK.");
                actionCard = selCard;
                substate = 1;
            }
        }
        else if (tinyChoice == "banish")
        {
            mute(soundCancel);
            scrSfx(soundSelectSpecial, 20);
            tSelector = 3;
            with (o36_Card)
            {
                flickerActionTimer = 0;
            }
            messageColor = global.palette[9];
            scr36_MessageSet("WHO WILL YOU BANISH TO THE NIGHT MANOR?");
            substate = 13;
            actionCard = selCard;
        }
        else if (tinyChoice == "matchmaker")
        {
            mute(soundCancel);
            scrSfx(soundSelectSpecial, 20);
            with (o36_Card)
            {
                flickerActionTimer = 0;
            }
            messageColor = global.palette[7];
            scr36_MessageSet("WHO WILL SHRINK TOGETHER?");
            substate = 7;
            actionCard = selCard;
        }
        else if (tinyChoice == "copyfrog")
        {
            mute(soundCancel);
            scrSfx(soundSelectSpecial, 20);
            messageColor = global.palette[2];
            scr36_MessageSet("WHICH GUEST WILL YOU COPY?");
            substate = 15;
            actionCard = selCard;
        }
        else if (tinyChoice == "stone")
        {
            if ((ds_list_size(party) - 1) >= (selIndex + 9))
            {
                mute(soundCancel);
                scrSfx(soundBootOut, 50);
                selCard.stone--;
                nonCard = scr36_CreateCard(CHAR_BOUNCE_TOP);
                nonCard.name = "STONE";
                nonCard.sprite_index = s36_Stone;
                ds_list_add(booted, ds_list_find_value(party, selIndex + 9));
                ds_list_delete(party, selIndex + 9);
                ds_list_insert(party, selIndex + 9, nonCard);
                selCard.visible = false;
                stateTimer = 0;
                previous = 9;
                substate = 16;
            }
            else
            {
                scrSfx(soundText, 15);
                messageColor = global.palette[0];
                scr36_MessageSet("NOONE TO CRUSH.");
            }
        }
        else if (tinyChoice == "arrow")
        {
            arrowMax = (arrowRow * 9) - 3;
            if (selIndex < arrowMax && selIndex < (ds_list_size(party) - 1))
            {
                mute(soundCancel);
                scrSfx(soundBootOut, 50);
                selCard.arrow--;
                substate = 19;
            }
            else
            {
                scrSfx(soundText, 15);
                messageColor = global.palette[0];
                scr36_MessageSet("NOONE TO SHOOT.");
            }
        }
        else if (tinyChoice == "bomb")
        {
            if (!bombRight && !bombLeft && !bombDown && !bombUp)
            {
                scrSfx(soundText, 15);
                messageColor = global.palette[0];
                scr36_MessageSet("NOONE TO BOMB.");
            }
            else
            {
                mute(soundCancel);
                scrSfx(soundBootOut, 50);
                selCard.bomb--;
                if (bombDown)
                {
                    ds_list_add(booted, bombDown);
                    ds_list_delete(party, selIndex + 9);
                }
                if (bombRight)
                {
                    ds_list_add(booted, bombRight);
                    ds_list_delete(party, selIndex + 1);
                }
                nonCard = scr36_CreateCard(CHAR_BOUNCE_TOP);
                nonCard.name = "BLAST";
                if (selCard.type == CHAR_HOST)
                {
                    nonCard.sprite_index = s36_FrogBlast;
                }
                else
                {
                    nonCard.sprite_index = s36_Blast;
                }
                ds_list_add(booted, selCard);
                ds_list_delete(party, selIndex);
                ds_list_insert(party, selIndex, nonCard);
                if (bombLeft)
                {
                    ds_list_add(booted, bombLeft);
                    ds_list_delete(party, selIndex - 1);
                }
                if (bombUp)
                {
                    ds_list_add(booted, bombUp);
                    ds_list_delete(party, selIndex - 9);
                }
                messageColor = global.palette[0];
                str = "* GUESTS WERE PUSHED OUT OF THE PARTY.";
                str = string_replace_all(str, "*", string(bombTotal));
                scr36_MessageSet(str);
                substate = 20;
            }
        }
    }
}
if (substate == 3)
{
    selOn = false;
    if (bringCounter)
    {
        stateTimer++;
        if (stateTimer == 1)
        {
            messageColor = global.palette[4];
            scr36_MessageSet(scrString("bringer"));
        }
        if (stateTimer == 100)
        {
            bringCounter--;
            stateTimer = 0;
            if (nextNextCard != -4)
            {
                nextCard = nextNextCard;
                nextNextCard = -4;
            }
            else
            {
                nextCard = -4;
            }
            substate = 2;
        }
    }
}
if (substate == 5)
{
    selOn = false;
    stateTimer++;
    if (stateTimer == 270)
    {
        if (popularity[cp] >= 3 || money[cp] >= (capacity[cp] - 3))
        {
            scr36_ChangeState(STATE_STORE);
        }
        else
        {
            scr36_ChangeState(STATE_START_PARTY);
        }
        exit;
    }
}
if (substate == 2)
{
    substate = 9;
    scr36_MessageSet("");
    if (ds_list_size(draw_pile) == 0)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet("NO ONE LEFT IN HOLODEX!");
        bringCounter = 0;
        substate = 1;
        exit;
    }
    tNewCard = 3;
    newCard = ds_list_find_value(draw_pile, 0);
    ds_list_insert(party, 0, newCard);
    ds_list_delete(draw_pile, 0);
    if (greeting)
    {
        scoreStart = 0;
        scoreEnd = 1;
        scr36_ChangeState(STATE_SCORE);
        stateTimer = 68;
        exit;
    }
}
if (substate == 9)
{
    substate = 1;
    var _werewolfArrived = false;
    if (newCard.werewolf)
    {
        _werewolfArrived = true;
        if (!newCard.peacekeeper)
        {
            scrSfx(soundWerewolf, 50);
            messageColor = global.palette[0];
            scr36_MessageSet(string(newCard.name) + " IS DEFENDING");
            newCard.flickerTimer = 32;
            newCard.peacekeeper += newCard.werewolf;
            if (newCard.type == CHAR_WEREWOLF)
            {
                newCard.sprite_index = s36_Werewolf2;
            }
            else if (newCard.tiny)
            {
            }
            else
            {
                newCard.sprite_index = s36_Werewolf2_R;
            }
        }
        else
        {
            scrSfx(soundWerewolf, 50);
            messageColor = global.palette[0];
            scr36_MessageSet(string(newCard.name) + " IS RESTING");
            newCard.flickerTimer = 32;
            newCard.peacekeeper -= newCard.werewolf;
            if (newCard.type == CHAR_WEREWOLF)
            {
                newCard.sprite_index = s36_Werewolf1;
            }
            else if (newCard.tiny)
            {
            }
            else
            {
                newCard.sprite_index = s36_Werewolf1_R;
            }
        }
    }
    var _gopherArrived = false;
    if (newCard.gopher)
    {
        _gopherArrived = true;
        if (!newCard.prestige)
        {
            scrSfx(soundWerewolf, 50);
            messageColor = global.palette[0];
            scr36_MessageSet(string(newCard.name) + " POPPED UP");
            newCard.flickerTimer = 32;
            newCard.prestige += newCard.gopher;
            if (newCard.type == CHAR_DINOSAUR)
            {
                newCard.sprite_index = s36_Dinosaur1;
            }
            else if (newCard.tiny)
            {
            }
        }
        else
        {
            scrSfx(soundWerewolf, 50);
            messageColor = global.palette[0];
            scr36_MessageSet(string(newCard.name) + " RETREATED");
            newCard.flickerTimer = 32;
            newCard.prestige -= newCard.gopher;
            if (newCard.type == CHAR_DINOSAUR)
            {
                newCard.sprite_index = s36_Dinosaur2;
            }
            else if (newCard.tiny)
            {
            }
        }
    }
    var oldTotalTrouble = totalTrouble;
    totalTrouble = scr36_GetTrouble();
    currPrestige = scr36_GetPrestige();
    var bringerArrived = false;
    if (newCard != -4)
    {
        if (newCard.bring > 0)
        {
            bringerArrived = true;
        }
    }
    if (newCard.entranceBonus && newCard.money < 9)
    {
        scrSfx(soundInvestor, 50);
        messageColor = global.palette[11];
        scr36_MessageSet(string(newCard.name) + " JUST EARNED DIVIDENDS.");
        newCard.flickerTimer = 32;
        newCard.money += newCard.entranceBonus;
        if (newCard.flipped)
        {
            newCard.currPop++;
        }
    }
    if (bringerArrived)
    {
        scrSfx(soundBring, 50);
        bringCounter += newCard.bring;
        substate = 3;
    }
    else if (ds_list_size(party) > capacity[cp])
    {
        mute(global.SFX);
        scrBGM(bgm36P_stingPartyEndB, false);
        bgmTrig = false;
        messageColor = global.palette[9];
        scr36_MessageSet("ERROR 36: PARTY OVERFLOW");
        scr36_ChangeState(STATE_BUSTED);
    }
    else if (totalTrouble >= TROUBLE_THRESHOLD)
    {
        mute(global.SFX);
        scrBGM(bgm36P_stingPartyEndB, false);
        bgmTrig = false;
        messageColor = global.palette[9];
        scr36_MessageSet("OH NO! YOU CRASHED YOUR SHIP!");
        scr36_ChangeState(STATE_BUSTED);
    }
    else if (bringCounter)
    {
        substate = 3;
    }
    else if (ds_list_size(party) == capacity[cp])
    {
        var unusedActions = false;
        for (var i = 0; i < ds_list_size(party); i++)
        {
            if (ds_list_find_value(party, i).bounce > 0 || ds_list_find_value(party, i).reshuffle > 0 || ds_list_find_value(party, i).matchmaker > 0 || ds_list_find_value(party, i).upgrade > 0 || ds_list_find_value(party, i).magicSwap > 0 || ds_list_find_value(party, i).banish > 0 || ds_list_find_value(party, i).copyfrog > 0 || ds_list_find_value(party, i).arrow > 0 || ds_list_find_value(party, i).stone > 0 || ds_list_find_value(party, i).bomb > 0)
            {
                ds_list_find_value(party, i).flickerActionTimer = 800;
                unusedActions = true;
            }
        }
        var actionsToBless = false;
        for (var i = 0; i < ds_list_size(party); i++)
        {
            if ((ds_list_find_value(party, i).bouncemax > 0 && ds_list_find_value(party, i).bounce < 4) || (ds_list_find_value(party, i).peekmax > 0 && ds_list_find_value(party, i).peek < 4) || (ds_list_find_value(party, i).phonemax > 0 && ds_list_find_value(party, i).phone < 4) || (ds_list_find_value(party, i).reshufflemax > 0 && ds_list_find_value(party, i).reshuffle < 4) || (ds_list_find_value(party, i).photomax > 0 && ds_list_find_value(party, i).photo < 4) || (ds_list_find_value(party, i).matchmakermax > 0 && ds_list_find_value(party, i).matchmaker < 4) || (ds_list_find_value(party, i).introvertmax > 0 && ds_list_find_value(party, i).introvert < 7) || (ds_list_find_value(party, i).upgrademax > 0 && ds_list_find_value(party, i).upgrade < 4) || (ds_list_find_value(party, i).magicSwapmax > 0 && ds_list_find_value(party, i).magicSwap < 4) || (ds_list_find_value(party, i).greetmax > 0 && ds_list_find_value(party, i).greet < 4) || (ds_list_find_value(party, i).banishmax > 0 && ds_list_find_value(party, i).banish < 4) || (ds_list_find_value(party, i).blessmax > 0 && ds_list_find_value(party, i).bless < 4))
            {
                actionsToBless = true;
            }
        }
        if (actionsToBless)
        {
            for (var i = 0; i < ds_list_size(party); i++)
            {
                if (ds_list_find_value(party, i).bless > 0)
                {
                    ds_list_find_value(party, i).flickerActionTimer = 800;
                    unusedActions = true;
                }
            }
        }
        var prestigeChars = 0;
        for (var i = 0; i < ds_list_size(deck[cp]); i++)
        {
            var c = ds_list_find_value(deck[cp], i);
            if (c.prestige > 0)
            {
                prestigeChars++;
            }
        }
        if (prestigeChars > 0)
        {
            for (var i = 0; i < ds_list_size(party); i++)
            {
                if (ds_list_find_value(party, i).magicSwap > 0)
                {
                    ds_list_find_value(party, i).flickerActionTimer = 800;
                    unusedActions = true;
                }
            }
        }
        if (!unusedActions)
        {
            mute(global.SFX);
            scrBGM(bgm36P_stingPartyEndA, false);
            bgmTrig = false;
            messageColor = global.palette[0];
            with (o36_Card)
            {
                flickerActionTimer = 0;
            }
            nextCard = -4;
            nextNextCard = -4;
            if (!_werewolfArrived)
            {
                scr36_MessageSet(scrString("full_party"));
            }
            scr36_ChangeState(STATE_SCORE);
            phase = PHASE_SCORING;
        }
        else
        {
            scrSfx(soundText, 40);
            messageColor = global.palette[0];
            scr36_MessageSet(scrString("full_party_actions"));
        }
    }
    else if (totalTrouble == (TROUBLE_THRESHOLD - 1) && totalTrouble != oldTotalTrouble)
    {
        scrSfx(soundWarning, 55);
        messageColor = global.palette[9];
        scr36_MessageSet(scrString("warning"));
    }
    else if (newCard.peacekeeper && oldTotalTrouble == (TROUBLE_THRESHOLD - 1) && totalTrouble == (TROUBLE_THRESHOLD - 2))
    {
        scrSfx(soundText, 40);
        troubleWarnStreak = 0;
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("chilled_out"));
    }
    else if (totalTrouble == (TROUBLE_THRESHOLD - 1) && totalTrouble == oldTotalTrouble)
    {
        if (!greeting)
        {
            if (troubleWarnStreak < 4)
            {
                scrSfx(soundWarnStreak[troubleWarnStreak], 40);
            }
            else
            {
                scrSfx(soundWarnStreak[4], 40);
            }
        }
        troubleWarnStreak++;
    }
    else if (ds_list_size(party) == (capacity[cp] - 1))
    {
        if (!greeting)
        {
            scrSfx(soundDoorOpen, 40);
        }
        messageColor = global.palette[0];
        if (!_werewolfArrived)
        {
            scr36_MessageSet(scrString("almost_full"));
        }
    }
    else if (!greeting)
    {
        scrSfx(soundDoorOpen, 40);
    }
    if (bringCounter == 0)
    {
        greeting = false;
    }
}
