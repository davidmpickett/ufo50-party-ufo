if (substate == 0)
{
    substate = 1;
    ds_list_clear(draw_pile_fetch);
    for (var _cost = POP_MAX; _cost >= 1; _cost--)
    {
        for (var i = 0; i < ds_list_size(draw_pile); i++)
        {
            if (ds_list_find_value(draw_pile, i).cost == _cost)
            {
                ds_list_add(draw_pile_fetch, ds_list_find_value(draw_pile, i));
                ds_list_find_value(draw_pile, i).redundant = false;
            }
        }
    }
    var _prevType = -1;
    var _prevPop = -1;
    for (var i = 0; i < ds_list_size(draw_pile_fetch); i++)
    {
        var j = i + 1;
        while (j < ds_list_size(draw_pile_fetch))
        {
            if (ds_list_find_value(draw_pile_fetch, i).popularity == ds_list_find_value(draw_pile_fetch, j).popularity && ds_list_find_value(draw_pile_fetch, i).money == ds_list_find_value(draw_pile_fetch, j).money && ds_list_find_value(draw_pile_fetch, i).name == ds_list_find_value(draw_pile_fetch, j).name && ds_list_find_value(draw_pile_fetch, i).bounce == ds_list_find_value(draw_pile_fetch, j).bounce && ds_list_find_value(draw_pile_fetch, i).peek == ds_list_find_value(draw_pile_fetch, j).peek && ds_list_find_value(draw_pile_fetch, i).phone == ds_list_find_value(draw_pile_fetch, j).phone && ds_list_find_value(draw_pile_fetch, i).reshuffle == ds_list_find_value(draw_pile_fetch, j).reshuffle && ds_list_find_value(draw_pile_fetch, i).photo == ds_list_find_value(draw_pile_fetch, j).photo && ds_list_find_value(draw_pile_fetch, i).matchmaker == ds_list_find_value(draw_pile_fetch, j).matchmaker && ds_list_find_value(draw_pile_fetch, i).upgrade == ds_list_find_value(draw_pile_fetch, j).upgrade && ds_list_find_value(draw_pile_fetch, i).magicSwap == ds_list_find_value(draw_pile_fetch, j).magicSwap && ds_list_find_value(draw_pile_fetch, i).greet == ds_list_find_value(draw_pile_fetch, j).greet && ds_list_find_value(draw_pile_fetch, i).troublemaker == ds_list_find_value(draw_pile_fetch, j).troublemaker && ds_list_find_value(draw_pile_fetch, i).peacekeeper == ds_list_find_value(draw_pile_fetch, j).peacekeeper && ds_list_find_value(draw_pile_fetch, i).introvert == ds_list_find_value(draw_pile_fetch, j).introvert && ds_list_find_value(draw_pile_fetch, i).bless == ds_list_find_value(draw_pile_fetch, j).bless && ds_list_find_value(draw_pile_fetch, i).banish == ds_list_find_value(draw_pile_fetch, j).banish && ds_list_find_value(draw_pile_fetch, i).arrow == ds_list_find_value(draw_pile_fetch, j).arrow && ds_list_find_value(draw_pile_fetch, i).bomb == ds_list_find_value(draw_pile_fetch, j).bomb && ds_list_find_value(draw_pile_fetch, i).stone == ds_list_find_value(draw_pile_fetch, j).stone && ds_list_find_value(draw_pile_fetch, i).prestige == ds_list_find_value(draw_pile_fetch, j).prestige)
            {
                ds_list_find_value(draw_pile_fetch, j).redundant = true;
            }
            j++;
        }
    }
    for (var i = 0; i < ds_list_size(draw_pile_fetch); i++)
    {
        if (ds_list_find_value(draw_pile_fetch, i).redundant)
        {
            ds_list_find_value(draw_pile_fetch, i).redundant = false;
            ds_list_delete(draw_pile_fetch, i);
            i = -1;
        }
    }
    charPos = 0;
}
if (pressLeft)
{
    tFetchNavi = -5;
    charPos--;
    if (charPos < 0)
    {
        charPos = ds_list_size(draw_pile_fetch) - 1;
    }
}
if (pressRight)
{
    tFetchNavi = 5;
    charPos++;
    if (charPos >= ds_list_size(draw_pile_fetch))
    {
        charPos = 0;
    }
}
if (pressLeft || pressRight)
{
    scrSfx(soundNaviE, 21);
}
selCard = ds_list_find_value(draw_pile_fetch, charPos);
if (fire1pressed)
{
    mute(soundOpenFetch);
    mute(soundNaviE);
    scrSfx(soundCancel, 5);
    scr36_MessageSet("");
    scr36_ChangeState(STATE_PARTY);
    exit;
}
else if (fire2pressed && selCard != -4)
{
    doorSoundBuffered = true;
    with (o36_Door)
    {
        image_speed = 0.2;
    }
    actionCard.phone--;
    messageColor = global.palette[7];
    scr36_MessageSet(scrStringVal("fetched", selCard.name));
    for (var i = 0; i < ds_list_size(draw_pile); i++)
    {
        if (ds_list_find_value(draw_pile, i) == selCard)
        {
            ds_list_delete(draw_pile, i);
        }
    }
    ds_list_insert(draw_pile, 0, selCard);
    scr36_ChangeState(STATE_PARTY);
    substate = 2;
}
