function scr36_RefreshCharActions(arg0)
{
    var size, ds;
    if (arg0 == 0)
    {
        ds = deck[cp];
        size = ds_list_size(deck[cp]);
    }
    else
    {
        ds = party;
        size = ds_list_size(party);
    }
    for (var i = 0; i < size; i++)
    {
        var currCard = ds_list_find_value(ds, i);
        currCard.bounce = currCard.bouncemax;
        currCard.peek = currCard.peekmax;
        currCard.phone = currCard.phonemax;
        currCard.reshuffle = currCard.reshufflemax;
        currCard.photo = currCard.photomax;
        currCard.matchmaker = currCard.matchmakermax;
        currCard.reform = currCard.reformmax;
        currCard.upgrade = currCard.upgrademax;
        currCard.magicSwap = currCard.magicSwapmax;
        currCard.greet = currCard.greetmax;
        currCard.introvert = currCard.introvertmax;
        currCard.banish = currCard.banishmax;
        currCard.bless = currCard.blessmax;
        currCard.copyfrog = currCard.copyfrogmax;
        if (arg0 == 0)
        {
            currCard.refresh = currCard.refreshmax;
            currCard.flopped = false;
            if (currCard.reformed)
            {
                currCard.troublemaker = true;
                currCard.reformed = false;
            }
            if (currCard.flipped)
            {
                currCard.flipped = false;
                currCard.popularity = currCard.currPop;
                currCard.money = currCard.currMon;
            }
            if (currCard.popularity > 9)
            {
                currCard.popularity = 9;
            }
            if (currCard.money > 9)
            {
                currCard.money = 9;
            }
            if (currCard.type == CHAR_WRESTLER)
            {
                currCard.sprite_index = s36_Wrestler;
                currCard.name = "JACK & BOX";
            }
            if (currCard.type == CHAR_SECURITY)
            {
                currCard.sprite_index = s36_Security;
                currCard.name = "SPEAR DUDE";
            }
            if (currCard.type == CHAR_HOST)
            {
                currCard.popularity = 0;
                currCard.money = 0;
                currCard.bounce = 0;
                currCard.bring = 0;
                currCard.troublemaker = 0;
                currCard.peacekeeper = 0;
                currCard.peek = 0;
                currCard.dancer = 0;
                currCard.full = 0;
                currCard.phone = 0;
                currCard.reshuffle = 0;
                currCard.photo = 0;
                currCard.matchmaker = 0;
                currCard.schoolpride = 0;
                currCard.oldfriend = 0;
                currCard.introvert = 0;
                currCard.reform = 0;
                currCard.reformed = 0;
                currCard.werewolf = 0;
                currCard.refresh = 0;
                currCard.bless = 0;
                currCard.upgrade = 0;
                currCard.troublePopBonus = 0;
                currCard.troubleMoneyBonus = 0;
                currCard.entranceBonus = 0;
                currCard.magicSwap = 0;
                currCard.greet = 0;
                currCard.banish = 0;
                currCard.phoneLow = 0;
                currCard.flipped = 0;
                currCard.polaroid = 0;
                currCard.copiedsprite = 0;
                currCard.tiny = 0;
            }
        }
    }
}
