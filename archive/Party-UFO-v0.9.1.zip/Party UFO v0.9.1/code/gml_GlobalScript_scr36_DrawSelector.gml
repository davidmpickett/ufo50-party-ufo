function scr36_DrawSelector(arg0, arg1, arg2, arg3)
{
    var img = arg0;
    var card = arg1;
    var xx = arg2;
    var yy = arg3;
    var off = 0;
    if (tSelector > 0)
    {
        off = 1;
    }
    if (card == -4)
    {
        draw_sprite(s36_Selector, img, xx - off, yy - off);
        draw_sprite_ext(s36_Selector, img, xx + 32 + off, yy - off, 1, 1, 270, 16777215, 1);
        draw_sprite_ext(s36_Selector, img, xx - off, yy + 32 + off, 1, 1, 90, 16777215, 1);
        draw_sprite_ext(s36_Selector, img, xx + 32 + off, yy + 32 + off, 1, 1, 180, 16777215, 1);
        exit;
    }
    draw_sprite(s36_Selector, img, xx - off, yy - off);
    if (!card.troublemaker && !card.phone && !card.bounce && !card.dancer && !card.peek && !card.peacekeeper && !card.full && !card.bring && !card.prestige && !card.introvert && !card.reshuffle && !card.schoolpride && !card.troublePopBonus && !card.entranceBonus && !card.photo && !card.refresh && !card.upgrade && !card.reform && !card.troubleMoneyBonus && !card.werewolf && !card.copyfrog && !card.magicSwap && !card.matchmaker && !card.banish && !card.bless)
    {
        draw_sprite_ext(s36_Selector, img, xx + 32 + off, yy - off, 1, 1, 270, 16777215, 1);
    }
    draw_sprite_ext(s36_Selector, img, xx - off, yy + 32 + off, 1, 1, 90, 16777215, 1);
    if (card.money == 0 && !card.prestigeLow)
    {
        if (card.phoneLow && card.phone)
        {
        }
        else
        {
            draw_sprite_ext(s36_Selector, img, xx + 32 + off, yy + 32 + off, 1, 1, 180, 16777215, 1);
        }
    }
}
