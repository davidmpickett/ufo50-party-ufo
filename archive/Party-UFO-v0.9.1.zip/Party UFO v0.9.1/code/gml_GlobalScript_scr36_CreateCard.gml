function scr36_CreateCard(arg0)
{
    card = instance_create(0, 0, o36_Card);
    card.type = arg0;
    card.visible = false;
    card.image_index = scrIRandomRange(1, 3);
    card.image_yscale = 1;
    switch (card.type)
    {
        case CHAR_ROLODEX_EXIT:
            card.sprite_index = s36_RolodexExit;
            card.name = scrString("exit");
            break;
        case CHAR_DIVIDER:
            card.sprite_index = s36_Divider;
            card.name = scrString("divider");
            break;
        case CHAR_DIVIDER_BANNED:
            card.sprite_index = s36_DividerBanned;
            card.name = scrString("divider");
            break;
        case CHAR_EXPAND:
            card.moneyCost = 2;
            card.sprite_index = s36_Expand;
            card.name = scrString("expand");
            card.supply = STORE_SUPPLY + 1;
            break;
        case CHAR_BOUNCE_TOP:
            card.cost = 1;
            card.maxcost = 1;
            card.sprite_index = s36_ClownTop;
            card.name = "JACK";
            break;
        case CHAR_COOL_BUDDY_M:
            card.cost = 2;
            card.maxcost = 2;
            card.popularity = 1;
            card.sprite_index = s36_GoodBuddyM;
            card.name = "OPPIE";
            card.oldfriend = 1;
            break;
        case CHAR_COOL_BUDDY_M_2:
            card.cost = 2;
            card.maxcost = 2;
            card.popularity = 1;
            card.sprite_index = s36_GoodBuddy2M;
            card.name = "OPPIE";
            card.oldfriend = 1;
            break;
        case CHAR_COOL_BUDDY_F:
            card.cost = 2;
            card.maxcost = 2;
            card.popularity = 1;
            card.sprite_index = s36_GoodBuddyF;
            card.name = "OPPIE";
            card.oldfriend = 1;
            break;
        case CHAR_COOL_BUDDY_F_2:
            card.cost = 2;
            card.maxcost = 2;
            card.popularity = 1;
            card.sprite_index = s36_GoodBuddy2F;
            card.name = "OPPIE";
            card.oldfriend = 1;
            break;
        case CHAR_WILD_FRIEND_M:
            card.cost = 1;
            card.maxcost = 1;
            card.popularity = 2;
            card.troublemaker = 1;
            card.sprite_index = s36_WildFriendM;
            card.name = "UFO CRASHR";
            break;
        case CHAR_WILD_FRIEND_F:
            card.cost = 1;
            card.maxcost = 1;
            card.popularity = 2;
            card.troublemaker = 1;
            card.sprite_index = s36_WildFriendF;
            card.name = "UFO CRASHR";
            break;
        case CHAR_WILD_FRIEND_M_2:
            card.cost = 1;
            card.maxcost = 1;
            card.popularity = 2;
            card.troublemaker = 1;
            card.sprite_index = s36_WildFriendM2;
            card.name = "UFO CRASHR";
            break;
        case CHAR_WILD_FRIEND_F_2:
            card.cost = 1;
            card.maxcost = 1;
            card.popularity = 2;
            card.troublemaker = 1;
            card.sprite_index = s36_WildFriendF2;
            card.name = "UFO CRASHR";
            break;
        case CHAR_RICH_FRIEND_M:
            card.cost = 2;
            card.maxcost = 2;
            card.money = 1;
            card.sprite_index = s36_RichFriendM;
            card.name = "COUNT BEAN";
            break;
        case CHAR_RICH_FRIEND_F:
            card.cost = 2;
            card.maxcost = 2;
            card.money = 1;
            card.sprite_index = s36_RichFriendF;
            card.name = "COUNT BEAN";
            break;
        case CHAR_MONKEY:
            card.cost = 4;
            card.maxcost = 4;
            card.popularity = 4;
            card.money = 1;
            card.troublemaker = 1;
            card.sprite_index = s36_Monkey;
            card.name = "PIRATE";
            break;
        case CHAR_ROCK_STAR:
            card.cost = 4;
            card.maxcost = 4;
            card.popularity = 1;
            card.money = 3;
            card.troublemaker = 1;
            card.sprite_index = s36_Rockstar;
            card.name = "ROCK GIRL";
            break;
        case CHAR_MR_POPULAR:
            card.cost = 7;
            card.maxcost = 7;
            card.popularity = 4;
            card.money = 0;
            card.bring = 1;
            card.sprite_index = s36_Mascot;
            card.name = "JESTER";
            break;
        case CHAR_TICKET_TAKER:
            card.cost = 10;
            card.maxcost = 10;
            card.popularity = -2;
            card.money = 4;
            card.sprite_index = s36_TicketTaker;
            card.name = "TIME JELLY";
            break;
        case CHAR_CATERER:
            card.cost = 8;
            card.maxcost = 8;
            card.popularity = 3;
            card.money = 3;
            card.troublemaker = 1;
            card.sprite_index = s36_Caterer;
            card.name = "CARD BUNNY";
            break;
        case CHAR_HIPPY:
            card.cost = 5;
            card.maxcost = 5;
            card.popularity = 3;
            card.money = -1;
            card.peacekeeper = 1;
            card.sprite_index = s36_Hippy;
            card.name = "GOGO IMP";
            break;
        case CHAR_SECURITY:
            card.cost = 4;
            card.maxcost = 4;
            card.popularity = 2;
            card.money = 0;
            card.bounce = 1;
            card.bouncemax = 1;
            card.sprite_index = s36_Security;
            card.name = "SPEAR DUDE";
            break;
        case CHAR_DOG:
            card.cost = 4;
            card.maxcost = 4;
            card.popularity = 1;
            card.peek = 1;
            card.peekmax = 1;
            card.sprite_index = s36_Dog;
            card.name = "NEWS ANCHR";
            break;
        case CHAR_COMEDIAN:
            card.cost = 7;
            card.maxcost = 7;
            card.popularity = 2;
            card.money = -2;
            card.full = 2;
            card.sprite_index = s36_Comedian;
            card.name = "MAYOR";
            break;
        case CHAR_DANCER:
            card.cost = 5;
            card.maxcost = 5;
            card.popularity = 0;
            card.dancer = 1;
            card.sprite_index = s36_Dancer;
            card.name = "QUIBBLE";
            break;
        case CHAR_DRIVER:
            card.cost = 3;
            card.maxcost = 3;
            card.phone = 1;
            card.phonemax = 1;
            card.troublemaker = 1;
            card.money = 2;
            card.sprite_index = s36_Driver;
            card.name = "ONIONMAN";
            break;
        case CHAR_AUCTIONEER:
            card.cost = 5;
            card.maxcost = 5;
            card.money = 1;
            card.popularity = 1;
            card.sprite_index = s36_Auctioneer;
            card.name = "SHY LIZARD";
            break;
        case CHAR_WRESTLER:
            card.cost = 5;
            card.maxcost = 5;
            card.money = 1;
            card.bounce = 1;
            card.bouncemax = 1;
            card.sprite_index = s36_Wrestler;
            card.name = "JACK & BOX";
            break;
        case CHAR_GRILLMASTER:
            card.popularity = 2;
            card.maxcost = 2;
            card.cost = 5;
            card.reshuffle = 1;
            card.reshufflemax = 1;
            card.sprite_index = s36_Grillmaster;
            card.name = "COACH";
            break;
        case CHAR_PHOTOGRAPHER:
            card.cost = 6;
            card.maxcost = 6;
            card.money = -1;
            card.popularity = 2;
            card.photo = 1;
            card.photomax = 1;
            card.sprite_index = s36_Photographer;
            card.name = "PHOTO MOM";
            break;
        case CHAR_CUPID:
            card.popularity = 1;
            card.cost = 8;
            card.maxcost = 8;
            card.matchmaker = 1;
            card.matchmakermax = 1;
            card.sprite_index = s36_Cupid;
            card.name = "SHRINKER";
            break;
        case CHAR_CELEBRITY:
            card.popularity = 5;
            card.money = 1;
            card.cost = 9;
            card.maxcost = 9;
            card.bring = 2;
            card.sprite_index = s36_Celebrity;
            card.name = "DIVERS";
            break;
        case CHAR_PRIVATE_I:
            card.popularity = 2;
            card.cost = 9;
            card.maxcost = 9;
            card.phone = 1;
            card.phonemax = 1;
            card.sprite_index = s36_PrivateI;
            card.name = "SEA DRIVER";
            break;
        case CHAR_GANGSTER:
            card.popularity = 3;
            card.cost = 7;
            card.maxcost = 7;
            card.sprite_index = s36_Gangster;
            card.name = "COOL SLUG";
            break;
        case CHAR_MASCOT:
            card.popularity = 1;
            card.cost = 4;
            card.maxcost = 4;
            card.schoolpride = 1;
            card.sprite_index = s36_MrPopular;
            card.name = "GARDENER";
            break;
        case CHAR_INTROVERT:
            card.popularity = 1;
            card.cost = 4;
            card.maxcost = 4;
            card.introvert = 3;
            card.introvertmax = 3;
            card.sprite_index = s36_Introvert;
            card.name = "DROP SHIP";
            break;
        case CHAR_COUNSELOR:
            card.cost = 7;
            card.maxcost = 7;
            card.popularity = -2;
            card.banish = 1;
            card.banishmax = 1;
            card.sprite_index = s36_Counselor;
            card.name = "FAMILY MAN";
            break;
        case CHAR_STYLIST:
            card.cost = 7;
            card.maxcost = 7;
            card.upgrade = 1;
            card.upgrademax = 1;
            card.sprite_index = s36_Stylist;
            card.name = "VAMPIRE";
            break;
        case CHAR_GAMBLER:
            card.popularity = -1;
            card.money = 2;
            card.cost = 4;
            card.maxcost = 4;
            card.sprite_index = s36_Gambler2;
            card.name = "GLADIATOR";
            break;
        case CHAR_BARTENDER:
            card.money = 1;
            card.troubleMoneyBonus = 1;
            card.cost = 6;
            card.maxcost = 6;
            card.sprite_index = s36_Bartender;
            card.name = "SHOPKEEP";
            break;
        case CHAR_WRITER:
            card.troublePopBonus = 3;
            card.cost = 12;
            card.maxcost = 12;
            card.sprite_index = s36_Writer;
            card.name = "LX-3-BOT";
            break;
        case CHAR_CLIMBER:
            card.popularity = 0;
            card.entranceBonus = 1;
            card.troublemaker = 1;
            card.cost = 7;
            card.maxcost = 7;
            card.sprite_index = s36_Climber;
            card.name = "OUTLAW";
            break;
        case CHAR_SPY:
            card.cost = 7;
            card.maxcost = 7;
            card.money = 1;
            card.peek = 1;
            card.peekmax = 1;
            card.sprite_index = s36_Spy;
            card.name = "CYBER OWL";
            break;
        case CHAR_CUTE_DOG:
            card.cost = 3;
            card.maxcost = 3;
            card.popularity = -1;
            card.peacekeeper = 1;
            card.sprite_index = s36_CuteDog;
            card.name = "CLAPPER";
            break;
        case CHAR_MAGICIAN:
            card.cost = 6;
            card.maxcost = 6;
            card.popularity = 1;
            card.money = 0;
            card.magicSwap = 1;
            card.magicSwapmax = 1;
            card.sprite_index = s36_Magician;
            card.name = "FLIPPER";
            break;
        case CHAR_ATHLETE:
            card.cost = 10;
            card.maxcost = 10;
            card.money = 2;
            card.reshuffle = 1;
            card.reshufflemax = 1;
            card.sprite_index = s36_Athlete;
            card.name = "SAMURAI";
            break;
        case CHAR_HOST:
            card.cost = 8;
            card.maxcost = 8;
            card.copyfrog = 1;
            card.copyfrogmax = 1;
            card.sprite_index = s36_Host;
            card.name = "COPY FROG";
            break;
        case CHAR_WEREWOLF:
            card.cost = 9;
            card.maxcost = 9;
            card.popularity = 3;
            card.money = 0;
            card.werewolf = 1;
            card.sprite_index = s36_Werewolf1;
            card.name = "UMBRELLA";
            break;
        case CHAR_CHEERLEADER:
            card.cost = 3;
            card.maxcost = 3;
            card.bless = 1;
            card.blessmax = 1;
            card.sprite_index = s36_Cheerleader;
            card.name = "BRONTOLYTE";
            break;
        case CHAR_ALIEN:
            card.cost = 36;
            card.maxcost = 36;
            card.prestige = 1;
            card.popularity = 2;
            card.sprite_index = s36_Alien;
            card.name = "HUMAN";
            card.supply = STORE_SUPPLY + 1;
            break;
        case CHAR_DINOSAUR:
            card.cost = 18;
            card.maxcost = 18;
            card.prestige = 1;
            card.prestigeLow = true;
            card.troublemaker = 2;
            card.sprite_index = s36_Dinosaur;
            card.name = "GUARDIAN";
            card.supply = STORE_SUPPLY + 1;
            break;
        case CHAR_LEPRECHAUN:
            card.cost = 42;
            card.maxcost = 42;
            card.prestige = 1;
            card.magicSwap = 1;
            card.magicSwapmax = 1;
            card.prestigeLow = true;
            card.sprite_index = s36_Leprechaun;
            card.name = "REVERSOID";
            card.supply = STORE_SUPPLY + 1;
            break;
        case CHAR_GENIE:
            card.cost = 60;
            card.maxcost = 60;
            card.prestige = 1;
            card.prestigeLow = true;
            card.phone = 1;
            card.phonemax = 1;
            card.sprite_index = s36_Genie;
            card.name = "OCTOPUS";
            card.supply = STORE_SUPPLY + 1;
            break;
        case CHAR_MERMAID:
            card.cost = 30;
            card.maxcost = 30;
            card.prestige = 1;
            card.bring = 2;
            card.prestigeLow = true;
            card.sprite_index = s36_Mermaid;
            card.name = "BUG HIVE";
            card.supply = STORE_SUPPLY + 1;
            break;
        case CHAR_DRAGON:
            card.cost = 24;
            card.maxcost = 24;
            card.prestige = 1;
            card.money = -4;
            card.sprite_index = s36_Ghost;
            card.name = "PLUTOCRAT";
            card.supply = STORE_SUPPLY + 1;
            break;
        case CHAR_GHOST:
            card.cost = 48;
            card.maxcost = 48;
            card.prestige = 1;
            card.prestigeLow = true;
            card.bounce = 1;
            card.bouncemax = 1;
            card.sprite_index = s36_Dragon;
            card.name = "RED QUEEN";
            card.supply = STORE_SUPPLY + 1;
            break;
        case CHAR_UNICORN:
            card.cost = 54;
            card.maxcost = 54;
            card.prestige = 1;
            card.prestigeLow = true;
            card.peacekeeper = 1;
            card.sprite_index = s36_Unicorn;
            card.name = "BARDOK!?";
            card.supply = STORE_SUPPLY + 1;
            break;
        case CHAR_SUPERHERO:
            card.cost = 54;
            card.maxcost = 54;
            card.prestige = 1;
            card.popularity = 6;
            card.sprite_index = s36_Superhero;
            card.name = "PRINCESS";
            card.supply = STORE_SUPPLY + 1;
            break;
        case CHAR_THE_HOST:
            card.cost = 60;
            card.maxcost = 60;
            card.prestige = 4;
            card.popularity = 30;
            card.sprite_index = s36_Amy;
            card.name = scrStringExt("char_the_host", 0, 10, 0);
            card.supply = STORE_SUPPLY + 1;
            break;
    }
    return card;
}
