function scr36_DrawCard(arg0, arg1, arg2, arg3, arg4)
{
    var dCard = arg0;
    var xCard = arg1;
    var yCard = arg2;
    var yOffset = arg3;
    if (!verify(dCard))
    {
        exit;
    }
    if (dCard.polaroid)
    {
        draw_sprite(s36_Icons, 40, arg1, arg2);
    }
    if (dCard.flickerTimer)
    {
        draw_sprite(s36_Flicker, flicker8, arg1, arg2);
    }
    if (!dCard.tiny)
    {
        if (dCard.flipped == 1)
        {
            if (dCard.flopped == 1)
            {
                draw_sprite_ext(dCard.sprite_index, dCard.image_index, arg1 + 31, arg2 + yOffset + 31, -1, -1, 0, -1, 1);
            }
            else
            {
                draw_sprite_ext(dCard.sprite_index, dCard.image_index, arg1, arg2 + yOffset + 31, 1, -1, 0, -1, 1);
            }
        }
        else if (dCard.flopped == 1)
        {
            draw_sprite_ext(dCard.sprite_index, dCard.image_index, arg1 + 31, arg2 + yOffset, -1, 1, 0, -1, 1);
        }
        else
        {
            draw_sprite(dCard.sprite_index, dCard.image_index, arg1, arg2 + yOffset);
        }
    }
    else
    {
        if (dCard.tinyFlipped1 == 1)
        {
            draw_sprite_ext(dCard.tinySprite1, dCard.image_index, arg1, arg2 + yOffset + 15, 0.5, -0.5, 0, -1, 1);
        }
        else
        {
            draw_sprite_ext(dCard.tinySprite1, dCard.image_index, arg1, arg2 + yOffset + 15, 0.5, 0.5, 0, -1, 1);
        }
        if (dCard.tinyFlipped2 == 1)
        {
            draw_sprite_ext(dCard.tinySprite2, dCard.image_index, arg1 + 15, arg2 + yOffset + 15, 0.5, -0.5, 0, -1, 1);
        }
        else
        {
            draw_sprite_ext(dCard.tinySprite2, dCard.image_index, arg1 + 15, arg2 + yOffset + 15, 0.5, 0.5, 0, -1, 1);
        }
    }
    if (dCard.grayedOut)
    {
    }
    if (dCard.polaroid)
    {
        draw_sprite(s36_Icons, 39, arg1, arg2);
    }
    scrSetFont(global.fontDefault);
    if (dCard.popularity > 0 && dCard.popularity < 10)
    {
        draw_set_color(global.palette[3]);
        scr36_DrawTextBG(arg1 + 24, arg2 + 12, string(dCard.popularity), 0, false);
    }
    else if (dCard.popularity > 9)
    {
        draw_set_color(global.palette[3]);
        scr36_DrawTextBG(arg1 + 16, arg2 + 12, string(dCard.popularity), 0, false);
    }
    if (dCard.popularity < 0)
    {
        draw_sprite(s36_Icons, 6, arg1 + 23, arg2 + 11);
        draw_set_color(global.palette[3]);
        scr36_DrawTextBG(arg1 + 24, arg2 + 12, string(abs(dCard.popularity)), global.palette[17], false);
    }
    if (dCard.money > 0 && dCard.money < 10)
    {
        draw_set_color(global.palette[11]);
        scr36_DrawTextBG(arg1 + 24, arg2 + 24, string(dCard.money), 0, false);
    }
    else if (dCard.money > 9)
    {
        draw_set_color(global.palette[11]);
        scr36_DrawTextBG(arg1 + 16, arg2 + 24, string(dCard.money), 0, false);
    }
    if (dCard.money < 0)
    {
        draw_sprite(s36_Icons, 6, arg1 + 23, arg2 + 23);
        draw_set_color(global.palette[11]);
        scr36_DrawTextBG(arg1 + 24, arg2 + 24, string(abs(dCard.money)), global.palette[17], false);
    }
    var iconIndex = 0;
    iconList = ds_list_create();
    ds_list_clear(iconList);
    if (dCard.troublemaker)
    {
        for (i = 0; i < dCard.troublemaker; i++)
        {
            ds_list_add(iconList, 7);
            iconIndex++;
        }
    }
    if (dCard.peacekeeper)
    {
        for (i = 0; i < dCard.peacekeeper; i++)
        {
            ds_list_add(iconList, 8);
            iconIndex++;
        }
    }
    if (dCard.prestige)
    {
        if (!dCard.prestigeLow)
        {
            for (i = 0; i < dCard.prestige; i++)
            {
                ds_list_add(iconList, 16);
                iconIndex++;
            }
        }
        else
        {
            draw_sprite(s36_Icons, 24, arg1, arg2);
        }
    }
    if (dCard.bring > 0)
    {
        ds_list_add(iconList, 9);
        iconIndex++;
    }
    if (dCard.troublePopBonus)
    {
        if (!dCard.flickerActionTimer || flicker8)
        {
            ds_list_add(iconList, 26);
            iconIndex++;
        }
    }
    if (dCard.troubleMoneyBonus)
    {
        if (!dCard.flickerActionTimer || flicker8)
        {
            ds_list_add(iconList, 27);
            iconIndex++;
        }
    }
    if (dCard.full)
    {
        ds_list_add(iconList, 21);
        iconIndex++;
    }
    if (dCard.dancer)
    {
        for (i = 0; i < dCard.dancer; i++)
        {
            ds_list_add(iconList, 13);
            iconIndex++;
        }
    }
    if (dCard.schoolpride)
    {
        ds_list_add(iconList, 18);
        iconIndex++;
    }
    if (dCard.werewolf && !dCard.peacekeeper)
    {
        ds_list_add(iconList, 30);
        iconIndex++;
    }
    if (dCard.bounce)
    {
        if (!dCard.flickerActionTimer || flicker8)
        {
            for (i = 0; i < dCard.bounce; i++)
            {
                ds_list_add(iconList, 10);
                iconIndex++;
            }
        }
    }
    if (dCard.reshuffle)
    {
        if (!dCard.flickerActionTimer || flicker8)
        {
            for (i = 0; i < dCard.reshuffle; i++)
            {
                ds_list_add(iconList, 17);
                iconIndex++;
            }
        }
    }
    if (dCard.photo)
    {
        if (!dCard.flickerActionTimer || flicker8)
        {
            for (i = 0; i < dCard.photo; i++)
            {
                ds_list_add(iconList, 2);
                iconIndex++;
            }
        }
    }
    if (dCard.matchmaker)
    {
        if (!dCard.flickerActionTimer || flicker8)
        {
            for (i = 0; i < dCard.matchmaker; i++)
            {
                ds_list_add(iconList, 1);
                iconIndex++;
            }
        }
    }
    if (dCard.peek)
    {
        if (!dCard.flickerActionTimer || flicker8)
        {
            for (i = 0; i < dCard.peek; i++)
            {
                ds_list_add(iconList, 11);
                iconIndex++;
            }
        }
    }
    if (dCard.upgrade)
    {
        if (!dCard.flickerActionTimer || flicker8)
        {
            for (i = 0; i < dCard.upgrade; i++)
            {
                ds_list_add(iconList, 23);
                iconIndex++;
            }
        }
    }
    if (dCard.magicSwap)
    {
        if (!dCard.flickerActionTimer || flicker8)
        {
            for (i = 0; i < dCard.magicSwap; i++)
            {
                ds_list_add(iconList, 28);
                iconIndex++;
            }
        }
    }
    if (dCard.entranceBonus)
    {
        if (!dCard.flickerActionTimer || flicker8)
        {
            draw_sprite(s36_Icons, 25, arg1, arg2);
        }
    }
    if (dCard.introvert)
    {
        if (!dCard.flickerActionTimer || flicker8)
        {
            for (i = 0; i < dCard.introvert; i += 3)
            {
                ds_list_add(iconList, 19);
                iconIndex++;
            }
        }
    }
    if (dCard.banish)
    {
        if (!dCard.flickerActionTimer || flicker8)
        {
            for (i = 0; i < dCard.banish; i++)
            {
                ds_list_add(iconList, 38);
                iconIndex++;
            }
        }
    }
    if (dCard.bless)
    {
        if (!dCard.flickerActionTimer || flicker8)
        {
            for (i = 0; i < dCard.bless; i++)
            {
                ds_list_add(iconList, 42);
                iconIndex++;
            }
        }
    }
    if (dCard.phone)
    {
        if (!dCard.flickerActionTimer || flicker8)
        {
            for (i = 0; i < dCard.phone; i++)
            {
                ds_list_add(iconList, 15);
                iconIndex++;
            }
        }
    }
    if (dCard.copyfrog)
    {
        if (!dCard.flickerActionTimer || flicker8)
        {
            ds_list_add(iconList, 29);
            iconIndex++;
        }
    }
    if (iconIndex > 0)
    {
        for (i = 0; i < (iconIndex + 1); i++)
        {
            if (!is_undefined(ds_list_find_value(iconList, i)))
            {
                if (i < 4)
                {
                    draw_sprite(s36_Icons, ds_list_find_value(iconList, i), arg1 - (i * 8), arg2);
                }
                else if (i > 3 && i < 7)
                {
                    draw_sprite(s36_Icons, ds_list_find_value(iconList, i), arg1 - ((7 - i) * 8), arg2 + 8);
                }
                else if (i > 6 && i < 10)
                {
                    draw_sprite(s36_Icons, ds_list_find_value(iconList, i), arg1 - ((i - 6) * 8), arg2 + 16);
                }
                else if (i > 9 && i < 13)
                {
                    draw_sprite(s36_Icons, ds_list_find_value(iconList, i), arg1 - ((13 - i) * 8), arg2 + 24);
                }
            }
        }
    }
    ds_list_destroy(iconList);
    if (dCard.type == CHAR_EXPAND)
    {
        draw_set_color(16777215);
        if (capacity[cp] < 10)
        {
            scr36_DrawTextBG(arg1 + 8, arg2 + 24, "0" + string(capacity[cp]), 0, false);
        }
        else
        {
            scr36_DrawTextBG(arg1 + 8, arg2 + 24, string(capacity[cp]), 0, false);
        }
    }
}
