function scr36_DrawSelector(arg0, arg1, arg2, arg3)
{
    var img = arg0;
    var card = arg1;
    var xx = arg2;
    var yy = arg3;
    var off = 0;
    if (tSelector > 0)
    {
        off = 1;
    }
    if (card == -4)
    {
        draw_sprite(s36_Selector, img, xx - off, yy - off);
        draw_sprite_ext(s36_Selector, img, xx + 32 + off, yy - off, 1, 1, 270, c_white, 1);
        draw_sprite_ext(s36_Selector, img, xx - off, yy + 32 + off, 1, 1, 90, c_white, 1);
        draw_sprite_ext(s36_Selector, img, xx + 32 + off, yy + 32 + off, 1, 1, 180, c_white, 1);
        exit;
    }
    totalIcons = card.troublemaker + card.phone + card.bounce + card.dancer + card.peek + card.peacekeeper + card.full + card.reshuffle + card.schoolpride + card.troublePopBonus + card.photo + card.refresh + card.upgrade + card.reform + card.troubleMoneyBonus + card.werewolf + card.copyfrog + card.magicSwap + card.matchmaker + card.banish + card.bless + card.stone + card.arrow + card.bomb;
    if (card.bring)
    {
        totalIcons++;
    }
    if (!card.prestigeLow)
    {
        totalIcons += card.prestige;
    }
    if (card.introvert)
    {
        if (card.introvert <= 3)
        {
            totalIcons++;
        }
        else if (card.introvert > 3 && card.introvert < 7)
        {
            totalIcons += 2;
        }
        else if (card.introvert >= 7)
        {
            totalIcons += 3;
        }
    }
    if (card.entranceBonus || card.type == CHAR_CELEBRITY_D || card.type == CHAR_CELEBRITY || card.type == CHAR_SECURITY_R || card.bless || totalIcons > 3)
    {
    }
    else
    {
        draw_sprite(s36_Selector, img, xx - off, yy - off);
    }
    if (!card.troublemaker && !card.phone && !card.bounce && !card.dancer && !card.peek && !card.peacekeeper && !card.full && !card.bring && !card.prestige && !card.introvert && !card.reshuffle && !card.schoolpride && !card.troublePopBonus && !card.entranceBonus && !card.photo && !card.refresh && !card.upgrade && !card.reform && !card.troubleMoneyBonus && !card.werewolf && !card.copyfrog && !card.magicSwap && !card.matchmaker && !card.banish && !card.bless && !card.stone && !card.arrow && !card.bomb)
    {
        draw_sprite_ext(s36_Selector, img, xx + 32 + off, yy - off, 1, 1, 270, c_white, 1);
    }
    draw_sprite_ext(s36_Selector, img, xx - off, yy + 32 + off, 1, 1, 90, c_white, 1);
    if (card.money == 0 && !card.prestigeLow)
    {
        if (card.phoneLow && card.phone)
        {
        }
        else
        {
            draw_sprite_ext(s36_Selector, img, xx + 32 + off, yy + 32 + off, 1, 1, 180, c_white, 1);
        }
    }
}
