if (substate == 0)
{
    substate = 1;
    selectorX = 0;
    selectorY = 0;
    pageY = 0;
    draw_set_color(c_white);
    scr36_MessageSet(scrString("open_rolodex"));
    ds_list_clear(rolodex);
    ds_list_add(rolodex, rolodexExit);
    if (phase == PHASE_PARTY)
    {
        for (var t = 0; t < 100; t++)
        {
            for (var i = 0; i < ds_list_size(draw_pile); i++)
            {
                if (ds_list_find_value(draw_pile, i).type == t)
                {
                    var _card = ds_list_find_value(draw_pile, i);
                    _card.grayedOut = false;
                    if (_card.echo && echoSwap)
                    {
                        e = _card.myecho;
                        foundecho = false;
                        for (var me = 0; me < ds_list_size(rolodex); me++)
                        {
                            if (foundecho == false)
                            {
                                if (ds_list_find_value(rolodex, me).type == e)
                                {
                                    ds_list_insert(rolodex, me, _card);
                                    foundecho = true;
                                }
                            }
                        }
                        if (foundecho == false)
                        {
                            ds_list_add(rolodex, _card);
                        }
                    }
                    else
                    {
                        ds_list_add(rolodex, _card);
                    }
                }
            }
        }
        if (ds_list_size(party) > 0)
        {
            ds_list_add(rolodex, divider);
            for (var i = 0; i < ds_list_size(party); i++)
            {
                var _card = ds_list_find_value(party, i);
                _card.grayedOut = true;
                ds_list_add(rolodex, _card);
            }
        }
        if (ds_list_size(booted) > 0)
        {
            ds_list_add(rolodex, dividerBanned);
            for (var i = 0; i < ds_list_size(booted); i++)
            {
                var _card = ds_list_find_value(booted, i);
                _card.grayedOut = true;
                ds_list_add(rolodex, _card);
            }
        }
    }
    else if (phase == PHASE_SHOP)
    {
        for (var t = 0; t < 100; t++)
        {
            for (var i = 0; i < ds_list_size(deck[cp]); i++)
            {
                var currCard = ds_list_find_value(deck[cp], i);
                if (currCard.type == t)
                {
                    if (currCard.echo && echoSwap)
                    {
                        e = currCard.myecho;
                        foundecho = false;
                        for (var me = 0; me < ds_list_size(rolodex); me++)
                        {
                            if (foundecho == false)
                            {
                                if (ds_list_find_value(rolodex, me).type == e)
                                {
                                    ds_list_insert(rolodex, me, currCard);
                                    foundecho = true;
                                }
                            }
                        }
                        if (foundecho == false)
                        {
                            ds_list_add(rolodex, currCard);
                        }
                    }
                    else
                    {
                        ds_list_add(rolodex, currCard);
                    }
                }
            }
        }
        scr36_RefreshCharActions(0);
    }
}
if (substate == 1)
{
    stateTimer++;
    if (stateTimer > 36)
    {
        selOn = true;
        substate = 2;
        clearMessage = true;
    }
}
if (substate == 2)
{
    if (stateTimer <= 100)
    {
        stateTimer++;
    }
    if (stateTimer == 100 && clearMessage)
    {
        scr36_MessageSet("");
    }
    var moved = scr36_HandleMovement(0, ds_list_size(rolodex));
    if (moved)
    {
        scrSfx(soundNaviB, 10);
    }
    selIndex = scr36_GetIndex(selectorX, selectorY, 0);
    if (selIndex >= 0 && selIndex < ds_list_size(rolodex))
    {
        selCard = ds_list_find_value(rolodex, selIndex);
    }
    else
    {
        selCard = -4;
    }
    if (selIndex >= (ROLODEX_PAGE_MAX + (pageY * 9)) || selIndex < (pageY * 9))
    {
        pageY = ceil(((selIndex + 1) - ROLODEX_PAGE_MAX) / 9);
        if (pageY < 0)
        {
            pageY = 0;
        }
    }
    if (fire1pressed)
    {
        if (selIndex == 0)
        {
            selOn = false;
            stateTimer = 200;
            substate = 3;
            scr36_MessageSet("");
            exit;
        }
        else
        {
            scrSfx(soundNaviB, 10);
            selectorX = 0;
            selectorY = 0;
            selIndex = scr36_GetIndex(selectorX, selectorY, 0);
        }
    }
    else if (fire2pressed && selCard != -4)
    {
        if (selCard.type == CHAR_ROLODEX_EXIT)
        {
            selOn = false;
            stateTimer = 200;
            substate = 3;
            scr36_MessageSet("");
        }
        else
        {
            scrSfx(soundText, 15);
            messageColor = 16777215;
            scr36_MessageSet(scrString("no_rolodex_actions"));
            clearMessage = false;
        }
    }
}
if (substate == 3)
{
    if (stateTimer++ >= 216)
    {
        with (o36_Card)
        {
            grayedOut = false;
        }
        if (phase == PHASE_PARTY)
        {
            scr36_ChangeState(STATE_PARTY);
        }
        else if (phase == PHASE_SHOP)
        {
            scr36_ChangeState(STATE_STORE);
        }
    }
}
