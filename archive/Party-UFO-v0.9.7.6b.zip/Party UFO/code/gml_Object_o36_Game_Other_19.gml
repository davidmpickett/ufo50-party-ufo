if (substate == 0)
{
    scrBGM(bgm36P_stingLose, false);
    substate = 1;
    messageColor = global.palette[9];
    if (scenarioIndex == 5 && scenarioWins[5] != 0)
    {
        scr36_MessageSet(scrString("out_of_time_streak"));
    }
    else
    {
        scr36_MessageSet(scrString("out_of_time"));
    }
    time[cp] = 0;
    if (scenarioIndex == 5)
    {
        scenarioWins[5] = 0;
    }
    scrSaveGame(0);
}
if (substate == 1)
{
    stateTimer++;
    if (stateTimer == 300)
    {
        if (scenarioIndex == 5 && global.cheatID == 0 && numPlayers == 1)
        {
            scr36_MessageSet(scrString("retry_scenario"), true);
            substate = 3;
            messageColor = 16777215;
        }
        else
        {
            scrTransition(-1, 30, 0, -10, false);
            substate++;
        }
    }
}
if (substate == 2)
{
    if (scrTransitionDone())
    {
        if (global.cheatID <= 0)
        {
            scr36_ChangeState(STATE_SCENARIO_SELECT);
        }
        else if (global.cheatID == 1)
        {
            scr36_ChangeState(STATE_SEED_SELECTION);
        }
        else if (global.cheatID == 2)
        {
            scr36_ChangeState(STATE_MAKE_SHOP);
        }
    }
}
if (substate == 3)
{
    answerX = 0;
    if (textMessagePos >= textMessageLength)
    {
        substate = 4;
    }
}
if (substate == 4)
{
    if (pressLeft || pressRight)
    {
        answerX = !answerX;
        scrSfx(soundNaviC, 50);
    }
    if (fire2pressed)
    {
        if (answerX == 1)
        {
            retryScenario = true;
        }
        else
        {
            retryScenario = false;
        }
        scrTransition(-1, 30, 0, -10, false);
        substate++;
        scrSfx(soundStageSelect, 55);
    }
}
if (substate == 5)
{
    if (scrTransitionDone())
    {
        scr36_ChangeState(STATE_SCENARIO_SELECT);
    }
}
