function scr36_SetupScenarios()
{
    for (var i = 0; i < 6; i++)
    {
        ds_list_clear(scenario[i]);
    }
    scenarioName[0] = "HUMAN INVITATION";
    ds_list_add(scenario[0], scr36_CreateCard(CHAR_ALIEN), scr36_CreateCard(CHAR_MONKEY), scr36_CreateCard(CHAR_SECURITY), scr36_CreateCard(CHAR_DRIVER), scr36_CreateCard(CHAR_CUTE_DOG), scr36_CreateCard(CHAR_DANCER), scr36_CreateCard(CHAR_MAGICIAN), scr36_CreateCard(CHAR_MASCOT), scr36_CreateCard(CHAR_TICKET_TAKER), scr36_CreateCard(CHAR_MR_POPULAR), scr36_CreateCard(CHAR_DOG), scr36_CreateCard(CHAR_CATERER), scr36_CreateCard(CHAR_WEREWOLF));
    scr36_SortCharacters(scenario[0]);
    scenarioName[1] = "CAMPAIGN FINANCE";
    ds_list_add(scenario[1], scr36_CreateCard(CHAR_WRESTLER), scr36_CreateCard(CHAR_GRILLMASTER), scr36_CreateCard(CHAR_GANGSTER), scr36_CreateCard(CHAR_SPY), scr36_CreateCard(CHAR_HIPPY), scr36_CreateCard(CHAR_PRIVATE_I), scr36_CreateCard(CHAR_MONKEY), scr36_CreateCard(CHAR_WRITER), scr36_CreateCard(CHAR_CLIMBER), scr36_CreateCard(CHAR_INTROVERT), scr36_CreateCard(CHAR_COMEDIAN), scr36_CreateCard(CHAR_SUPERHERO), scr36_CreateCard(CHAR_MERMAID));
    scr36_SortCharacters(scenario[1]);
    scenarioName[2] = "UNHOLY NIGHT";
    ds_list_add(scenario[2], scr36_CreateCard(CHAR_MAGICIAN_V), scr36_CreateCard(CHAR_STYLIST), scr36_CreateCard(CHAR_HIPPY), scr36_CreateCard(CHAR_MR_POPULAR), scr36_CreateCard(CHAR_COUNSELOR), scr36_CreateCard(CHAR_PHOTOGRAPHER), scr36_CreateCard(CHAR_ATHLETE), scr36_CreateCard(CHAR_CHEERLEADER), scr36_CreateCard(CHAR_WRESTLER), scr36_CreateCard(CHAR_GAMBLER), scr36_CreateCard(CHAR_ROCK_STAR), scr36_CreateCard(CHAR_DINOSAUR), scr36_CreateCard(CHAR_GENIE));
    scr36_SortCharacters(scenario[2]);
    scenarioName[3] = "PEST CONTROL";
    ds_list_add(scenario[3], scr36_CreateCard(CHAR_GANGSTER_W), scr36_CreateCard(CHAR_DOG_W), scr36_CreateCard(CHAR_AUCTIONEER), scr36_CreateCard(CHAR_CELEBRITY), scr36_CreateCard(CHAR_BARTENDER), scr36_CreateCard(CHAR_CATERER), scr36_CreateCard(CHAR_DRIVER_P), scr36_CreateCard(CHAR_WEREWOLF_R), scr36_CreateCard(CHAR_DANCER), scr36_CreateCard(CHAR_HOST), scr36_CreateCard(CHAR_COUNSELOR), scr36_CreateCard(CHAR_GHOST), scr36_CreateCard(CHAR_LEPRECHAUN));
    scr36_SortCharacters(scenario[3]);
    scenarioName[4] = "A LITTLE TROUBLE";
    ds_list_add(scenario[4], scr36_CreateCard(CHAR_CHEERLEADER), scr36_CreateCard(CHAR_SECURITY_R), scr36_CreateCard(CHAR_MASCOT), scr36_CreateCard(CHAR_CUPID), scr36_CreateCard(CHAR_GRILLMASTER), scr36_CreateCard(CHAR_SPY), scr36_CreateCard(CHAR_CLIMBER_T), scr36_CreateCard(CHAR_WRITER), scr36_CreateCard(CHAR_PRIVATE_I_P), scr36_CreateCard(CHAR_CUTE_DOG), scr36_CreateCard(CHAR_ROCK_STAR_K), scr36_CreateCard(CHAR_UNICORN), scr36_CreateCard(CHAR_DRAGON));
    scr36_SortCharacters(scenario[4]);
    ds_list_clear(echolist);
    ds_list_add(echolist, scr36_CreateCard(CHAR_MAGICIAN), scr36_CreateCard(CHAR_MAGICIAN_V), scr36_CreateCard(CHAR_DOG), scr36_CreateCard(CHAR_DOG_W), scr36_CreateCard(CHAR_SECURITY), scr36_CreateCard(CHAR_SECURITY_R), scr36_CreateCard(CHAR_ROCK_STAR), scr36_CreateCard(CHAR_ROCK_STAR_K), scr36_CreateCard(CHAR_DRIVER), scr36_CreateCard(CHAR_DRIVER_P));
}
