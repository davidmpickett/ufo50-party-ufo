if (substate == 0)
{
    substate = 1;
    if (prevState == STATE_ROLODEX)
    {
        selectorX = 0;
        selectorY = 0;
    }
    else if (prevState == STATE_START_PARTY)
    {
        selectorX = 1;
        selectorY = 0;
    }
    else if (prevState == STATE_BUSTED)
    {
        selectorX = 2;
        selectorY = 0;
        substate = 4;
    }
    bringCounter = 0;
    currPrestige = scr36_GetPrestige();
}
if (substate == 1 || substate == 4 || substate == 6 || substate == 7 || substate == 8 || substate == 10 || substate == 11 || substate == 12 || substate == 13 || substate == 14 || substate == 15)
{
    selOn = true;
    var moved;
    if (substate == 1)
    {
        moved = scr36_HandleMovement(0, capacity[cp] + 2);
    }
    else
    {
        moved = scr36_HandleMovement(2, ds_list_size(party) + 2);
    }
    if (moved)
    {
        if (substate == 1)
        {
            scrSfx(soundNaviA, 10);
        }
        else
        {
            scrSfx(soundNaviD, 10);
        }
    }
    selIndex = scr36_GetIndex(selectorX, selectorY, 2);
    if (selIndex >= 0 && selIndex < ds_list_size(party))
    {
        selCard = ds_list_find_value(party, selIndex);
    }
    else
    {
        selCard = -4;
    }
    if (moved && nextCard != -4)
    {
        if (selIndex == -1)
        {
            messageColor = 16777215;
            scr36_MessageSet(scrStringVal("let_in", string(nextCard.name)));
        }
        else
        {
            scr36_MessageSet("");
        }
    }
}
if (doorSoundBuffered)
{
    scrSfx(soundDoorOpen, 40);
    doorSoundBuffered = false;
}
if (substate == 1)
{
    if (debug)
    {
        debug = false;
        selIndex = -1;
        scr36_LuckPushingAI();
    }
    if (fire2pressed && selIndex == -1)
    {
        if (!bgmTrig)
        {
            if (capacity[cp] < 8)
            {
                scrBGM(bgmParty[0]);
            }
            else if (capacity[cp] < 17)
            {
                scrBGM(bgmParty[1]);
            }
            else if (capacity[cp] < 26)
            {
                scrBGM(bgmParty[2]);
            }
            else
            {
                scrBGM(bgmParty[3]);
            }
            bgmTrig = true;
        }
        if (ds_list_size(party) < capacity[cp])
        {
            if (nextNextCard != -4)
            {
                nextCard = nextNextCard;
                nextNextCard = -4;
            }
            else
            {
                nextCard = -4;
            }
            with (o36_Door)
            {
                image_speed = 0.2;
            }
            substate = 2;
            with (o36_Card)
            {
                flickerActionTimer = 0;
            }
        }
        else
        {
            scrSfx(soundText, 15);
            messageColor = 16777215;
            scr36_MessageSet(scrString("no_room"));
        }
    }
    else if (fire1pressed && selIndex == -1)
    {
        if (nextCard != -4 && nextNextCard != -4)
        {
            scrSfx(soundBootOut, 50);
            messageColor = global.palette[13];
            scr36_MessageSet(nextCard.name + " & " + nextNextCard.name + " WERE SENT AWAY.");
            ds_list_delete(draw_pile, 1);
            ds_list_delete(draw_pile, 0);
            ds_list_add(booted, nextCard);
            ds_list_add(booted, nextNextCard);
            nextCard = -4;
            nextNextCard = -4;
        }
        else if (nextCard != -4)
        {
            scrSfx(soundBootOut, 50);
            messageColor = global.palette[13];
            scr36_MessageSet(nextCard.name + " WAS SENT AWAY.");
            ds_list_delete(draw_pile, 0);
            ds_list_add(booted, nextCard);
            nextCard = -4;
        }
        else if (ds_list_size(party) < 1)
        {
            scrSfx(soundText, 15);
            messageColor = global.palette[0];
            scr36_MessageSet(scrString("dont_end"));
        }
        else
        {
            scrBGM(bgm36_stingPartyEndA, false);
            bgmTrig = false;
            with (o36_Card)
            {
                flickerActionTimer = 0;
            }
            nextCard = -4;
            nextNextCard = -4;
            messageColor = global.palette[0];
            scr36_MessageSet(scrString("ended_party"));
            scr36_ChangeState(STATE_SCORE);
            phase = PHASE_SCORING;
            exit;
        }
    }
    else if (fire2pressed && selIndex == -2)
    {
        scrSfx(soundTransitionA, 60);
        selOn = false;
        messageColor = global.palette[0];
        scr36_MessageSet("OPENING HOLODEX...");
        scr36_ChangeState(STATE_ROLODEX);
        exit;
    }
    else if (fire2pressed && selCard != -4)
    {
        if (selCard.bounce)
        {
            mute(soundCancel);
            scrSfx(soundSelectSpecial, 20);
            tSelector = 3;
            actionIndex = selIndex;
            with (o36_Card)
            {
                flickerActionTimer = 0;
            }
            messageColor = global.palette[10];
            scr36_MessageSet("WHO DO YOU WANT TO PUSH OUT?");
            substate = 4;
            actionCard = selCard;
        }
        else if (selCard.photo)
        {
            if (ds_list_size(party) < capacity[cp])
            {
                mute(soundCancel);
                scrSfx(soundSelectSpecial, 20);
                with (o36_Card)
                {
                    flickerActionTimer = 0;
                }
                messageColor = global.palette[4];
                scr36_MessageSet(scrString("photograph"));
                substate = 6;
                actionCard = selCard;
            }
            else
            {
                messageColor = global.palette[4];
                scr36_MessageSet("NOT ENOUGH ROOM FOR A PHOTOSHOOT.");
            }
        }
        else if (selCard.matchmaker)
        {
            mute(soundCancel);
            scrSfx(soundSelectSpecial, 20);
            with (o36_Card)
            {
                flickerActionTimer = 0;
            }
            messageColor = global.palette[7];
            scr36_MessageSet("WHO WILL SHRINK TOGETHER?");
            substate = 7;
            actionCard = selCard;
        }
        else if (selCard.upgrade)
        {
            if (selCard.popularity < 9)
            {
                if (!selCard.flipped && (selCard.popularity + selCard.drained) >= 9)
                {
                    scrSfx(soundText, 15);
                    messageColor = global.palette[0];
                    scr36_MessageSet("NICE TRY, MICHAEL!");
                }
                else if (selCard.flipped && (selCard.popularity + selCard.flipdrain) >= 9)
                {
                    scrSfx(soundText, 15);
                    messageColor = global.palette[0];
                    scr36_MessageSet("NICE TRY, MICHAEL!");
                }
                else
                {
                    mute(soundCancel);
                    scrSfx(soundSelectSpecial, 20);
                    with (o36_Card)
                    {
                        flickerActionTimer = 0;
                    }
                    messageColor = global.palette[9];
                    scr36_MessageSet("WHO LOOKS TASTY?");
                    substate = 10;
                    actionCard = selCard;
                }
            }
            else if (selCard.popularity >= 9)
            {
                scrSfx(soundText, 15);
                messageColor = global.palette[0];
                scr36_MessageSet(selCard.name + " HAS DRANK THEIR FILL OF POP");
            }
        }
        else if (selCard.magicSwap)
        {
            mute(soundCancel);
            scrSfx(soundSelectSpecial, 20);
            with (o36_Card)
            {
                flickerActionTimer = 0;
            }
            messageColor = global.palette[7];
            scr36_MessageSet("WHO WILL BE FLIPPED?");
            substate = 11;
            actionCard = selCard;
        }
        else if (selCard.reshuffle)
        {
            mute(soundCancel);
            scrSfx(soundSelectSpecial, 20);
            with (o36_Card)
            {
                flickerActionTimer = 0;
            }
            messageColor = global.palette[19];
            scr36_MessageSet("WHICH SIDE OF THE PARTY WILL GO OUTSIDE?");
            substate = 12;
            actionIndex = selIndex;
            actionCard = selCard;
        }
        else if (selCard.bless)
        {
            var actionsToBless = false;
            for (var i = 0; i < ds_list_size(party); i++)
            {
                if ((ds_list_find_value(party, i).bouncemax > 0 && ds_list_find_value(party, i).bounce < 4) || (ds_list_find_value(party, i).peekmax > 0 && ds_list_find_value(party, i).peek < 4) || (ds_list_find_value(party, i).phonemax > 0 && ds_list_find_value(party, i).phone < 4) || (ds_list_find_value(party, i).reshufflemax > 0 && ds_list_find_value(party, i).reshuffle < 4) || (ds_list_find_value(party, i).photomax > 0 && ds_list_find_value(party, i).photo < 4) || (ds_list_find_value(party, i).matchmakermax > 0 && ds_list_find_value(party, i).matchmaker < 4) || (ds_list_find_value(party, i).introvertmax > 0 && ds_list_find_value(party, i).introvert < 7) || (ds_list_find_value(party, i).reformmax > 0 && ds_list_find_value(party, i).reform < 4) || (ds_list_find_value(party, i).upgrademax > 0 && ds_list_find_value(party, i).upgrade < 4) || (ds_list_find_value(party, i).magicSwapmax > 0 && ds_list_find_value(party, i).magicSwap < 4) || (ds_list_find_value(party, i).greetmax > 0 && ds_list_find_value(party, i).greet < 4) || (ds_list_find_value(party, i).banishmax > 0 && ds_list_find_value(party, i).banish < 4))
                {
                    ds_list_find_value(party, i).flickerTimer = 128;
                    actionsToBless = true;
                }
            }
            if (actionsToBless)
            {
                mute(soundCancel);
                scrSfx(soundSelectSpecial, 20);
                messageColor = global.palette[14];
                scr36_MessageSet("WHICH SOUL SHALL YOU BLESS WITH BRONTOR'S GRACE?");
                substate = 14;
                actionCard = selCard;
            }
            else
            {
                scrSfx(soundText, 15);
                messageColor = global.palette[0];
                scr36_MessageSet("NO ACTIONS TO BLESS");
            }
        }
        else if (selCard.copyfrog)
        {
            mute(soundCancel);
            scrSfx(soundSelectSpecial, 20);
            messageColor = global.palette[2];
            scr36_MessageSet("WHICH GUEST WILL YOU COPY?");
            substate = 15;
            actionCard = selCard;
        }
        else if (selCard.introvert)
        {
            if (ds_list_size(party) < capacity[cp])
            {
                scrSfx(soundDoorOpen, 40);
                with (o36_Card)
                {
                    flickerActionTimer = 0;
                }
                selCard.introvert--;
                nonCard = scr36_CreateCard(CHAR_RITUALIST);
                ds_list_insert(party, selIndex + 1, nonCard);
            }
            else if (ds_list_size(party) >= capacity[cp])
            {
                scrSfx(soundText, 15);
                messageColor = 16777215;
                scr36_MessageSet(scrString("no_room"));
            }
        }
        else if (selCard.phone)
        {
            if (ds_list_size(party) < capacity[cp] && !ds_list_empty(draw_pile))
            {
                mute(soundCancel);
                scrSfx(soundOpenFetch, 20);
                messageColor = global.palette[7];
                scr36_MessageSet(scrString("fetch_anyone"));
                scr36_ChangeState(STATE_FETCH);
                actionCard = selCard;
                exit;
            }
            else
            {
                scrSfx(soundText, 15);
                messageColor = 16777215;
                if (ds_list_size(party) >= capacity[cp])
                {
                    scr36_MessageSet(scrString("no_room"));
                }
                else
                {
                    scr36_MessageSet("NO ONE LEFT IN HOLODEX!");
                }
            }
        }
        else if (selCard.peek)
        {
            if (nextCard != -4)
            {
                scrSfx(soundText, 15);
                messageColor = global.palette[0];
                scr36_MessageSet("YOU ALREADY KNOW WHO'S AT THE AIRLOCK!");
            }
            else if (ds_list_empty(draw_pile))
            {
                scrSfx(soundText, 15);
                messageColor = global.palette[0];
                scr36_MessageSet("NO ONE LEFT IN HOLODEX!");
            }
            else if (ds_list_size(draw_pile) >= 2)
            {
                scrSfx(soundPeek, 50);
                selCard.peek--;
                nextCard = ds_list_find_value(draw_pile, 0);
                nextNextCard = ds_list_find_value(draw_pile, 1);
                messageColor = global.palette[13];
                scr36_MessageSet(nextCard.name + " & " + nextNextCard.name + " ARE HERE");
                actionCard = selCard;
            }
            else
            {
                scrSfx(soundPeek, 50);
                selCard.peek--;
                nextCard = ds_list_find_value(draw_pile, 0);
                messageColor = global.palette[13];
                scr36_MessageSet(nextCard.name + "IS AT THE AIRLOCK.");
                actionCard = selCard;
            }
        }
        else if (selCard.banish)
        {
            mute(soundCancel);
            scrSfx(soundSelectSpecial, 20);
            tSelector = 3;
            with (o36_Card)
            {
                flickerActionTimer = 0;
            }
            messageColor = global.palette[9];
            scr36_MessageSet("WHO WILL YOU BANISH TO THE NIGHT MANOR?");
            substate = 13;
            actionCard = selCard;
        }
        else
        {
            scrSfx(soundText, 15);
            messageColor = global.palette[0];
            scr36_MessageSet(scrString("this_person_no_action"), true);
        }
    }
    else if (fire2pressed)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        if (selectorX == 6 && selectorY == 2)
        {
            scr36_MessageSet("EGGPLANT IS A GREAT PODCAST.");
        }
        else
        {
            scr36_MessageSet(scrString("nothing_here"));
        }
    }
    else if (fire1pressed)
    {
        scrSfx(soundNaviA, 10);
        selectorX = 1;
        selectorY = 0;
        selIndex = scr36_GetIndex(selectorX, selectorY, 2);
    }
}
else if (substate == 4)
{
    if (phase == PHASE_BUSTED && (stateTimer++ < 60 || textMessagePos < textMessageLength))
    {
        selOn = false;
        nextCard = -4;
        nextNextCard = -4;
        exit;
    }
    selOn = true;
    if (fire1pressed && phase != PHASE_BUSTED)
    {
        mute(soundSelectSpecial);
        scrSfx(soundCancel, 5);
        scr36_MessageSet("");
        substate = 1;
    }
    else if (fire2pressed && selCard != -4)
    {
        if (phase == PHASE_PARTY)
        {
            if (selCard != actionCard)
            {
                scrSfx(soundBootOut, 50);
                bounceTop = scr36_CreateCard(CHAR_BOUNCE_TOP);
                if (actionIndex > selIndex)
                {
                    ds_list_insert(party, actionIndex, bounceTop);
                    ds_list_delete(party, selIndex);
                    actionCard.flopped = false;
                    bounceTop.flopped = false;
                }
                else if (actionIndex < selIndex)
                {
                    ds_list_delete(party, selIndex);
                    ds_list_insert(party, actionIndex + 1, bounceTop);
                    actionCard.flopped = true;
                    bounceTop.flopped = true;
                }
                if (actionCard.type == CHAR_WRESTLER)
                {
                    actionCard.sprite_index = s36_ClownBottom;
                    actionCard.name = "BOX";
                }
                else if (actionCard.type == CHAR_SECURITY)
                {
                    actionCard.sprite_index = s36_SpearBottom;
                    actionCard.name = "DUDE";
                    bounceTop.name = "SPEAR";
                    bounceTop.sprite_index = s36_SpearTop;
                }
                else if (actionCard.type == CHAR_GHOST)
                {
                    bounceTop.name = "RED DRONE";
                    bounceTop.sprite_index = s36_Drone;
                    actionCard.flopped = 0;
                    bounceTop.flopped = 0;
                }
                else if (actionCard.type == CHAR_HOST)
                {
                    bounceTop.name = "FROG COPY";
                    bounceTop.sprite_index = s36_CopyCopy;
                }
                actionCard.bounce--;
                ds_list_add(booted, selCard);
                messageColor = global.palette[10];
                scr36_MessageSet(selCard.name + " WAS PUSHED OUT OF THE PARTY.");
                totalTrouble = scr36_GetTrouble();
                currPrestige = scr36_GetPrestige();
                if (totalTrouble >= TROUBLE_THRESHOLD)
                {
                    mute(global.SFX);
                    scrBGM(bgm36_stingPartyEndB, false);
                    bgmTrig = false;
                    messageColor = global.palette[9];
                    scr36_MessageSet("OH NO! YOU CRASHED YOUR SHIP!");
                    scr36_ChangeState(STATE_BUSTED);
                    exit;
                }
                substate = 1;
            }
            else
            {
                messageColor = global.palette[0];
                scr36_MessageSet(actionCard.name + " CAN'T PUSH THEMSELVES OUT.");
            }
        }
        else if (phase == PHASE_BUSTED)
        {
            if (selCard.type != CHAR_BOUNCE_TOP && selCard.type != CHAR_PHOTO && selCard.type != CHAR_RITUALIST && selCard.type != CHAR_LIL_GUESTS)
            {
                scrSfx(soundBootOut, 50);
                ds_list_delete(party, selIndex);
                totalTrouble = scr36_GetTrouble();
                currPrestige = scr36_GetPrestige();
                selCard.probation = PROBATION_TIME;
                messageColor = global.palette[0];
                scr36_MessageSet(scrStringVal("banned", selCard.name, PROBATION_TIME));
                substate = 5;
                stateTimer = 0;
            }
            else
            {
                scrSfx(soundText, 15);
                totalTrouble = scr36_GetTrouble();
                currPrestige = scr36_GetPrestige();
                messageColor = global.palette[0];
                scr36_MessageSet("YOU BLAMED " + selCard.name + " BUT THEY RESISTED THE BAN.");
                substate = 5;
                stateTimer = 0;
            }
        }
    }
    else if (fire2pressed && selCard == -4)
    {
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("nobody_here"));
    }
    else if (phase != PHASE_BUSTED)
    {
        if (actionIndex > selIndex)
        {
            actionCard.flopped = false;
        }
        else if (actionIndex < selIndex)
        {
            actionCard.flopped = true;
        }
    }
}
else if (substate == 7)
{
    if (fire1pressed)
    {
        mute(soundSelectSpecial);
        scrSfx(soundCancel, 5);
        scr36_MessageSet("");
        substate = 1;
    }
    else if (fire2pressed && selCard != -4 && !selCard.tiny)
    {
        mute(soundCancel);
        scrSfx(soundMatchA, 20);
        draw_set_color(global.palette[7]);
        scr36_MessageSet("WHO WILL SHRINK WITH THEM?");
        matchCard = selCard;
        matchIndex = selIndex;
        matchX = selectorX;
        matchY = selectorY;
        substate = 8;
    }
    else if (fire2pressed && selCard == -4)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("nobody_here"));
    }
    else if (fire2pressed && selCard.tiny)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet("THEY ARE ALREADY TINY.");
    }
}
else if (substate == 8)
{
    if (fire1pressed)
    {
        mute(soundMatchA);
        scrSfx(soundCancel, 5);
        scr36_MessageSet("");
        substate = 1;
    }
    else if (fire2pressed && selCard != -4 && abs(selIndex - matchIndex) == 1 && !selCard.tiny)
    {
        scrSfx(soundMatchB, 51);
        ds_list_delete(party, max(selIndex, matchIndex));
        ds_list_delete(party, min(selIndex, matchIndex));
        newCard = scr36_CreateCard(CHAR_LIL_GUESTS);
        newCard.money = selCard.money + matchCard.money;
        newCard.popularity = selCard.popularity + matchCard.popularity;
        newCard.prestige = selCard.prestige + matchCard.prestige;
        newCard.sprite_index = 0;
        newCard.tinySprite1 = selCard.sprite_index;
        newCard.tinySprite2 = matchCard.sprite_index;
        newCard.tinyFlipped1 = selCard.flipped;
        newCard.tinyFlipped2 = matchCard.flipped;
        newCard.troublemaker = selCard.troublemaker + matchCard.troublemaker;
        newCard.peacekeeper = selCard.peacekeeper + matchCard.peacekeeper;
        newCard.oldfriend = selCard.oldfriend + matchCard.oldfriend;
        newCard.bring = selCard.bring + matchCard.bring;
        newCard.full = selCard.full + matchCard.full;
        newCard.schoolpride = selCard.schoolpride + matchCard.schoolpride;
        newCard.dancer = selCard.dancer + matchCard.dancer;
        newCard.troublePopBonus = selCard.troublePopBonus + matchCard.troublePopBonus;
        newCard.troubleMoneyBonus = selCard.troubleMoneyBonus + matchCard.troubleMoneyBonus;
        newCard.tiny = 1;
        ds_list_insert(party, min(selIndex, matchIndex), newCard);
        actionCard.matchmaker--;
        ds_list_add(booted, selCard);
        ds_list_add(booted, matchCard);
        messageColor = global.palette[7];
        scr36_MessageSet(matchCard.name + " & " + selCard.name + " ARE REALLY SMALL NOW.");
        substate = 1;
    }
    else if (fire2pressed && selCard == -4)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("nobody_here"));
    }
    else if (fire2pressed && abs(matchIndex - selIndex) > 1)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("must_be_adjacent"));
    }
    else if (fire2pressed && selCard == matchCard)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("same_person_warning"));
    }
    else if (fire2pressed && selCard.tiny)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet("THEY ARE ALREADY TINY.");
    }
}
else if (substate == 6)
{
    if (fire1pressed)
    {
        mute(soundSelectSpecial);
        scrSfx(soundCancel, 5);
        scr36_MessageSet("");
        substate = 1;
    }
    else if (fire2pressed && selCard != -4)
    {
        scrSfx(soundPhoto, 50);
        selCard.flickerTimer = 32;
        actionCard.photo--;
        newCard = scr36_CreateCard(CHAR_PHOTO);
        newCard.money = selCard.money;
        newCard.popularity = selCard.popularity;
        newCard.tiny = selCard.tiny;
        newCard.tinySprite1 = selCard.tinySprite1;
        newCard.tinySprite2 = selCard.tinySprite2;
        newCard.tinyFlipped1 = selCard.tinyFlipped1;
        newCard.tinyFlipped2 = selCard.tinyFlipped2;
        newCard.sprite_index = selCard.sprite_index;
        newCard.troublemaker = selCard.troublemaker;
        newCard.peacekeeper = selCard.peacekeeper;
        newCard.flipped = selCard.flipped;
        newCard.flopped = selCard.flopped;
        newCard.image_speed = 0;
        newCard.polaroid = 1;
        ds_list_insert(party, 0, newCard);
        substate = 9;
        exit;
    }
    else if (fire2pressed && selCard == -4)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("nobody_here"));
    }
}
else if (substate == 10)
{
    if (fire1pressed)
    {
        mute(soundSelectSpecial);
        scrSfx(soundCancel, 5);
        scr36_MessageSet("");
        substate = 1;
    }
    else if (fire2pressed && selCard != -4 && selCard != actionCard)
    {
        scrSfx(soundPopular, 50);
        messageColor = global.palette[9];
        scr36_MessageSet(actionCard.name + " DRAINED 1 POP FROM " + selCard.name);
        actionCard.upgrade--;
        selCard.flickerTimer = 32;
        if (selCard.flipped)
        {
            selCard.flipdrain++;
        }
        else
        {
            selCard.drained++;
        }
        selCard.popularity--;
        actionCard.popularity++;
        if (actionCard.flipped)
        {
            actionCard.currMon++;
        }
        substate = 1;
        exit;
    }
    else if (fire2pressed && selCard == actionCard)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(actionCard.name + " CAN'T DRAIN THEMSELVES.");
    }
    else if (fire2pressed && selCard == -4)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("nobody_here"));
    }
}
else if (substate == 11)
{
    if (fire1pressed)
    {
        mute(soundSelectSpecial);
        scrSfx(soundCancel, 5);
        scr36_MessageSet("");
        substate = 1;
    }
    else if (fire2pressed && selCard != -4)
    {
        selCard.currPop = selCard.popularity;
        selCard.currMon = selCard.money;
        scrSfx(soundMagicSwap, 50);
        messageColor = global.palette[7];
        scr36_MessageSet(selCard.name + " WAS FLIPPED");
        selCard.popularity = selCard.currMon;
        selCard.money = selCard.currPop;
        if (selCard.flipped == 0)
        {
            selCard.flipped = 1;
        }
        else
        {
            selCard.flipped = 0;
        }
        actionCard.magicSwap--;
        substate = 1;
    }
    else if (fire2pressed && selCard == -4)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("nobody_here"));
    }
}
else if (substate == 12)
{
    if (fire1pressed)
    {
        mute(soundSelectSpecial);
        scrSfx(soundCancel, 5);
        scr36_MessageSet("");
        substate = 1;
    }
    else if (fire2pressed && selIndex < actionIndex)
    {
        scrSfx(soundGoOutside, 50);
        with (o36_Card)
        {
            flickerActionTimer = 0;
        }
        actionCard.reshuffle--;
        for (i = 0; i < actionIndex; i++)
        {
            ds_list_add(draw_pile, ds_list_find_value(party, i));
        }
        var i = actionIndex - 1;
        while (i >= 0)
        {
            ds_list_delete(party, i);
            i--;
        }
        scrShuffle(draw_pile);
        nextCard = -4;
        nextNextCard = -4;
        messageColor = global.palette[19];
        scr36_MessageSet("EVERYONE TO THE LEFT WENT OUTSIDE");
        totalTrouble = scr36_GetTrouble();
        currPrestige = scr36_GetPrestige();
        if (totalTrouble >= TROUBLE_THRESHOLD)
        {
            mute(global.SFX);
            scrBGM(bgm36_stingPartyEndB, false);
            bgmTrig = false;
            messageColor = global.palette[9];
            scr36_MessageSet("OH NO! YOU CRASHED YOUR SHIP!");
            scr36_ChangeState(STATE_BUSTED);
            exit;
        }
        substate = 1;
    }
    else if (fire2pressed && selIndex > actionIndex)
    {
        scrSfx(soundGoOutside, 50);
        with (o36_Card)
        {
            flickerActionTimer = 0;
        }
        actionCard.reshuffle--;
        var i = actionIndex + 1;
        while (i < ds_list_size(party))
        {
            ds_list_add(draw_pile, ds_list_find_value(party, i));
            i++;
        }
        i = ds_list_size(party);
        while (i > actionIndex)
        {
            ds_list_delete(party, i);
            i--;
        }
        scrShuffle(draw_pile);
        nextCard = -4;
        nextNextCard = -4;
        messageColor = global.palette[19];
        scr36_MessageSet("EVERYONE TO THE RIGHT WENT OUTSIDE");
        totalTrouble = scr36_GetTrouble();
        currPrestige = scr36_GetPrestige();
        if (totalTrouble >= TROUBLE_THRESHOLD)
        {
            mute(global.SFX);
            scrBGM(bgm36_stingPartyEndB, false);
            bgmTrig = false;
            messageColor = global.palette[9];
            scr36_MessageSet("OH NO! YOU CRASHED YOUR SHIP!");
            scr36_ChangeState(STATE_BUSTED);
            exit;
        }
        substate = 1;
    }
    else if (fire2pressed && selIndex == actionIndex)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet("CHOOSE A SIDE");
    }
}
else if (substate == 13)
{
    if (fire1pressed)
    {
        mute(soundSelectSpecial);
        scrSfx(soundCancel, 5);
        scr36_MessageSet("");
        substate = 1;
    }
    else if (fire2pressed && selCard != -4 && selCard.type != CHAR_LIL_GUESTS && selCard.type != CHAR_BOUNCE_TOP && selCard.type != CHAR_PHOTO && selCard.type != CHAR_RITUALIST)
    {
        scrSfx(soundBootOut, 50);
        actionCard.banish--;
        selCard.probation = 1;
        ds_list_add(booted, selCard);
        ds_list_delete(party, selIndex);
        messageColor = global.palette[0];
        scr36_MessageSet(selCard.name + " WAS BANNED FOR 1 PARTY.");
        totalTrouble = scr36_GetTrouble();
        currPrestige = scr36_GetPrestige();
        if (totalTrouble >= TROUBLE_THRESHOLD)
        {
            mute(global.SFX);
            scrBGM(bgm36_stingPartyEndB, false);
            bgmTrig = false;
            messageColor = global.palette[9];
            scr36_MessageSet("OH NO! YOU CRASHED YOUR SHIP!");
            scr36_ChangeState(STATE_BUSTED);
            exit;
        }
        substate = 1;
    }
    else if (fire2pressed && selCard == -4)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("nobody_here"));
    }
    else if (fire2pressed && (selCard.type == CHAR_LIL_GUESTS || selCard.type == CHAR_BOUNCE_TOP || selCard.type == CHAR_PHOTO || selCard.type == CHAR_RITUALIST))
    {
        scrSfx(soundText, 15);
        actionCard.banish--;
        ds_list_add(booted, selCard);
        ds_list_delete(party, selIndex);
        messageColor = global.palette[0];
        scr36_MessageSet("YOU BOOTED " + selCard.name + " BUT THEY RESISTED THE BAN.");
        totalTrouble = scr36_GetTrouble();
        currPrestige = scr36_GetPrestige();
        if (totalTrouble >= TROUBLE_THRESHOLD)
        {
            mute(global.SFX);
            scrBGM(bgm36_stingPartyEndB, false);
            bgmTrig = false;
            messageColor = global.palette[9];
            scr36_MessageSet("OH NO! YOU CRASHED YOUR SHIP!");
            scr36_ChangeState(STATE_BUSTED);
            exit;
        }
        substate = 1;
    }
}
else if (substate == 14)
{
    if (fire1pressed)
    {
        mute(soundSelectSpecial);
        scrSfx(soundCancel, 5);
        scr36_MessageSet("");
        substate = 1;
    }
    else if (fire2pressed && selCard != -4 && selCard.type != CHAR_CHEERLEADER)
    {
        if (selCard.bouncemax > 0 && selCard.bounce < 4)
        {
            selCard.bounce++;
            scrSfx(soundRefresh, 50);
            actionCard.bless--;
            messageColor = global.palette[14];
            scr36_MessageSet(selCard.name + " WAS BLESSED");
            substate = 1;
        }
        else if (selCard.peekmax > 0 && selCard.peek < 4)
        {
            selCard.peek++;
            scrSfx(soundRefresh, 50);
            actionCard.bless--;
            messageColor = global.palette[14];
            scr36_MessageSet(selCard.name + " WAS BLESSED");
            substate = 1;
        }
        else if (selCard.phonemax > 0 && selCard.phone < 4)
        {
            selCard.phone++;
            scrSfx(soundRefresh, 50);
            actionCard.bless--;
            messageColor = global.palette[14];
            scr36_MessageSet(selCard.name + " WAS BLESSED");
            substate = 1;
        }
        else if (selCard.reshufflemax > 0 && selCard.reshuffle < 4)
        {
            selCard.reshuffle++;
            scrSfx(soundRefresh, 50);
            actionCard.bless--;
            messageColor = global.palette[14];
            scr36_MessageSet(selCard.name + " WAS BLESSED");
            substate = 1;
        }
        else if (selCard.photomax > 0 && selCard.photo < 4)
        {
            selCard.photo++;
            scrSfx(soundRefresh, 50);
            actionCard.bless--;
            messageColor = global.palette[14];
            scr36_MessageSet(selCard.name + " WAS BLESSED");
            substate = 1;
        }
        else if (selCard.matchmakermax > 0 && selCard.matchmaker < 4)
        {
            selCard.matchmaker++;
            scrSfx(soundRefresh, 50);
            actionCard.bless--;
            messageColor = global.palette[14];
            scr36_MessageSet(selCard.name + " WAS BLESSED");
            substate = 1;
        }
        else if (selCard.introvertmax > 0 && selCard.introvert < 7)
        {
            selCard.introvert += 3;
            scrSfx(soundRefresh, 50);
            actionCard.bless--;
            messageColor = global.palette[14];
            scr36_MessageSet(selCard.name + " WAS BLESSED");
            substate = 1;
        }
        else if (selCard.reformmax > 0 && selCard.reform < 4)
        {
            selCard.reform++;
            scrSfx(soundRefresh, 50);
            actionCard.bless--;
            messageColor = global.palette[14];
            scr36_MessageSet(selCard.name + " WAS BLESSED");
            substate = 1;
        }
        else if (selCard.upgrademax > 0 && selCard.upgrade < 4)
        {
            selCard.upgrade++;
            scrSfx(soundRefresh, 50);
            actionCard.bless--;
            messageColor = global.palette[14];
            scr36_MessageSet(selCard.name + " WAS BLESSED");
            substate = 1;
        }
        else if (selCard.magicSwapmax > 0 && selCard.magicSwap < 4)
        {
            selCard.magicSwap++;
            scrSfx(soundRefresh, 50);
            actionCard.bless--;
            messageColor = global.palette[14];
            scr36_MessageSet(selCard.name + " WAS BLESSED");
            substate = 1;
        }
        else if (selCard.greetmax > 0 && selCard.greet < 4)
        {
            selCard.greet++;
            scrSfx(soundRefresh, 50);
            actionCard.bless--;
            messageColor = global.palette[14];
            scr36_MessageSet(selCard.name + " WAS BLESSED");
            substate = 1;
        }
        else if (selCard.banishmax > 0 && selCard.banish < 4)
        {
            selCard.banish++;
            scrSfx(soundRefresh, 50);
            actionCard.bless--;
            messageColor = global.palette[14];
            scr36_MessageSet(selCard.name + " WAS BLESSED");
            substate = 1;
        }
        else if (selCard.bounce == 4 || selCard.peek == 4 || selCard.phone == 4 || selCard.reshuffle == 4 || selCard.photo == 4 || selCard.matchmaker == 4 || selCard.introvert >= 7 || selCard.reform == 4 || selCard.upgrade == 4 || selCard.magicSwap == 4 || selCard.greet == 4 || selCard.banish == 4)
        {
            messageColor = global.palette[0];
            scr36_MessageSet(selCard.name + " IS FULLY BLESSED");
        }
        else
        {
            messageColor = global.palette[0];
            scr36_MessageSet(selCard.name + " HAS NO ACTIONS TO BLESS");
        }
    }
    else if (fire2pressed && selCard == -4)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("nobody_here"));
    }
    else if (fire2pressed && selCard.type == CHAR_CHEERLEADER)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet("SORRY. NO BLESSING FOR MORE BLESSES.");
    }
}
else if (substate == 15)
{
    if (fire1pressed)
    {
        mute(soundSelectSpecial);
        scrSfx(soundCancel, 5);
        scr36_MessageSet("");
        substate = 1;
    }
    else if (fire2pressed && selCard != -4 && selCard != actionCard && !selCard.prestige)
    {
        actionCard.popularity = selCard.popularity;
        actionCard.money = selCard.money;
        actionCard.bounce = selCard.bounce;
        actionCard.bring = selCard.bring;
        actionCard.troublemaker = selCard.troublemaker;
        actionCard.peacekeeper = selCard.peacekeeper;
        actionCard.peek = selCard.peek;
        actionCard.dancer = selCard.dancer;
        actionCard.full = selCard.full;
        actionCard.phone = selCard.phone;
        actionCard.reshuffle = selCard.reshuffle;
        actionCard.photo = selCard.photo;
        actionCard.matchmaker = selCard.matchmaker;
        actionCard.schoolpride = selCard.schoolpride;
        actionCard.oldfriend = selCard.oldfriend;
        actionCard.introvert = selCard.introvert;
        actionCard.reform = selCard.reform;
        actionCard.reformed = selCard.reformed;
        actionCard.werewolf = selCard.werewolf;
        actionCard.refresh = selCard.refresh;
        actionCard.bless = selCard.bless;
        actionCard.upgrade = selCard.upgrade;
        actionCard.troublePopBonus = selCard.troublePopBonus;
        actionCard.troubleMoneyBonus = selCard.troubleMoneyBonus;
        actionCard.entranceBonus = selCard.entranceBonus;
        actionCard.magicSwap = selCard.magicSwap;
        actionCard.greet = selCard.greet;
        actionCard.banish = selCard.banish;
        actionCard.phoneLow = selCard.phoneLow;
        actionCard.flipped = selCard.flipped;
        actionCard.tiny = selCard.tiny;
        actionCard.tinySprite1 = actionCard.sprite_index;
        actionCard.tinySprite2 = actionCard.sprite_index;
        actionCard.tinyFlipped1 = selCard.tinyFlipped1;
        actionCard.tinyFlipped2 = selCard.tinyFlipped2;
        actionCard.drained = selCard.drained;
        actionCard.flipdrain = selCard.flipdrain;
        actionCard.copyfrog += selCard.copyfrog;
        actionCard.copyfrog--;
        scrSfx(soundPacify, 50);
        messageColor = global.palette[4];
        scr36_MessageSet(actionCard.name + " COPIED " + selCard.name);
        var oldTotalTrouble = totalTrouble;
        totalTrouble = scr36_GetTrouble();
        currPrestige = scr36_GetPrestige();
        if (totalTrouble >= TROUBLE_THRESHOLD)
        {
            mute(global.SFX);
            scrBGM(bgm36_stingPartyEndB, false);
            bgmTrig = false;
            messageColor = global.palette[9];
            scr36_MessageSet("OH NO! YOU CRASHED YOUR SHIP!");
            scr36_ChangeState(STATE_BUSTED);
            exit;
        }
        else if (totalTrouble == (TROUBLE_THRESHOLD - 1) && totalTrouble != oldTotalTrouble)
        {
            scrSfx(soundWarning, 55);
            messageColor = global.palette[9];
            scr36_MessageSet(scrString("warning"));
        }
        else if (actionCard.peacekeeper && oldTotalTrouble == (TROUBLE_THRESHOLD - 1) && totalTrouble == (TROUBLE_THRESHOLD - 2))
        {
            scrSfx(soundText, 40);
            troubleWarnStreak = 0;
            messageColor = global.palette[0];
            scr36_MessageSet(scrString("chilled_out"));
        }
        else if (totalTrouble == (TROUBLE_THRESHOLD - 1) && totalTrouble == oldTotalTrouble)
        {
            if (troubleWarnStreak < 4)
            {
                scrSfx(soundWarnStreak[troubleWarnStreak], 40);
            }
            else
            {
                scrSfx(soundWarnStreak[4], 40);
            }
            troubleWarnStreak++;
        }
        substate = 1;
    }
    else if (fire2pressed && selCard.prestige)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(actionCard.name + " CAN'T COPY STAR GUESTS");
    }
    else if (fire2pressed && selCard == -4)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("nobody_here"));
    }
    else if (fire2pressed && selCard == actionCard)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet(actionCard.name + " TRIED VERY HARD, BUT THEY COULDN'T COPY THEMSELF.");
    }
}
if (substate == 3)
{
    selOn = false;
    if (bringCounter)
    {
        stateTimer++;
        if (stateTimer == 1)
        {
            messageColor = global.palette[4];
            scr36_MessageSet(scrString("bringer"));
        }
        if (stateTimer == 100)
        {
            bringCounter--;
            stateTimer = 0;
            if (nextNextCard != -4)
            {
                nextCard = nextNextCard;
                nextNextCard = -4;
            }
            else
            {
                nextCard = -4;
            }
            substate = 2;
        }
    }
}
if (substate == 5)
{
    selOn = false;
    stateTimer++;
    if (stateTimer == 270)
    {
        if (popularity[cp] >= 3 || money[cp] >= (capacity[cp] - 3))
        {
            scr36_ChangeState(STATE_STORE);
        }
        else
        {
            scr36_ChangeState(STATE_START_PARTY);
        }
        exit;
    }
}
if (substate == 2)
{
    substate = 9;
    scr36_MessageSet("");
    if (ds_list_size(draw_pile) == 0)
    {
        scrSfx(soundText, 15);
        messageColor = global.palette[0];
        scr36_MessageSet("NO ONE LEFT IN HOLODEX!");
        bringCounter = 0;
        substate = 1;
        exit;
    }
    tNewCard = 3;
    newCard = ds_list_find_value(draw_pile, 0);
    ds_list_insert(party, 0, newCard);
    ds_list_delete(draw_pile, 0);
    if (greeting)
    {
        scoreStart = 0;
        scoreEnd = 1;
        scr36_ChangeState(STATE_SCORE);
        stateTimer = 68;
        exit;
    }
}
if (substate == 9)
{
    substate = 1;
    var _werewolfArrived = false;
    if (newCard.werewolf)
    {
        _werewolfArrived = true;
        if (!newCard.peacekeeper)
        {
            scrSfx(soundWerewolf, 50);
            messageColor = global.palette[0];
            scr36_MessageSet("THE UMBRELLA OPENED");
            newCard.flickerTimer = 32;
            newCard.peacekeeper = true;
            newCard.sprite_index = s36_Werewolf2;
        }
        else
        {
            scrSfx(soundWerewolf, 50);
            messageColor = global.palette[0];
            scr36_MessageSet("THE UMBRELLA CLOSED");
            newCard.flickerTimer = 32;
            newCard.peacekeeper = false;
            newCard.sprite_index = s36_Werewolf1;
        }
    }
    var oldTotalTrouble = totalTrouble;
    totalTrouble = scr36_GetTrouble();
    currPrestige = scr36_GetPrestige();
    var bringerArrived = false;
    if (newCard != -4)
    {
        if (newCard.bring > 0)
        {
            bringerArrived = true;
        }
    }
    if (newCard.entranceBonus && newCard.money < 9)
    {
        scrSfx(soundPopular, 50);
        messageColor = global.palette[11];
        scr36_MessageSet("OUTLAW JUST ROBBED ANOTHER TRAIN");
        newCard.flickerTimer = 32;
        newCard.money += newCard.entranceBonus;
    }
    if (bringerArrived)
    {
        scrSfx(soundBring, 50);
        bringCounter += newCard.bring;
        substate = 3;
    }
    else if (ds_list_size(party) > capacity[cp])
    {
        mute(global.SFX);
        scrBGM(bgm36_stingPartyEndB, false);
        bgmTrig = false;
        messageColor = global.palette[9];
        scr36_MessageSet("ERROR 36: PARTY OVERFLOW");
        scr36_ChangeState(STATE_BUSTED);
    }
    else if (totalTrouble >= TROUBLE_THRESHOLD)
    {
        mute(global.SFX);
        scrBGM(bgm36_stingPartyEndB, false);
        bgmTrig = false;
        messageColor = global.palette[9];
        scr36_MessageSet("OH NO! YOU CRASHED YOUR SHIP!");
        scr36_ChangeState(STATE_BUSTED);
    }
    else if (bringCounter)
    {
        substate = 3;
    }
    else if (ds_list_size(party) == capacity[cp])
    {
        var unusedActions = false;
        for (var i = 0; i < ds_list_size(party); i++)
        {
            if (ds_list_find_value(party, i).bounce > 0 || ds_list_find_value(party, i).reshuffle > 0 || ds_list_find_value(party, i).matchmaker > 0 || ds_list_find_value(party, i).upgrade > 0 || ds_list_find_value(party, i).magicSwap > 0 || ds_list_find_value(party, i).banish > 0 || ds_list_find_value(party, i).copyfrog > 0)
            {
                ds_list_find_value(party, i).flickerActionTimer = 800;
                unusedActions = true;
            }
        }
        var actionsToBless = false;
        for (var i = 0; i < ds_list_size(party); i++)
        {
            if ((ds_list_find_value(party, i).bouncemax > 0 && ds_list_find_value(party, i).bounce < 4) || (ds_list_find_value(party, i).peekmax > 0 && ds_list_find_value(party, i).peek < 4) || (ds_list_find_value(party, i).phonemax > 0 && ds_list_find_value(party, i).phone < 4) || (ds_list_find_value(party, i).reshufflemax > 0 && ds_list_find_value(party, i).reshuffle < 4) || (ds_list_find_value(party, i).photomax > 0 && ds_list_find_value(party, i).photo < 4) || (ds_list_find_value(party, i).matchmakermax > 0 && ds_list_find_value(party, i).matchmaker < 4) || (ds_list_find_value(party, i).introvertmax > 0 && ds_list_find_value(party, i).introvert < 7) || (ds_list_find_value(party, i).reformmax > 0 && ds_list_find_value(party, i).reform < 4) || (ds_list_find_value(party, i).upgrademax > 0 && ds_list_find_value(party, i).upgrade < 4) || (ds_list_find_value(party, i).magicSwapmax > 0 && ds_list_find_value(party, i).magicSwap < 4) || (ds_list_find_value(party, i).greetmax > 0 && ds_list_find_value(party, i).greet < 4) || (ds_list_find_value(party, i).banishmax > 0 && ds_list_find_value(party, i).banish < 4))
            {
                actionsToBless = true;
            }
        }
        if (actionsToBless)
        {
            for (var i = 0; i < ds_list_size(party); i++)
            {
                if (ds_list_find_value(party, i).bless > 0)
                {
                    ds_list_find_value(party, i).flickerActionTimer = 800;
                    unusedActions = true;
                }
            }
        }
        if (unusedActions)
        {
            for (var i = 0; i < ds_list_size(party); i++)
            {
                if (ds_list_find_value(party, i).reform > 0)
                {
                    ds_list_find_value(party, i).flickerActionTimer = 800;
                }
            }
        }
        var prestigeChars = 0;
        for (var i = 0; i < ds_list_size(deck[cp]); i++)
        {
            var c = ds_list_find_value(deck[cp], i);
            if (c.prestige > 0)
            {
                prestigeChars++;
            }
        }
        if (prestigeChars > 0)
        {
            for (var i = 0; i < ds_list_size(party); i++)
            {
                if (ds_list_find_value(party, i).magicSwap > 0)
                {
                    ds_list_find_value(party, i).flickerActionTimer = 800;
                    unusedActions = true;
                }
            }
        }
        if (!unusedActions)
        {
            mute(global.SFX);
            scrBGM(bgm36_stingPartyEndA, false);
            bgmTrig = false;
            messageColor = global.palette[0];
            with (o36_Card)
            {
                flickerActionTimer = 0;
            }
            nextCard = -4;
            nextNextCard = -4;
            if (!_werewolfArrived)
            {
                scr36_MessageSet(scrString("full_party"));
            }
            scr36_ChangeState(STATE_SCORE);
            phase = PHASE_SCORING;
        }
        else
        {
            scrSfx(soundText, 40);
            messageColor = global.palette[0];
            scr36_MessageSet(scrString("full_party_actions"));
        }
    }
    else if (totalTrouble == (TROUBLE_THRESHOLD - 1) && totalTrouble != oldTotalTrouble)
    {
        scrSfx(soundWarning, 55);
        messageColor = global.palette[9];
        scr36_MessageSet(scrString("warning"));
    }
    else if (newCard.peacekeeper && oldTotalTrouble == (TROUBLE_THRESHOLD - 1) && totalTrouble == (TROUBLE_THRESHOLD - 2))
    {
        scrSfx(soundText, 40);
        troubleWarnStreak = 0;
        messageColor = global.palette[0];
        scr36_MessageSet(scrString("chilled_out"));
    }
    else if (totalTrouble == (TROUBLE_THRESHOLD - 1) && totalTrouble == oldTotalTrouble)
    {
        if (!greeting)
        {
            if (troubleWarnStreak < 4)
            {
                scrSfx(soundWarnStreak[troubleWarnStreak], 40);
            }
            else
            {
                scrSfx(soundWarnStreak[4], 40);
            }
        }
        troubleWarnStreak++;
    }
    else if (ds_list_size(party) == (capacity[cp] - 1))
    {
        if (!greeting)
        {
            scrSfx(soundDoorOpen, 40);
        }
        messageColor = global.palette[0];
        if (!_werewolfArrived)
        {
            scr36_MessageSet(scrString("almost_full"));
        }
    }
    else if (!greeting)
    {
        scrSfx(soundDoorOpen, 40);
    }
    if (bringCounter == 0)
    {
        greeting = false;
    }
}
