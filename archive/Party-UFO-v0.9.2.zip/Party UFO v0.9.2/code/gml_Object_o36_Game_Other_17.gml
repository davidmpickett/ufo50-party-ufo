if (substate == 0)
{
    substate = 1;
    currPrestige = 0;
    if (prevState == STATE_SCORE || prevState == STATE_PARTY)
    {
        scrSfx(soundTransitionB, 60);
        phase = PHASE_SHOP;
        for (var i = 0; i < ds_list_size(store); i++)
        {
            if (ds_list_find_value(store, i).type == CHAR_EXPAND)
            {
                ds_list_find_value(store, i).moneyCost = capacity[cp] - 3;
            }
            if (ds_list_find_value(store, i).moneyCost > MAX_EXPAND_COST)
            {
                ds_list_find_value(store, i).moneyCost = MAX_EXPAND_COST;
            }
        }
        selectorX = 0;
        selectorY = 0;
        messageColor = 16777215;
        scr36_MessageSet(scrString("store_intro"));
        if (PRICE_DROP_ON_2P && numPlayers == 2 && time[cp] == (PRICE_DROP_DAY_2P - 1))
        {
            var str = scrStringVal("price_drop", PRICE_DROP_AMOUNT_2P);
            scr36_MessageSet(str);
        }
    }
    else if (prevState == STATE_ROLODEX)
    {
        selectorY = floor(ds_list_size(store) / 9);
        selectorX = ds_list_size(store) - (selectorY * 9);
        stateTimer = 37;
    }
}
if (substate == 1)
{
    stateTimer++;
    if (PRICE_DROP_ON_1P && numPlayers == 1 && time[cp] == (PRICE_DROP_DAY_1P - 1) && (prevState == STATE_SCORE || prevState == STATE_PARTY))
    {
        if (stateTimer == 36)
        {
            mute(global.SFX);
            scrBGM(bgm36_stingPartyEndB, false);
            bgmTrig = false;
            var str = "BLACK HOLE SALE! THE COST OF GUESTS WILL DROP BY 10% EACH ROUND!";
            scr36_MessageSet(str);
        }
        if (stateTimer > 336)
        {
            if (!bgmTrig)
            {
                scrBGM(bgm36_shop);
                bgmTrig = true;
            }
            selOn = true;
            substate = 2;
        }
    }
    else if (stateTimer > 36)
    {
        if (!bgmTrig)
        {
            scrBGM(bgm36_shop);
            bgmTrig = true;
        }
        selOn = true;
        substate = 2;
    }
}
if (substate == 2)
{
    var moved = scr36_HandleMovement(0, ds_list_size(store) + 2);
    if (moved)
    {
        scrSfx(soundNaviB, 10);
    }
    selIndex = scr36_GetIndex(selectorX, selectorY, 0);
    if (selIndex >= 0 && selIndex < ds_list_size(store))
    {
        selCard = ds_list_find_value(store, selIndex);
    }
    else
    {
        selCard = -4;
    }
    if (pressUp || pressLeft || pressRight || pressDown)
    {
        if (selCard != -4)
        {
            if (selCard.cost > 0)
            {
                messageColor = 16777215;
                scr36_MessageSetFull(scrStringVal("pop_cost", selCard.cost));
            }
            else if (selCard.type == CHAR_EXPAND)
            {
                messageColor = 16777215;
                scr36_MessageSet("SPEND " + string(selCard.moneyCost) + " MONEY TO EXPAND UFO.");
            }
            else if (selCard.moneyCost > 0)
            {
                messageColor = 16777215;
                scr36_MessageSetFull(scrStringVal("money_cost", selCard.moneyCost));
            }
        }
        else
        {
            scr36_MessageSet("");
        }
    }
    if (fire2pressed && selCard != -4)
    {
        if (selCard.cost > 0)
        {
            if (selCard.supply <= 0)
            {
                mute(soundPurchase);
                scrSfx(soundNope, 20);
                messageColor = global.palette[9];
                scr36_MessageSet(scrString("char_not_avail"));
            }
            else if (popularity[cp] < selCard.cost)
            {
                mute(soundPurchase);
                scrSfx(soundNope, 20);
                messageColor = global.palette[9];
                scr36_MessageSet(scrString("not_enough_pop"));
            }
            else
            {
                scrSfx(soundPurchase, 65);
                popularity[cp] -= selCard.cost;
                ds_list_add(deck[cp], scr36_CreateCard(selCard.type));
                messageColor = 16777215;
                scr36_MessageSetFull(scrStringVal("add_char", selCard.name));
                if (selCard.oldfriend)
                {
                    var newType;
                    do
                    {
                        newType = scrChoose(CHAR_COOL_BUDDY_M, CHAR_COOL_BUDDY_M_2, CHAR_COOL_BUDDY_F, CHAR_COOL_BUDDY_F_2);
                    }
                    until (newType != selCard.type);
                    var oldCard = selCard;
                    selCard = scr36_CreateCard(newType);
                    selCard.supply = oldCard.supply;
                    with (oldCard)
                    {
                        instance_destroy();
                    }
                    ds_list_set(store, selIndex, selCard);
                }
                else if (selCard.type == CHAR_RICH_FRIEND_M || selCard.type == CHAR_RICH_FRIEND_F)
                {
                    var newType;
                    do
                    {
                        newType = scrChoose(CHAR_RICH_FRIEND_M, CHAR_RICH_FRIEND_F);
                    }
                    until (newType != selCard.type);
                    var oldCard = selCard;
                    selCard = scr36_CreateCard(newType);
                    selCard.supply = oldCard.supply;
                    with (oldCard)
                    {
                        instance_destroy();
                    }
                    ds_list_set(store, selIndex, selCard);
                }
                if (selCard.supply <= STORE_SUPPLY)
                {
                    selCard.supply--;
                }
                selCard.flickerTimer = 96;
                if (ds_list_find_value(store, 0).supply == 0 && ds_list_find_value(store, 1).supply == 0)
                {
                    for (var i = 0; i < ds_list_size(deck[cp]); i++)
                    {
                        var _card = ds_list_find_value(deck[cp], i);
                        switch (_card.type)
                        {
                            case CHAR_COOL_BUDDY_M:
                                _card.name = scrStringManual("game_meta_message_36_cool_buddy_m", 0);
                                break;
                            case CHAR_COOL_BUDDY_M_2:
                                _card.name = scrStringManual("game_meta_message_36_cool_buddy_m2", 0);
                                break;
                            case CHAR_COOL_BUDDY_F:
                                _card.name = scrStringManual("game_meta_message_36_cool_buddy_f", 0);
                                break;
                            case CHAR_COOL_BUDDY_F_2:
                                _card.name = scrStringManual("game_meta_message_36_cool_buddy_f2", 0);
                                break;
                            case CHAR_WILD_FRIEND_M:
                                _card.name = "PILOT";
                                break;
                            case CHAR_WILD_FRIEND_F:
                                _card.name = "ISABELL";
                                break;
                            case CHAR_WILD_FRIEND_M_2:
                                _card.name = "STEWARD";
                                break;
                            case CHAR_WILD_FRIEND_F_2:
                                _card.name = "NONNA";
                                break;
                            case CHAR_RICH_FRIEND_M:
                                _card.name = scrStringManual("game_meta_message_36_rich_pal_m", 0);
                                break;
                            case CHAR_RICH_FRIEND_F:
                                _card.name = scrStringManual("game_meta_message_36_rich_pal_f", 0);
                                break;
                            case CHAR_BARTENDER:
                                _card.name = scrStringManual("game_meta_message_bartender", 0);
                                break;
                            case CHAR_ROCK_STAR:
                                _card.name = scrStringManual("game_meta_message_rock_star", 0);
                                break;
                            case CHAR_PHOTOGRAPHER:
                                _card.name = scrStringManual("game_meta_message_photographer", 0);
                                break;
                            case CHAR_STYLIST:
                                _card.name = scrStringManual("game_meta_message_stylist", 0);
                                break;
                            case CHAR_COUNSELOR:
                                _card.name = scrStringManual("game_meta_message_counselor", 0);
                                break;
                            case CHAR_CUTE_DOG:
                                _card.name = scrStringManual("game_meta_message_cute_dog", 0);
                                break;
                            case CHAR_DOG:
                                _card.name = scrStringManual("game_meta_message_dog", 0);
                                break;
                        }
                    }
                    for (var i = 0; i < ds_list_size(store); i++)
                    {
                        var _card = ds_list_find_value(store, i);
                        switch (_card.type)
                        {
                            case CHAR_COOL_BUDDY_M:
                                _card.name = scrStringManual("game_meta_message_36_cool_buddy_m", 0);
                                break;
                            case CHAR_COOL_BUDDY_M_2:
                                _card.name = scrStringManual("game_meta_message_36_cool_buddy_m2", 0);
                                break;
                            case CHAR_COOL_BUDDY_F:
                                _card.name = scrStringManual("game_meta_message_36_cool_buddy_f", 0);
                                break;
                            case CHAR_COOL_BUDDY_F_2:
                                _card.name = scrStringManual("game_meta_message_36_cool_buddy_f2", 0);
                                break;
                            case CHAR_WILD_FRIEND_M:
                                _card.name = scrStringManual("game_meta_message_36_wild_friend_m", 0);
                                break;
                            case CHAR_WILD_FRIEND_F:
                                _card.name = scrStringManual("game_meta_message_36_wild_friend_f", 0);
                                break;
                            case CHAR_WILD_FRIEND_M_2:
                                _card.name = scrStringManual("game_meta_message_36_wild_friend_m2", 0);
                                break;
                            case CHAR_WILD_FRIEND_F_2:
                                _card.name = scrStringManual("game_meta_message_36_wild_friend_f2", 0);
                                break;
                            case CHAR_RICH_FRIEND_M:
                                _card.name = scrStringManual("game_meta_message_36_rich_pal_m", 0);
                                break;
                            case CHAR_RICH_FRIEND_F:
                                _card.name = scrStringManual("game_meta_message_36_rich_pal_f", 0);
                                break;
                            case CHAR_BARTENDER:
                                _card.name = scrStringManual("game_meta_message_bartender", 0);
                                break;
                            case CHAR_ROCK_STAR:
                                _card.name = scrStringManual("game_meta_message_rock_star", 0);
                                break;
                            case CHAR_PHOTOGRAPHER:
                                _card.name = scrStringManual("game_meta_message_photographer", 0);
                                break;
                            case CHAR_STYLIST:
                                _card.name = scrStringManual("game_meta_message_stylist", 0);
                                break;
                            case CHAR_COUNSELOR:
                                _card.name = scrStringManual("game_meta_message_counselor", 0);
                                break;
                            case CHAR_CUTE_DOG:
                                _card.name = scrStringManual("game_meta_message_cute_dog", 0);
                                break;
                            case CHAR_DOG:
                                _card.name = scrStringManual("game_meta_message_dog", 0);
                                break;
                        }
                    }
                }
            }
        }
        else if (selCard.moneyCost > 0)
        {
            if (money[cp] < selCard.moneyCost)
            {
                mute(soundExpand);
                scrSfx(soundNope, 20);
                messageColor = global.palette[9];
                scr36_MessageSet(scrString("not_enough_money"));
            }
            else if (selCard.type == CHAR_EXPAND)
            {
                if (capacity[cp] < CAPACITY_MAX)
                {
                    scrSfx(soundExpand, 65);
                    money[cp] -= selCard.moneyCost;
                    selCard.flickerTimer = 96;
                    capacity[cp]++;
                    selCard.moneyCost = capacity[cp] - 3;
                    if (selCard.moneyCost > MAX_EXPAND_COST)
                    {
                        selCard.moneyCost = MAX_EXPAND_COST;
                    }
                    messageColor = 16777215;
                    scr36_MessageSet(scrString("expand_capacity"));
                }
                else
                {
                    mute(soundExpand);
                    scrSfx(soundNope, 20);
                    messageColor = global.palette[9];
                    scr36_MessageSet(scrString("house_max_big"));
                }
            }
            else
            {
                money[cp] -= selCard.moneyCost;
                selCard.flickerTimer = 96;
                ds_list_add(deck[cp], scr36_CreateCard(selCard.type));
                messageColor = 16777215;
                scr36_MessageSetFull(scrStringVal("add_char", selCard.name));
            }
        }
    }
    if (fire2pressed && selIndex == ds_list_size(store))
    {
        scrSfx(soundTransitionA, 60);
        selOn = false;
        scr36_ChangeState(STATE_ROLODEX);
        exit;
    }
    if (fire2pressed && selIndex == (ds_list_size(store) + 1))
    {
        muteBGM();
        bgmTrig = false;
        selOn = false;
        scr36_ChangeState(STATE_START_PARTY);
        for (var i = 0; i < ds_list_size(deck[cp]); i++)
        {
            var currCard = ds_list_find_value(deck[cp], i);
            if (verify(currCard))
            {
                charsUsed[currCard.type] = true;
            }
        }
        exit;
    }
    else if (fire1pressed)
    {
        if (selIndex == (ds_list_size(store) + 1))
        {
            muteBGM();
            bgmTrig = false;
            selOn = false;
            scr36_ChangeState(STATE_START_PARTY);
            for (var i = 0; i < ds_list_size(deck[cp]); i++)
            {
                var currCard = ds_list_find_value(deck[cp], i);
                if (verify(currCard))
                {
                    charsUsed[currCard.type] = true;
                }
            }
            exit;
        }
        else
        {
            scrSfx(soundNaviB, 10);
            selectorX = 8;
            selectorY = 1;
            selIndex = scr36_GetIndex(selectorX, selectorY, 0);
        }
    }
}
