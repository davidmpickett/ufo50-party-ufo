function scr36_SetupGame(arg0)
{
    wonGame[0] = false;
    wonGame[1] = false;
    tiePossible = false;
    cp = 0;
    for (var p = 0; p < 2; p++)
    {
        popularity[p] = 0;
        money[p] = 0;
        capacity[p] = START_CAPACITY;
        time[p] = NUM_DAYS;
        ds_list_add(deck[p], scr36_CreateCard(CHAR_WILD_FRIEND_M_2), scr36_CreateCard(CHAR_WILD_FRIEND_F_2), scr36_CreateCard(CHAR_WILD_FRIEND_M), scr36_CreateCard(CHAR_WILD_FRIEND_F), scr36_CreateCard(CHAR_RICH_FRIEND_M), scr36_CreateCard(CHAR_RICH_FRIEND_F), scr36_CreateCard(CHAR_COOL_BUDDY_M), scr36_CreateCard(CHAR_COOL_BUDDY_F), scr36_CreateCard(CHAR_COOL_BUDDY_M_2), scr36_CreateCard(CHAR_COOL_BUDDY_F_2));
        justBusted[p] = false;
    }
    if (arg0 < 5)
    {
        echoSwap = false;
    }
    popularity[1] += POP_2P_BONUS;
    money[1] += MONEY_2P_BONUS;
    ds_list_copy(store, scenario[arg0]);
    ds_list_insert(store, 0, scr36_CreateCard(scrChoose(CHAR_RICH_FRIEND_M, CHAR_RICH_FRIEND_F)));
    ds_list_insert(store, 0, scr36_CreateCard(scrChoose(CHAR_COOL_BUDDY_M, CHAR_COOL_BUDDY_M_2, CHAR_COOL_BUDDY_F, CHAR_COOL_BUDDY_F_2)));
    ds_list_insert(store, 0, scr36_CreateCard(CHAR_EXPAND));
    scr36_SortCharacters(store);
}
